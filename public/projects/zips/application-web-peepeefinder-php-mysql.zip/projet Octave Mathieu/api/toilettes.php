<?php
/**
 * ========================================
 * API REST - RÉCUPÉRATION DES TOILETTES
 * ========================================
 *
 * Fichier: api/toilettes.php
 * Description: API REST pour récupérer la liste des toilettes avec filtres
 *
 * Méthode HTTP: GET
 * Format de sortie: JSON
 *
 * Fonctionnalités:
 * - Récupération de toutes les toilettes avec coordonnées GPS
 * - Filtrage avancé (PMR, payant/gratuit, 24/7, type, commune, note)
 * - Recherche textuelle (nom, adresse, commune)
 * - Pagination (limit/offset)
 * - Tri personnalisable
 * - Indication des favoris pour utilisateur connecté
 * - Comptage total avec et sans filtres
 *
 * Paramètres GET disponibles:
 * - pmr=1            : Filtrer les toilettes accessibles PMR
 * - gratuit=1        : Filtrer les toilettes gratuites
 * - payant=1         : Filtrer les toilettes payantes
 * - ouvert_24_7=1    : Filtrer les toilettes ouvertes 24/7
 * - not_ouvert_24_7=1: Filtrer les toilettes NON ouvertes 24/7
 * - type=xxx         : Filtrer par type (ex: "public", "automatique")
 * - commune=xxx      : Filtrer par commune (recherche partielle)
 * - note_min=x       : Filtrer par note minimum (ex: 3.5)
 * - search=xxx       : Recherche dans nom, adresse, commune
 * - ids=1,2,3        : Récupérer uniquement les IDs spécifiés
 * - sort=xxx         : Trier par (nom, commune, note_moyenne, created_at)
 * - order=ASC|DESC   : Ordre de tri (défaut: ASC)
 * - limit=n          : Nombre de résultats (max 1000)
 * - offset=n         : Décalage pour pagination
 *
 * Réponse JSON:
 * {
 *   "success": true,
 *   "count": 150,        // Nombre de résultats retournés
 *   "total": 500,        // Nombre total avec filtres appliqués
 *   "limit": 100,
 *   "offset": 0,
 *   "data": [...]        // Tableau de toilettes
 * }
 *
 * @author PeePeeFinder Team
 * @version 1.0
 */

// ========================================
// 1. INITIALISATION
// ========================================
session_start();
require_once '../includes/db.php';

// ========================================
// 2. HEADERS HTTP
// ========================================
// Headers JSON pour la réponse
header('Content-Type: application/json; charset=utf-8');

// Headers CORS (Cross-Origin Resource Sharing)
// Permettent l'accès à l'API depuis d'autres domaines
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// ========================================
// 3. GESTION PREFLIGHT CORS (OPTIONS)
// ========================================
// Les navigateurs envoient une requête OPTIONS avant GET/POST pour vérifier les permissions CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// ========================================
// 4. TRAITEMENT PRINCIPAL
// ========================================
try {
    // ---- Récupérer l'ID utilisateur si connecté ----
    // Utilisé pour indiquer les favoris de l'utilisateur
    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

    // ========================================
    // 5. CONSTRUCTION DE LA REQUÊTE SQL
    // ========================================

    // ---- Requête de base avec ou sans favoris ----
    if ($user_id) {
        // Si connecté, ajouter une sous-requête pour détecter les favoris
        $sql = "SELECT
                    t.id,
                    t.nom,
                    t.type_normalise as type,
                    t.adresse,
                    t.commune,
                    t.code_postal,
                    t.payant,
                    t.acces_pmr,
                    t.ouvert_24_7,
                    t.latitude,
                    t.longitude,
                    t.note_moyenne,
                    t.nombre_avis,
                    t.horaires,
                    t.description,
                    t.Source,
                    t.Type as type_original,
                    t.`Horaires d'ouverture` as horaires_ouverture,
                    (SELECT COUNT(*) FROM favorites WHERE user_id = $user_id AND toilette_id = t.id) as is_favorite
                FROM toilettes t
                WHERE t.latitude IS NOT NULL AND t.longitude IS NOT NULL";
    } else {
        // Si non connecté, is_favorite sera toujours 0
        $sql = "SELECT
                    id,
                    nom,
                    type_normalise as type,
                    adresse,
                    commune,
                    code_postal,
                    payant,
                    acces_pmr,
                    ouvert_24_7,
                    latitude,
                    longitude,
                    note_moyenne,
                    nombre_avis,
                    horaires,
                    description,
                    Source,
                    Type as type_original,
                    `Horaires d'ouverture` as horaires_ouverture,
                    0 as is_favorite
                FROM toilettes
                WHERE latitude IS NOT NULL AND longitude IS NOT NULL";
    }

    // Tableau de paramètres pour prepared statement
    $params = array();

    // ========================================
    // 6. APPLICATION DES FILTRES
    // ========================================

    // ---- Filtre: Accessible PMR ----
    if (isset($_GET['pmr']) && $_GET['pmr'] == '1') {
        $sql .= " AND acces_pmr = 1";
    }

    // ---- Filtre: Gratuit ----
    if (isset($_GET['gratuit']) && $_GET['gratuit'] == '1') {
        $sql .= " AND payant = 0";
    }

    // ---- Filtre: Payant ----
    if (isset($_GET['payant']) && $_GET['payant'] == '1') {
        $sql .= " AND payant = 1";
    }

    // ---- Filtre: Ouvert 24/7 ----
    if (isset($_GET['ouvert_24_7']) && $_GET['ouvert_24_7'] == '1') {
        $sql .= " AND ouvert_24_7 = 1";
    }

    // ---- Filtre: NON ouvert 24/7 ----
    if (isset($_GET['not_ouvert_24_7']) && $_GET['not_ouvert_24_7'] == '1') {
        $sql .= " AND ouvert_24_7 = 0";
    }

    // ---- Filtre: Type de toilette ----
    // Ex: "public", "automatique", etc.
    if (isset($_GET['type']) && !empty($_GET['type']) && $_GET['type'] !== 'all') {
        $sql .= " AND type = ?";
        $params[] = $_GET['type'];
    }

    // ---- Filtre: Commune ----
    // Recherche partielle avec LIKE %commune%
    if (isset($_GET['commune']) && !empty($_GET['commune'])) {
        $sql .= " AND commune LIKE ?";
        $params[] = '%' . $_GET['commune'] . '%';
    }

    // ---- Filtre: Note minimum ----
    // Ex: note_min=3.5 pour afficher uniquement les toilettes avec note >= 3.5
    if (isset($_GET['note_min']) && is_numeric($_GET['note_min'])) {
        $sql .= " AND note_moyenne >= ?";
        $params[] = (float)$_GET['note_min'];
    }

    // ---- Filtre: Recherche textuelle ----
    // Recherche dans nom, adresse, commune
    if (isset($_GET['search']) && !empty($_GET['search'])) {
        $search = '%' . $_GET['search'] . '%';
        $sql .= " AND (nom LIKE ? OR adresse LIKE ? OR commune LIKE ?)";
        $params[] = $search;
        $params[] = $search;
        $params[] = $search;
    }

    // ---- Filtre: IDs spécifiques ----
    // Ex: ids=1,5,12 pour récupérer uniquement ces toilettes
    if (isset($_GET['ids']) && !empty($_GET['ids'])) {
        $ids = explode(',', $_GET['ids']);
        $ids = array_filter($ids, 'is_numeric');  // Sécurité: garder uniquement les nombres
        if (!empty($ids)) {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $sql .= " AND id IN ($placeholders)";
            $params = array_merge($params, $ids);
        }
    }

    // ========================================
    // 7. TRI DES RÉSULTATS
    // ========================================
    // Liste blanche des colonnes autorisées pour le tri (sécurité)
    $allowed_sort = array('nom', 'commune', 'note_moyenne', 'created_at');
    $sort_by = (isset($_GET['sort']) && in_array($_GET['sort'], $allowed_sort)) ? $_GET['sort'] : 'nom';
    $sort_order = (isset($_GET['order']) && strtoupper($_GET['order']) === 'DESC') ? 'DESC' : 'ASC';
    $sql .= " ORDER BY " . $sort_by . " " . $sort_order;

    // ========================================
    // 8. PAGINATION
    // ========================================
    // Par défaut, pas de limite (pour charger toute la carte)
    // On peut forcer limit=none pour désactiver explicitement la limite
    $limit = (isset($_GET['limit']) && is_numeric($_GET['limit'])) ? (int)$_GET['limit'] : null;
    $offset = (isset($_GET['offset']) && is_numeric($_GET['offset'])) ? (int)$_GET['offset'] : 0;

    // Appliquer la limite seulement si définie
    if ($limit !== null && (!isset($_GET['limit']) || $_GET['limit'] !== 'none')) {
        // Sécurité: limiter à 1000 résultats max
        $limit = min($limit, 1000);
        $sql .= " LIMIT " . $limit . " OFFSET " . $offset;
    }

    // ========================================
    // 9. EXÉCUTION DE LA REQUÊTE PRINCIPALE
    // ========================================
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $toilettes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // ========================================
    // 10. COMPTAGE TOTAL (SANS LIMITE)
    // ========================================
    // Compter le nombre total de résultats avec les mêmes filtres
    $count_sql = "SELECT COUNT(*) as total FROM toilettes WHERE 1=1";
    $count_params = array();

    // ---- Répéter les mêmes filtres pour le comptage ----
    if (isset($_GET['pmr']) && $_GET['pmr'] == '1') {
        $count_sql .= " AND acces_pmr = 1";
    }
    if (isset($_GET['gratuit']) && $_GET['gratuit'] == '1') {
        $count_sql .= " AND payant = 0";
    }
    if (isset($_GET['payant']) && $_GET['payant'] == '1') {
        $count_sql .= " AND payant = 1";
    }
    if (isset($_GET['ouvert_24_7']) && $_GET['ouvert_24_7'] == '1') {
        $count_sql .= " AND ouvert_24_7 = 1";
    }
    if (isset($_GET['not_ouvert_24_7']) && $_GET['not_ouvert_24_7'] == '1') {
        $count_sql .= " AND ouvert_24_7 = 0";
    }
    if (isset($_GET['type']) && !empty($_GET['type']) && $_GET['type'] !== 'all') {
        $count_sql .= " AND type = ?";
        $count_params[] = $_GET['type'];
    }
    if (isset($_GET['commune']) && !empty($_GET['commune'])) {
        $count_sql .= " AND commune LIKE ?";
        $count_params[] = '%' . $_GET['commune'] . '%';
    }
    if (isset($_GET['note_min']) && is_numeric($_GET['note_min'])) {
        $count_sql .= " AND note_moyenne >= ?";
        $count_params[] = (float)$_GET['note_min'];
    }
    if (isset($_GET['search']) && !empty($_GET['search'])) {
        $search = '%' . $_GET['search'] . '%';
        $count_sql .= " AND (nom LIKE ? OR adresse LIKE ? OR commune LIKE ?)";
        $count_params[] = $search;
        $count_params[] = $search;
        $count_params[] = $search;
    }

    // Exécuter le comptage
    $count_stmt = $pdo->prepare($count_sql);
    $count_stmt->execute($count_params);
    $count_result = $count_stmt->fetch(PDO::FETCH_ASSOC);
    $total = $count_result['total'];

    // ========================================
    // 11. FORMATAGE DES DONNÉES
    // ========================================
    // Convertir les types de données pour JSON cohérent
    $formatted_toilettes = array();
    foreach ($toilettes as $toilet) {
        $formatted_toilettes[] = array(
            'id' => (int)$toilet['id'],
            'nom' => $toilet['nom'],
            'type' => $toilet['type'],
            'adresse' => $toilet['adresse'],
            'commune' => $toilet['commune'],
            'code_postal' => $toilet['code_postal'],
            'payant' => (bool)$toilet['payant'],
            'acces_pmr' => (bool)$toilet['acces_pmr'],
            'ouvert_24_7' => (bool)$toilet['ouvert_24_7'],
            'latitude' => (float)$toilet['latitude'],
            'longitude' => (float)$toilet['longitude'],
            'note_moyenne' => round((float)$toilet['note_moyenne'], 2),
            'nombre_avis' => (int)$toilet['nombre_avis'],
            'horaires' => $toilet['horaires'],
            'description' => $toilet['description'],
            'is_favorite' => (bool)$toilet['is_favorite']
        );
    }

    // ========================================
    // 12. RÉPONSE JSON
    // ========================================
    $response = array(
        'success' => true,
        'count' => count($formatted_toilettes),  // Nombre retourné
        'total' => (int)$total,                   // Nombre total avec filtres
        'limit' => $limit,
        'offset' => $offset,
        'data' => $formatted_toilettes
    );

    // Headers pour désactiver le cache (toujours retourner données fraîches)
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');

    // Encoder en JSON avec caractères UTF-8 préservés et indentation
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

} catch (Exception $e) {
    // ========================================
    // 13. GESTION DES ERREURS
    // ========================================
    // Logger l'erreur technique
    error_log("API Toilettes Error: " . $e->getMessage());

    // Retourner une erreur JSON
    http_response_code(500);
    echo json_encode(array(
        'success' => false,
        'error' => 'Erreur serveur',
        'message' => 'Impossible de récupérer les données',
        'debug' => $e->getMessage()
    ), JSON_UNESCAPED_UNICODE);
}
?>
