<?php
/**
 * ========================================
 * API REST - AJOUT/MODIFICATION D'AVIS
 * ========================================
 *
 * Fichier: api/add_avis.php
 * Description: Ajoute ou met à jour un avis (review) pour une toilette
 *
 * Méthode HTTP: POST
 * Format de sortie: JSON
 * Authentification: Requise
 *
 * Corps de la requête (JSON):
 * {
 *   "toilette_id": 42,
 *   "note": 4,
 *   "proprete": 5,
 *   "commentaire": "Très propre et bien entretenu"
 * }
 *
 * Fonctionnalités:
 * - Ajouter un nouvel avis si l'utilisateur n'en a pas déjà un
 * - Mettre à jour l'avis existant si l'utilisateur a déjà noté
 * - Recalculer automatiquement les statistiques de la toilette
 * - Mettre à jour la note moyenne et le nombre d'avis
 * - Validation des données (note entre 1 et 5)
 *
 * Validation:
 * - toilette_id > 0
 * - note: 1-5 (requis)
 * - proprete: 0-5 (optionnel, défaut 0)
 * - commentaire: string (optionnel)
 *
 * Réponse JSON (succès):
 * {
 *   "success": true,
 *   "message": "Avis ajouté" | "Avis mis à jour",
 *   "stats": {
 *     "note_moyenne": 4.2,
 *     "nombre_avis": 15,
 *     "proprete_moyenne": 4.5
 *   }
 * }
 *
 * @author PeePeeFinder Team
 * @version 1.0
 */

// ========================================
// 1. INITIALISATION
// ========================================
session_start();
require_once '../includes/db.php';

// Header JSON
header('Content-Type: application/json; charset=utf-8');

// ========================================
// 2. VÉRIFICATION AUTHENTIFICATION
// ========================================
// Seuls les utilisateurs connectés peuvent déposer des avis
if (!isset($_SESSION['user_id'])) {
    echo json_encode(array('success' => false, 'message' => 'Non connecté'));
    exit();
}

// ========================================
// 3. VÉRIFICATION DE LA MÉTHODE HTTP
// ========================================
// Cette API accepte uniquement POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(array('success' => false, 'message' => 'Méthode invalide'));
    exit();
}

// ========================================
// 4. RÉCUPÉRATION ET VALIDATION DES DONNÉES
// ========================================
// Lire le corps de la requête JSON
$data = json_decode(file_get_contents('php://input'), true);

// Extraire les données
$user_id = $_SESSION['user_id'];
$toilette_id = isset($data['toilette_id']) ? (int)$data['toilette_id'] : 0;
$note = isset($data['note']) ? (int)$data['note'] : 0;
$proprete = isset($data['proprete']) ? (int)$data['proprete'] : 0;
$commentaire = isset($data['commentaire']) ? trim($data['commentaire']) : '';

// ---- Validation de base ----
// toilette_id doit être > 0
// note doit être entre 1 et 5
if ($toilette_id <= 0 || $note < 1 || $note > 5) {
    echo json_encode(array('success' => false, 'message' => 'Données invalides'));
    exit();
}

// ========================================
// 5. AJOUT OU MISE À JOUR DE L'AVIS
// ========================================
try {
    // ---- Vérifier si l'utilisateur a déjà un avis pour cette toilette ----
    // Un utilisateur ne peut avoir qu'un seul avis par toilette
    $stmt = $pdo->prepare("SELECT id FROM avis WHERE user_id = ? AND toilette_id = ?");
    $stmt->execute(array($user_id, $toilette_id));
    $existing = $stmt->fetch();

    if ($existing) {
        // ---- L'avis existe déjà → Mise à jour ----
        $stmt = $pdo->prepare("
            UPDATE avis SET note = ?, proprete = ?, commentaire = ?, updated_at = NOW()
            WHERE id = ?
        ");
        $stmt->execute(array($note, $proprete, $commentaire, $existing['id']));
        $message = 'Avis mis à jour';
    } else {
        // ---- Pas d'avis existant → Insertion ----
        $stmt = $pdo->prepare("
            INSERT INTO avis (user_id, toilette_id, note, proprete, commentaire, created_at)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute(array($user_id, $toilette_id, $note, $proprete, $commentaire));
        $message = 'Avis ajouté';
    }

    // ========================================
    // 6. RECALCUL DES STATISTIQUES
    // ========================================
    // Après ajout/modification, recalculer les moyennes pour la toilette

    // ---- Calculer les nouvelles moyennes ----
    // COALESCE retourne 0 si aucun avis (évite NULL)
    $statsStmt = $pdo->prepare("
        SELECT
            COALESCE(AVG(note), 0) as avg_note,
            COUNT(*) as total_avis,
            COALESCE(AVG(proprete), 0) as avg_proprete
        FROM avis
        WHERE toilette_id = ? AND is_visible = 1
    ");
    $statsStmt->execute(array($toilette_id));
    $stats = $statsStmt->fetch(PDO::FETCH_ASSOC);

    // Arrondir les moyennes à 2 décimales
    $avgNote = isset($stats['avg_note']) ? round((float)$stats['avg_note'], 2) : 0;
    $avgProprete = isset($stats['avg_proprete']) ? round((float)$stats['avg_proprete'], 2) : 0;
    $totalAvis = isset($stats['total_avis']) ? (int)$stats['total_avis'] : 0;

    // ---- Mettre à jour la table toilettes ----
    // Persister les statistiques pour éviter de recalculer à chaque affichage
    $updateStmt = $pdo->prepare("
        UPDATE toilettes
        SET note_moyenne = ?, nombre_avis = ?, updated_at = NOW()
        WHERE id = ?
    ");
    $updateStmt->execute(array($avgNote, $totalAvis, $toilette_id));

    // ========================================
    // 7. RÉPONSE JSON
    // ========================================
    echo json_encode(array(
        'success' => true,
        'message' => $message,
        'stats' => array(
            'note_moyenne' => $avgNote,
            'nombre_avis' => $totalAvis,
            'proprete_moyenne' => $avgProprete
        )
    ));

} catch (Exception $e) {
    // ========================================
    // 8. GESTION DES ERREURS
    // ========================================
    error_log('Add avis error: ' . $e->getMessage());
    echo json_encode(array('success' => false, 'message' => 'Erreur serveur'));
}
?>
