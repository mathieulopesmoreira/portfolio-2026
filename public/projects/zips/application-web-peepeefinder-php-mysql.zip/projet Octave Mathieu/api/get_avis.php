<?php
/**
 * ========================================
 * API REST - RÉCUPÉRATION DES AVIS
 * ========================================
 *
 * Fichier: api/get_avis.php
 * Description: Récupère tous les avis (reviews) d'une toilette spécifique
 *
 * Méthode HTTP: GET
 * Format de sortie: JSON
 * Authentification: Optionnelle
 *
 * Paramètres GET:
 * - toilette_id (requis): ID de la toilette
 *
 * Fonctionnalités:
 * - Récupérer tous les avis visibles d'une toilette
 * - Joindre le username de l'auteur
 * - Trier par date (plus récent en premier)
 * - Calculer les statistiques globales (note moyenne, propreté moyenne, total)
 * - Récupérer l'avis de l'utilisateur connecté (s'il existe)
 * - Indiquer si l'utilisateur peut modifier chaque avis (can_edit)
 *
 * Réponse JSON (succès):
 * {
 *   "success": true,
 *   "count": 15,
 *   "data": [
 *     {
 *       "id": 42,
 *       "username": "JohnDoe",
 *       "note": 4,
 *       "proprete": 5,
 *       "commentaire": "Très propre!",
 *       "created_at": "2024-01-15 14:30:00",
 *       "can_edit": false
 *     },
 *     ...
 *   ],
 *   "stats": {
 *     "note_moyenne": 4.2,
 *     "proprete_moyenne": 4.5,
 *     "nombre_avis": 15
 *   },
 *   "user_review": {
 *     "id": 67,
 *     "note": 5,
 *     "proprete": 4,
 *     "commentaire": "Mon avis"
 *   }
 * }
 *
 * @author PeePeeFinder Team
 * @version 1.0
 */

// ========================================
// 1. INITIALISATION
// ========================================
session_start();
require_once '../includes/db.php';

// Header JSON
header('Content-Type: application/json; charset=utf-8');

// ========================================
// 2. VALIDATION DES PARAMÈTRES
// ========================================
// Récupérer l'ID de la toilette depuis les paramètres GET
$toilette_id = isset($_GET['toilette_id']) ? (int)$_GET['toilette_id'] : 0;

// Validation: ID doit être > 0
if ($toilette_id <= 0) {
    echo json_encode(array('success' => false, 'message' => 'ID invalide'));
    exit();
}

// ========================================
// 3. RÉCUPÉRATION DES AVIS
// ========================================
try {
    // ---- Requête SQL: Avis avec username de l'auteur ----
    // JOIN users pour récupérer le nom d'utilisateur
    // Filtrer uniquement les avis visibles (is_visible = 1)
    // Trier par date de création (plus récent en premier)
    $stmt = $pdo->prepare("
        SELECT a.*, u.username
        FROM avis a
        JOIN users u ON a.user_id = u.id
        WHERE a.toilette_id = ? AND a.is_visible = 1
        ORDER BY a.created_at DESC
    ");
    $stmt->execute(array($toilette_id));
    $avis = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // ---- Formater les données ----
    // Convertir les types et ajouter can_edit (permission de modification)
    $formatted = array();
    foreach ($avis as $av) {
        $formatted[] = array(
            'id' => (int)$av['id'],
            'username' => $av['username'],
            'note' => (int)$av['note'],              // Note générale (1-5)
            'proprete' => (int)$av['proprete'],      // Note de propreté (1-5)
            'commentaire' => $av['commentaire'],
            'created_at' => $av['created_at'],
            // L'utilisateur peut modifier uniquement son propre avis
            'can_edit' => isset($_SESSION['user_id']) && $_SESSION['user_id'] == $av['user_id']
        );
    }

    // ========================================
    // 4. CALCUL DES STATISTIQUES GLOBALES
    // ========================================
    // Calculer les moyennes et le total pour cette toilette
    $statsStmt = $pdo->prepare("
        SELECT
            COALESCE(AVG(note), 0) as avg_note,
            COALESCE(AVG(proprete), 0) as avg_proprete,
            COUNT(*) as total
        FROM avis
        WHERE toilette_id = ? AND is_visible = 1
    ");
    $statsStmt->execute(array($toilette_id));
    $stats = $statsStmt->fetch(PDO::FETCH_ASSOC);

    // Formater les statistiques (arrondir à 2 décimales)
    $avgNote = isset($stats['avg_note']) ? round((float)$stats['avg_note'], 2) : 0;
    $avgProprete = isset($stats['avg_proprete']) ? round((float)$stats['avg_proprete'], 2) : 0;
    $totalAvis = isset($stats['total']) ? (int)$stats['total'] : 0;

    // ========================================
    // 5. RÉCUPÉRATION DE L'AVIS UTILISATEUR
    // ========================================
    // Si l'utilisateur est connecté, récupérer son avis personnel (s'il existe)
    // Permet d'afficher "Vous avez déjà noté cette toilette"
    $userReview = null;
    if (isset($_SESSION['user_id'])) {
        $userStmt = $pdo->prepare("
            SELECT id, note, proprete, commentaire
            FROM avis
            WHERE toilette_id = ? AND user_id = ? AND is_visible = 1
            LIMIT 1
        ");
        $userStmt->execute(array($toilette_id, $_SESSION['user_id']));
        $userReview = $userStmt->fetch(PDO::FETCH_ASSOC);

        // Si un avis existe, le formater
        if ($userReview) {
            $userReview = array(
                'id' => (int)$userReview['id'],
                'note' => (int)$userReview['note'],
                'proprete' => (int)$userReview['proprete'],
                'commentaire' => $userReview['commentaire']
            );
        }
    }

    // ========================================
    // 6. RÉPONSE JSON
    // ========================================
    echo json_encode(array(
        'success' => true,
        'count' => count($formatted),
        'data' => $formatted,
        'stats' => array(
            'note_moyenne' => $avgNote,
            'proprete_moyenne' => $avgProprete,
            'nombre_avis' => $totalAvis
        ),
        'user_review' => $userReview  // null si non connecté ou pas d'avis
    ));

} catch (Exception $e) {
    // ========================================
    // 7. GESTION DES ERREURS
    // ========================================
    error_log("Get avis error: " . $e->getMessage());
    echo json_encode(array('success' => false, 'message' => 'Erreur serveur'));
}
?>
