<?php
/**
 * ========================================
 * API REST - TOGGLE MODE SOMBRE
 * ========================================
 *
 * Fichier: api/toggle_dark_mode.php
 * Description: Bascule le mode sombre/clair pour l'utilisateur connecté
 *
 * Méthode HTTP: POST
 * Format de sortie: JSON
 * Authentification: Requise
 *
 * Fonctionnalités:
 * - Récupérer l'état actuel du mode sombre
 * - Inverser l'état (dark → light ou light → dark)
 * - Mettre à jour la base de données
 * - Mettre à jour la session
 * - Retourner le nouvel état
 *
 * Réponse JSON (succès):
 * {
 *   "success": true,
 *   "dark_mode": true,
 *   "message": "Mode sombre activé"
 * }
 *
 * Réponse JSON (erreur):
 * {
 *   "success": false,
 *   "message": "Non connecté"
 * }
 *
 * @author PeePeeFinder Team
 * @version 1.0
 */

// ========================================
// 1. INITIALISATION
// ========================================
session_start();
require_once '../includes/db.php';

// Header JSON
header('Content-Type: application/json; charset=utf-8');

// ========================================
// 2. VÉRIFICATION AUTHENTIFICATION
// ========================================
// Seuls les utilisateurs connectés peuvent changer leur préférence de thème
if (!isset($_SESSION['user_id'])) {
    echo json_encode(array(
        'success' => false,
        'message' => 'Non connecté'
    ));
    exit();
}

// ========================================
// 3. TOGGLE DU MODE SOMBRE
// ========================================
try {
    $user_id = $_SESSION['user_id'];

    // ---- Récupérer l'état actuel du mode sombre ----
    // La colonne dark_mode stocke 0 (light) ou 1 (dark)
    $stmt = $pdo->prepare("SELECT dark_mode FROM users WHERE id = ?");
    $stmt->execute(array($user_id));
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // ---- Vérifier que l'utilisateur existe ----
    if (!$user) {
        throw new Exception('Utilisateur introuvable');
    }

    // ---- Inverser l'état du mode sombre ----
    // Si dark_mode = 1 (dark), passer à 0 (light)
    // Si dark_mode = 0 (light), passer à 1 (dark)
    $new_state = $user['dark_mode'] ? 0 : 1;

    // ---- Mettre à jour en base de données ----
    // Persister la préférence pour les futures sessions
    $stmt = $pdo->prepare("UPDATE users SET dark_mode = ? WHERE id = ?");
    $stmt->execute(array($new_state, $user_id));

    // ---- Mettre à jour la session ----
    // Appliquer immédiatement le changement sans recharger
    $_SESSION['dark_mode'] = (bool)$new_state;

    // ---- Réponse JSON avec le nouvel état ----
    echo json_encode(array(
        'success' => true,
        'dark_mode' => (bool)$new_state,
        'message' => 'Mode sombre ' . ($new_state ? 'activé' : 'désactivé')
    ));

} catch (Exception $e) {
    // ========================================
    // 4. GESTION DES ERREURS
    // ========================================
    // Logger l'erreur sans l'exposer à l'utilisateur
    error_log("Toggle dark mode error: " . $e->getMessage());

    // Retourner une erreur JSON générique
    echo json_encode(array(
        'success' => false,
        'message' => 'Erreur lors du changement de mode'
    ));
}
?>
