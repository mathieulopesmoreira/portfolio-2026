<?php
/**
 * ========================================
 * API REST - RÉCUPÉRATION DES FAVORIS
 * ========================================
 *
 * Fichier: api/get_favorites.php
 * Description: Récupère la liste des toilettes favorites de l'utilisateur connecté
 *
 * Méthode HTTP: GET
 * Format de sortie: JSON
 * Authentification: Requise
 *
 * Fonctionnalités:
 * - Récupérer tous les favoris de l'utilisateur
 * - Joindre les informations de la toilette (nom, commune, PMR, etc.)
 * - Trier par date d'ajout (plus récent en premier)
 * - Extraire la liste des IDs pour faciliter les vérifications côté client
 * - Retourner le nombre total de favoris
 *
 * Réponse JSON (succès):
 * {
 *   "success": true,
 *   "count": 5,
 *   "favorite_ids": [12, 45, 67, ...],
 *   "favorites": [
 *     {
 *       "toilette_id": 12,
 *       "added_at": "2024-01-15 14:30:00",
 *       "nom": "Toilettes Publiques - Gare",
 *       "commune": "Paris",
 *       "acces_pmr": 1,
 *       "payant": 0,
 *       "note_moyenne": 4.5,
 *       "nombre_avis": 23
 *     },
 *     ...
 *   ]
 * }
 *
 * @author PeePeeFinder Team
 * @version 1.0
 */

// ========================================
// 1. INITIALISATION
// ========================================
session_start();
require_once '../includes/db.php';

// ========================================
// 2. HEADERS HTTP
// ========================================
// Headers JSON
header('Content-Type: application/json; charset=utf-8');

// Headers CORS (Cross-Origin Resource Sharing)
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// ========================================
// 3. GESTION PREFLIGHT CORS
// ========================================
// Gestion OPTIONS pour CORS (requête préliminaire des navigateurs)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// ========================================
// 4. VÉRIFICATION AUTHENTIFICATION
// ========================================
// Seuls les utilisateurs connectés ont des favoris
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'Non authentifié',
        'message' => 'Vous devez être connecté pour voir vos favoris'
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

// ========================================
// 5. RÉCUPÉRATION DES FAVORIS
// ========================================
try {
    $user_id = $_SESSION['user_id'];

    // ---- Requête SQL: Favoris avec informations des toilettes ----
    // LEFT JOIN pour garder les favoris même si la toilette n'existe plus
    // (permet de détecter les favoris orphelins)
    $stmt = $pdo->prepare("
        SELECT
            f.toilette_id,
            f.created_at as added_at,
            t.nom,
            t.commune,
            t.acces_pmr,
            t.payant,
            t.note_moyenne,
            t.nombre_avis
        FROM favorites f
        LEFT JOIN toilettes t ON f.toilette_id = t.id
        WHERE f.user_id = ?
        ORDER BY f.created_at DESC
    ");
    $stmt->execute([$user_id]);
    $favorites = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // ---- Extraire les IDs uniquement ----
    // Facilite la vérification côté client: "est-ce que toilette X est favorite?"
    // Permet d'utiliser: favorite_ids.includes(toilette_id)
    $favorite_ids = array_map(function($fav) {
        return (int)$fav['toilette_id'];
    }, $favorites);

    // ========================================
    // 6. RÉPONSE JSON
    // ========================================
    $response = [
        'success' => true,
        'count' => count($favorites),        // Nombre total de favoris
        'favorite_ids' => $favorite_ids,     // Liste des IDs uniquement
        'favorites' => $favorites            // Données complètes
    ];

    http_response_code(200);
    echo json_encode($response, JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    // ========================================
    // 7. GESTION DES ERREURS
    // ========================================
    // Logger l'erreur technique
    error_log("API Get Favorites Error: " . $e->getMessage());

    // Retourner une erreur JSON
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Erreur serveur',
        'message' => 'Impossible de récupérer les favoris',
        'debug' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>
