<?php
/**
 * API REST - Gestion des favoris (Ajouter/Retirer)
 * Endpoint: /api/toggle_favorite.php
 * Method: POST
 * Returns: JSON
 */

session_start();
require_once '../includes/db.php';

// Headers JSON
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Gestion OPTIONS pour CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Vérifier que l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'Non authentifié',
        'message' => 'Vous devez être connecté pour ajouter des favoris'
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

// Vérifier que c'est bien une requête POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Méthode non autorisée',
        'message' => 'Utilisez POST'
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

try {
    // Récupérer les données POST
    $raw_input = file_get_contents('php://input');
    $data = json_decode($raw_input, true);

    // Si pas de JSON, essayer $_POST
    if (!$data) {
        $data = $_POST;
    }

    // Log pour debug
    error_log("Toggle Favorite - User ID: " . $_SESSION['user_id'] . ", Raw Input: " . $raw_input);
    error_log("Toggle Favorite - Parsed Data: " . json_encode($data));

    // Validation
    if (!isset($data['toilette_id']) || !is_numeric($data['toilette_id'])) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => 'Données invalides',
            'message' => 'ID de toilette manquant ou invalide',
            'debug_data' => $data
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $user_id = $_SESSION['user_id'];
    $toilette_id = (int)$data['toilette_id'];

    // Vérifier que la toilette existe
    $stmt = $pdo->prepare("SELECT id FROM toilettes WHERE id = ?");
    $stmt->execute([$toilette_id]);
    $toilette = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$toilette) {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'error' => 'Toilette introuvable',
            'message' => 'Cette toilette n\'existe pas'
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    // Vérifier si le favori existe déjà
    $stmt = $pdo->prepare("SELECT id FROM favorites WHERE user_id = ? AND toilette_id = ?");
    $stmt->execute([$user_id, $toilette_id]);
    $existing = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existing) {
        // Le favori existe déjà, on le supprime (toggle)
        $stmt = $pdo->prepare("DELETE FROM favorites WHERE user_id = ? AND toilette_id = ?");
        $stmt->execute([$user_id, $toilette_id]);

        $response = [
            'success' => true,
            'action' => 'removed',
            'message' => 'Retiré des favoris',
            'is_favorite' => false
        ];
    } else {
        // Le favori n'existe pas, on l'ajoute
        $stmt = $pdo->prepare("INSERT INTO favorites (user_id, toilette_id, created_at) VALUES (?, ?, NOW())");
        $stmt->execute([$user_id, $toilette_id]);

        // Vérifier que l'insertion a réussi
        $inserted_id = $pdo->lastInsertId();
        error_log("Favorite Added - ID: " . $inserted_id . ", User: " . $user_id . ", Toilette: " . $toilette_id);

        $response = [
            'success' => true,
            'action' => 'added',
            'message' => 'Ajouté aux favoris',
            'is_favorite' => true,
            'inserted_id' => $inserted_id
        ];
    }

    // Compter le nombre total de favoris de l'utilisateur
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM favorites WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $count = $stmt->fetch(PDO::FETCH_ASSOC);
    $response['total_favorites'] = (int)$count['total'];

    http_response_code(200);
    echo json_encode($response, JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    error_log("API Toggle Favorite Error: " . $e->getMessage());

    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Erreur serveur',
        'message' => 'Impossible de modifier les favoris',
        'debug' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>
