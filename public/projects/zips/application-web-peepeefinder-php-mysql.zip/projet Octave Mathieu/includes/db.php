<?php
/**
 * ========================================
 * CONFIGURATION BASE DE DONNÉES
 * ========================================
 *
 * Fichier: includes/db.php
 * Description: Configuration et connexion à la base de données MySQL via PDO
 *
 * Responsabilités:
 * - Établir la connexion PDO à MySQL
 * - Configurer les paramètres PDO (mode erreur, fetch mode, timezone)
 * - Fournir des fonctions utilitaires pour les requêtes SQL
 * - Gérer les erreurs de connexion
 *
 * Configuration PDO:
 * - Mode d'erreur: ERRMODE_EXCEPTION (lance des exceptions en cas d'erreur)
 * - Mode de récupération par défaut: FETCH_ASSOC (tableau associatif)
 * - Fuseau horaire: UTC (+00:00)
 * - Charset: utf8mb4 (support complet d'Unicode, y compris emojis)
 *
 * Fonctions utilitaires:
 * - executeQuery(): Exécuter une requête préparée avec paramètres
 * - fetchOne(): Récupérer une seule ligne
 * - fetchAll(): Récupérer toutes les lignes
 * - countRows(): Compter les lignes d'une table
 *
 * Variables globales créées:
 * - $pdo: Instance PDO disponible dans tout le projet
 *
 * @author PeePeeFinder Team
 * @version 1.0
 */

// ========================================
// 1. CONNEXION À LA BASE DE DONNÉES
// ========================================
try {
    // ---- Créer une nouvelle instance PDO ----
    // Paramètres:
    // - Host: localhost (serveur MySQL local)
    // - Database: peepefinder
    // - Charset: utf8mb4 (UTF-8 complet avec support emoji)
    // - User: root
    // - Password: '' (vide pour environnement de développement local)
    $pdo = new PDO('mysql:host=localhost;dbname=peepefinder;charset=utf8mb4', 'root', '');

    // ---- Configuration PDO: Mode d'erreur ----
    // ERRMODE_EXCEPTION lance des exceptions en cas d'erreur SQL
    // Permet une meilleure gestion des erreurs avec try/catch
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // ---- Configuration PDO: Mode de récupération par défaut ----
    // FETCH_ASSOC retourne les résultats sous forme de tableau associatif
    // Exemple: ['id' => 1, 'nom' => 'Test'] au lieu de [0 => 1, 'id' => 1, 1 => 'Test', 'nom' => 'Test']
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    // ---- Définir le fuseau horaire ----
    // UTC (+00:00) pour cohérence avec les timestamps
    // Les dates seront stockées en UTC dans la base de données
    $pdo->exec("SET time_zone = '+00:00'");

} catch (Exception $e) {
    // ========================================
    // 2. GESTION DES ERREURS DE CONNEXION
    // ========================================
    // En cas d'échec de connexion, arrêter l'exécution avec un message d'erreur
    // die() arrête le script immédiatement
    die('Erreur de connexion à la base de données : ' . $e->getMessage());
}

// ========================================
// 3. FONCTIONS UTILITAIRES POUR REQUÊTES SQL
// ========================================

/**
 * Exécuter une requête préparée
 *
 * Cette fonction simplifie l'exécution de requêtes préparées avec paramètres.
 * Elle gère automatiquement la préparation et l'exécution.
 *
 * @param PDO $pdo Instance PDO
 * @param string $sql Requête SQL avec placeholders (?)
 * @param array $params Paramètres à binder (défaut: tableau vide)
 * @return PDOStatement Statement exécuté
 * @throws Exception En cas d'erreur SQL
 *
 * Exemple:
 * $stmt = executeQuery($pdo, "SELECT * FROM users WHERE id = ?", [42]);
 */
function executeQuery($pdo, $sql, $params = []) {
    try {
        // Préparer la requête (protection contre injections SQL)
        $stmt = $pdo->prepare($sql);

        // Exécuter avec les paramètres
        $stmt->execute($params);

        // Retourner le statement pour fetch ultérieur
        return $stmt;

    } catch (Exception $e) {
        // Logger l'erreur pour le débogage
        error_log("Query Error: " . $e->getMessage());

        // Relancer l'exception pour gestion par l'appelant
        throw $e;
    }
}

/**
 * Récupérer une seule ligne
 *
 * Exécute une requête et retourne la première ligne seulement.
 * Pratique pour les requêtes avec LIMIT 1 ou pour récupérer un seul enregistrement.
 *
 * @param PDO $pdo Instance PDO
 * @param string $sql Requête SQL
 * @param array $params Paramètres (défaut: tableau vide)
 * @return array|false Tableau associatif ou false si aucun résultat
 *
 * Exemple:
 * $user = fetchOne($pdo, "SELECT * FROM users WHERE id = ?", [42]);
 * if ($user) {
 *     echo $user['username'];
 * }
 */
function fetchOne($pdo, $sql, $params = []) {
    $stmt = executeQuery($pdo, $sql, $params);
    return $stmt->fetch();
}

/**
 * Récupérer toutes les lignes
 *
 * Exécute une requête et retourne toutes les lignes dans un tableau.
 * Chaque ligne est un tableau associatif.
 *
 * @param PDO $pdo Instance PDO
 * @param string $sql Requête SQL
 * @param array $params Paramètres (défaut: tableau vide)
 * @return array Tableau de tableaux associatifs
 *
 * Exemple:
 * $users = fetchAll($pdo, "SELECT * FROM users WHERE role = ?", ['admin']);
 * foreach ($users as $user) {
 *     echo $user['username'] . "\n";
 * }
 */
function fetchAll($pdo, $sql, $params = []) {
    $stmt = executeQuery($pdo, $sql, $params);
    return $stmt->fetchAll();
}

/**
 * Compter les lignes d'une table
 *
 * Simplifie le comptage avec une condition WHERE optionnelle.
 * Retourne un entier avec le nombre de lignes.
 *
 * @param PDO $pdo Instance PDO
 * @param string $table Nom de la table
 * @param string $where Condition WHERE (optionnel, sans le mot "WHERE")
 * @param array $params Paramètres pour la condition WHERE (optionnel)
 * @return int Nombre de lignes
 *
 * Exemples:
 * // Compter tous les utilisateurs
 * $total = countRows($pdo, 'users');
 *
 * // Compter les admins
 * $admins = countRows($pdo, 'users', 'role = ?', ['admin']);
 *
 * // Compter les toilettes accessibles PMR
 * $pmr = countRows($pdo, 'toilettes', 'acces_pmr = 1');
 */
function countRows($pdo, $table, $where = '', $params = []) {
    // Construction de la requête SQL
    $sql = "SELECT COUNT(*) as count FROM " . $table;

    // Ajouter la condition WHERE si fournie
    if ($where) {
        $sql .= " WHERE " . $where;
    }

    // Exécuter et récupérer le résultat
    $result = fetchOne($pdo, $sql, $params);

    // Retourner le compte en tant qu'entier
    return (int)$result['count'];
}
?>
