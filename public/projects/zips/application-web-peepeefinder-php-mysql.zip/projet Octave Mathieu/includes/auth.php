<?php
/**
 * ========================================
 * SYSTÈME D'AUTHENTIFICATION ET AUTORISATIONS
 * ========================================
 *
 * Fichier: includes/auth.php
 * Description: Système complet de gestion d'authentification et de permissions
 *
 * Responsabilités:
 * - Vérifier l'état de connexion des utilisateurs
 * - Gérer les permissions et rôles (user/admin)
 * - Protéger les pages nécessitant une authentification
 * - Valider la sécurité des sessions (anti-hijacking)
 * - Gérer les messages flash (erreurs/succès)
 * - Fournir des fonctions CSRF pour la sécurité
 *
 * Fonctions principales:
 * - isLoggedIn(): Vérifier si utilisateur connecté
 * - isAdmin(): Vérifier si utilisateur est admin
 * - requireLogin(): Forcer la connexion (redirige sinon)
 * - requireAdmin(): Forcer le rôle admin (redirige sinon)
 * - hasPermission(): Vérifier une permission spécifique
 * - validateSession(): Valider la sécurité de la session
 * - initSession(): Initialiser la session lors de la connexion
 * - refreshSessionData(): Rafraîchir les données de session depuis la DB
 * - canAccess(): Vérifier l'accès à une ressource
 * - generateCsrfToken(): Générer un token CSRF
 * - verifyCsrfToken(): Vérifier un token CSRF
 * - Flash messages: getFlashError(), getFlashSuccess(), setFlashError(), setFlashSuccess()
 *
 * Sécurité implémentée:
 * - Validation du User-Agent (détection de hijacking)
 * - Régénération périodique de l'ID de session (toutes les heures)
 * - Protection CSRF avec tokens sécurisés (random_bytes)
 * - Vérification hash_equals pour comparaisons sécurisées
 * - Stockage sécurisé des données en session
 *
 * Permissions par défaut:
 * - Admin: Toutes les permissions
 * - User: view_map, view_dashboard, add_avis, add_favorite, report_issue
 *
 * @author PeePeeFinder Team
 * @version 1.0
 */

// ========================================
// 1. FONCTIONS DE VÉRIFICATION D'ÉTAT
// ========================================

/**
 * Vérifier si l'utilisateur est connecté
 *
 * Vérifie la présence d'un user_id non vide en session.
 *
 * @return bool True si connecté, false sinon
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Vérifier si l'utilisateur est admin
 *
 * Vérifie que l'utilisateur est connecté ET que son rôle est 'admin'.
 *
 * @return bool True si admin, false sinon
 */
function isAdmin() {
    return isLoggedIn() && isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

/**
 * Obtenir l'ID de l'utilisateur connecté
 *
 * @return int|null ID utilisateur ou null si non connecté
 */
function getUserId() {
    return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
}

/**
 * Obtenir le nom d'utilisateur connecté
 *
 * @return string|null Username ou null si non connecté
 */
function getUsername() {
    return isset($_SESSION['username']) ? $_SESSION['username'] : null;
}

/**
 * Obtenir le rôle de l'utilisateur connecté
 *
 * @return string|null 'admin' ou 'user' ou null si non connecté
 */
function getUserRole() {
    return isset($_SESSION['role']) ? $_SESSION['role'] : null;
}

// ========================================
// 2. FONCTIONS DE PROTECTION DE PAGES
// ========================================

/**
 * Exiger que l'utilisateur soit connecté
 *
 * Redirige vers login.php si l'utilisateur n'est pas connecté.
 * Préserve l'URL de destination pour rediriger après connexion.
 *
 * @param string $redirect_url URL de redirection après connexion (optionnel)
 *
 * Exemple:
 * requireLogin(); // En haut de map.php, dashboard.php, etc.
 */
function requireLogin($redirect_url = '') {
    if (!isLoggedIn()) {
        // ---- Déterminer l'URL de redirection ----
        if (empty($redirect_url)) {
            // Par défaut, utiliser l'URL actuelle (avec query string)
            $redirect_url = $_SERVER['PHP_SELF'];
            if (!empty($_SERVER['QUERY_STRING'])) {
                $redirect_url .= '?' . $_SERVER['QUERY_STRING'];
            }
        }

        // ---- Rediriger vers la page de connexion ----
        // Le paramètre redirect permet de revenir à la page après connexion
        header('Location: login.php?redirect=' . urlencode($redirect_url));
        exit();
    }
}

/**
 * Exiger que l'utilisateur soit admin
 *
 * Vérifie d'abord que l'utilisateur est connecté, puis vérifie le rôle admin.
 * Redirige vers index.php si non admin.
 *
 * Exemple:
 * requireAdmin(); // En haut de import.php (page réservée aux admins)
 */
function requireAdmin() {
    // D'abord vérifier qu'il est connecté
    requireLogin();

    // Ensuite vérifier le rôle
    if (!isAdmin()) {
        // Stocker un message d'erreur en session
        $_SESSION['error'] = 'Accès refusé. Droits administrateur requis.';

        // Rediriger vers l'accueil
        header('Location: index.php');
        exit();
    }
}

// ========================================
// 3. SYSTÈME DE PERMISSIONS
// ========================================

/**
 * Vérifier si l'utilisateur possède une permission spécifique
 *
 * Système de permissions granulaires. Les admins ont toutes les permissions.
 * Les utilisateurs normaux ont un ensemble de permissions défini.
 *
 * @param string $permission Nom de la permission à vérifier
 * @return bool True si l'utilisateur a la permission, false sinon
 *
 * Permissions disponibles:
 * - view_map: Voir la carte
 * - view_dashboard: Voir le dashboard
 * - add_avis: Ajouter des avis
 * - add_favorite: Ajouter des favoris
 * - report_issue: Signaler un problème
 *
 * Exemple:
 * if (hasPermission('add_avis')) {
 *     // Afficher le formulaire d'avis
 * }
 */
function hasPermission($permission) {
    // ---- Admin a toutes les permissions ----
    if (isAdmin()) {
        return true;
    }

    // ---- Permissions spécifiques pour les utilisateurs normaux ----
    // À étendre avec un système de permissions granulaires si nécessaire
    $userPermissions = array(
        'view_map' => true,
        'view_dashboard' => true,
        'add_avis' => true,
        'add_favorite' => true,
        'report_issue' => true
    );

    return isset($userPermissions[$permission]) ? $userPermissions[$permission] : false;
}

// ========================================
// 4. GESTION DES SESSIONS
// ========================================

/**
 * Rafraîchir les données de session depuis la base de données
 *
 * Utile après modification du profil (changement username, email, etc.)
 * pour mettre à jour les données en session sans déconnecter l'utilisateur.
 *
 * @param PDO $pdo Instance PDO
 * @return bool True si succès, false si échec ou non connecté
 *
 * Exemple:
 * // Après mise à jour du profil
 * refreshSessionData($pdo);
 */
function refreshSessionData($pdo) {
    if (!isLoggedIn()) {
        return false;
    }

    try {
        // Récupérer les données utilisateur fraîches depuis la DB
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? LIMIT 1");
        $stmt->execute(array(getUserId()));
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // Mettre à jour les données en session
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['dark_mode'] = (bool)$user['dark_mode'];
            return true;
        }
    } catch (Exception $e) {
        error_log("Session refresh error: " . $e->getMessage());
    }

    return false;
}

/**
 * Déconnecter l'utilisateur
 *
 * Détruit la session et les cookies associés.
 * N'utilise PAS de redirection (à gérer par l'appelant).
 *
 * Note: logout.php utilise sa propre logique de déconnexion.
 * Cette fonction est disponible pour usage interne si nécessaire.
 */
function logout() {
    // Détruire les variables de session
    $_SESSION = array();

    // Détruire le cookie de session
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time() - 3600, '/');
    }

    // Détruire le cookie "remember me" si présent
    if (isset($_COOKIE['remember_token'])) {
        setcookie('remember_token', '', time() - 3600, '/');
    }

    // Détruire la session
    session_destroy();
}

/**
 * Vérifier la validité de la session (protection contre hijacking)
 *
 * Valide que la session n'a pas été compromise en vérifiant:
 * - Le User-Agent n'a pas changé
 * - Régénère l'ID de session toutes les heures
 *
 * @return bool True si session valide, false sinon
 *
 * Note: Cette fonction est appelée automatiquement à la fin de ce fichier.
 */
function validateSession() {
    if (!isLoggedIn()) {
        return false;
    }

    // ---- Vérifier l'IP (désactivé car problématique avec IP dynamiques) ----
    // Si l'utilisateur change de réseau, il serait déconnecté
    // if (isset($_SESSION['ip']) && $_SESSION['ip'] !== $_SERVER['REMOTE_ADDR']) {
    //     logout();
    //     return false;
    // }

    // ---- Vérifier le User-Agent ----
    // Si le User-Agent change, c'est suspect (potentiel hijacking)
    if (isset($_SESSION['user_agent']) && $_SESSION['user_agent'] !== $_SERVER['HTTP_USER_AGENT']) {
        logout();
        return false;
    }

    // ---- Régénérer l'ID de session périodiquement (sécurité) ----
    // Toutes les heures, pour limiter la fenêtre de vulnérabilité
    if (!isset($_SESSION['last_regeneration'])) {
        $_SESSION['last_regeneration'] = time();
    } elseif (time() - $_SESSION['last_regeneration'] > 3600) { // 3600 secondes = 1 heure
        session_regenerate_id(true);  // true = supprime l'ancien fichier de session
        $_SESSION['last_regeneration'] = time();
    }

    return true;
}

/**
 * Initialiser les données de session lors de la connexion
 *
 * Appelée par login.php après authentification réussie.
 * Initialise toutes les données de session et régénère l'ID.
 *
 * @param array $user Données utilisateur de la base de données
 *
 * Exemple (dans login.php):
 * if (password_verify($password, $user['password_hash'])) {
 *     initSession($user);
 *     header('Location: map.php');
 * }
 */
function initSession($user) {
    // Stocker les données utilisateur en session
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['dark_mode'] = (bool)$user['dark_mode'];

    // Stocker les données de sécurité
    $_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
    $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
    $_SESSION['last_regeneration'] = time();

    // Régénérer l'ID de session pour sécurité (protection fixation de session)
    session_regenerate_id(true);
}

// ========================================
// 5. CONTRÔLE D'ACCÈS AUX RESSOURCES
// ========================================

/**
 * Vérifier si l'utilisateur peut accéder à une ressource
 *
 * Vérifie si l'utilisateur est propriétaire de la ressource ou admin.
 *
 * @param int $resource_user_id ID du propriétaire de la ressource
 * @return bool True si accès autorisé, false sinon
 *
 * Exemple:
 * // Vérifier si l'utilisateur peut modifier un avis
 * if (canAccess($avis['user_id'])) {
 *     // Afficher le bouton de modification
 * }
 */
function canAccess($resource_user_id) {
    // Admin peut tout voir et modifier
    if (isAdmin()) {
        return true;
    }

    // L'utilisateur peut accéder à ses propres ressources
    return isLoggedIn() && getUserId() == $resource_user_id;
}

// ========================================
// 6. PROTECTION CSRF (Cross-Site Request Forgery)
// ========================================

/**
 * Générer un token CSRF
 *
 * Génère un token sécurisé pour protéger contre les attaques CSRF.
 * Le token est stocké en session et doit être inclus dans les formulaires.
 *
 * @return string Token CSRF (64 caractères hexadécimaux)
 *
 * Exemple (dans un formulaire):
 * <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
 */
function generateCsrfToken() {
    if (!isset($_SESSION['csrf_token'])) {
        // Générer 32 octets aléatoires et les convertir en hexadécimal
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Vérifier un token CSRF
 *
 * Vérifie que le token fourni correspond au token en session.
 * Utilise hash_equals() pour comparaison sécurisée (protection timing attacks).
 *
 * @param string $token Token à vérifier
 * @return bool True si token valide, false sinon
 *
 * Exemple (traitement du formulaire):
 * if (!verifyCsrfToken($_POST['csrf_token'])) {
 *     die('Token CSRF invalide');
 * }
 */
function verifyCsrfToken($token) {
    if (!isset($_SESSION['csrf_token'])) {
        return false;
    }
    // hash_equals() évite les timing attacks
    return hash_equals($_SESSION['csrf_token'], $token);
}

// ========================================
// 7. MESSAGES FLASH (Notifications temporaires)
// ========================================

/**
 * Récupérer et supprimer un message d'erreur stocké en session
 *
 * Les messages flash sont affichés une seule fois puis supprimés.
 *
 * @return string|null Message d'erreur ou null si aucun
 *
 * Exemple:
 * $error = getFlashError();
 * if ($error) {
 *     echo '<div class="error">' . $error . '</div>';
 * }
 */
function getFlashError() {
    if (isset($_SESSION['error'])) {
        $error = $_SESSION['error'];
        unset($_SESSION['error']);
        return $error;
    }
    return null;
}

/**
 * Récupérer et supprimer un message de succès stocké en session
 *
 * @return string|null Message de succès ou null si aucun
 */
function getFlashSuccess() {
    if (isset($_SESSION['success'])) {
        $success = $_SESSION['success'];
        unset($_SESSION['success']);
        return $success;
    }
    return null;
}

/**
 * Définir un message flash d'erreur
 *
 * @param string $message Message d'erreur à afficher
 *
 * Exemple:
 * setFlashError('Email déjà utilisé');
 * header('Location: register.php');
 */
function setFlashError($message) {
    $_SESSION['error'] = $message;
}

/**
 * Définir un message flash de succès
 *
 * @param string $message Message de succès à afficher
 *
 * Exemple:
 * setFlashSuccess('Profil mis à jour avec succès');
 * header('Location: profil.php');
 */
function setFlashSuccess($message) {
    $_SESSION['success'] = $message;
}

// ========================================
// 8. VALIDATION AUTOMATIQUE DE SESSION
// ========================================
// Valider automatiquement la session à chaque chargement de page
// Cela détecte les sessions compromises et les neutralise
if (session_status() === PHP_SESSION_ACTIVE) {
    validateSession();
}
?>
