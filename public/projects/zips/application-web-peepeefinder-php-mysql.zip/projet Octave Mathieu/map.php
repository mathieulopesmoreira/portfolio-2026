<?php
/**
 * ========================================
 * PAGE CARTE INTERACTIVE (MAP)
 * ========================================
 *
 * Fichier: map.php
 * Description: Carte interactive affichant toutes les toilettes publiques avec filtres et informations détaillées
 *
 * **AUTHENTIFICATION REQUISE**
 *
 * Fonctionnalités principales:
 * - Carte interactive basée sur Leaflet.js (OpenStreetMap)
 * - Affichage de toutes les toilettes avec markers cliquables
 * - Panneau latéral avec filtres avancés
 * - Barre de recherche textuelle (nom, adresse, commune)
 * - Géolocalisation de l'utilisateur (avec permission)
 * - Popups détaillées pour chaque toilette
 * - Système de favoris (cœur rouge/gris)
 * - Système d'avis avec notes et commentaires
 * - Clustering des markers pour performance
 * - Interface responsive (mobile/desktop)
 * - Mode sombre/clair
 * - Liste des résultats synchronisée avec la carte
 *
 * Filtres disponibles:
 * - Accessibilité PMR (Personnes à Mobilité Réduite)
 * - Toilettes gratuites / payantes
 * - Ouverture 24/7
 * - Type de toilette (public, automatique, etc.)
 * - Commune (recherche)
 * - Note minimum (1-5 étoiles)
 * - Recherche textuelle (nom, adresse, commune)
 *
 * Bibliothèques utilisées:
 * - Leaflet.js: Bibliothèque de cartes interactives open-source
 * - OpenStreetMap: Tuiles de carte (tiles)
 * - Leaflet.markercluster: Clustering des markers pour performance
 * - Feather Icons: Icônes SVG pour l'interface
 * - Tailwind CSS: Framework CSS utility-first
 *
 * Markers et icônes:
 * - Marker standard: Icône bleue pour les toilettes normales
 * - Marker PMR: Icône verte pour les toilettes accessibles PMR
 * - Marker sélectionné: Icône rouge pour la toilette actuellement consultée
 * - User location: Icône bleue pulsante pour la position de l'utilisateur
 *
 * Popups (fenêtres d'information):
 * - Nom de la toilette
 * - Adresse complète
 * - Commune et code postal
 * - Badges: PMR, Gratuit/Payant, 24/7
 * - Note moyenne avec étoiles
 * - Nombre d'avis
 * - Bouton favoris (toggle)
 * - Horaires d'ouverture
 * - Bouton "Voir les détails" (ouvre modal)
 *
 * Modal de détails:
 * - Toutes les informations de la toilette
 * - Liste complète des avis avec notes
 * - Formulaire d'ajout d'avis (note + propreté + commentaire)
 * - Statistiques (note moyenne, propreté moyenne)
 * - Bouton de fermeture
 *
 * API appelées:
 * - GET /api/toilettes.php: Récupérer toutes les toilettes avec filtres
 * - POST /api/toggle_favorite.php: Ajouter/retirer des favoris
 * - GET /api/get_avis.php: Récupérer les avis d'une toilette
 * - POST /api/add_avis.php: Ajouter/modifier un avis
 * - GET /api/get_favorites.php: Récupérer les favoris de l'utilisateur
 *
 * Fonctionnalités avancées:
 * - Clustering automatique: Groupe les markers proches pour performance
 * - Dezoom automatique: Si <10 résultats, ajuste le zoom pour tout afficher
 * - Compteur de résultats: Affiche le nombre de toilettes trouvées
 * - Liste scrollable: Panneau latéral avec liste des résultats
 * - Synchronisation carte/liste: Cliquer sur un item dans la liste centre la carte
 * - Geolocation HTML5: Localise l'utilisateur avec son accord
 * - Responsive design: S'adapte mobile/tablette/desktop
 * - Mode sombre: Ajuste les couleurs de la carte et de l'interface
 *
 * Sécurité:
 * - Protection par requireLogin() (utilisateurs connectés uniquement)
 * - Échappement HTML des données affichées
 * - Validation des entrées utilisateur (filtres, recherche)
 * - Protection CSRF pour les actions (favoris, avis)
 * - Limitation des requêtes API côté serveur
 *
 * Performance:
 * - Clustering des markers (Leaflet.markercluster)
 * - Chargement asynchrone des données (AJAX)
 * - Cache des favoris côté client
 * - Debouncing de la recherche textuelle
 * - Lazy loading des avis (chargés à la demande)
 *
 * Tables utilisées:
 * - toilettes: Données principales des toilettes
 * - favorites: Favoris de l'utilisateur
 * - avis: Avis et notes des toilettes
 * - users: Informations utilisateur pour les avis
 *
 * @author PeePeeFinder Team
 * @version 1.0
 */

// ========================================
// 1. INITIALISATION ET SÉCURITÉ
// ========================================
session_start();

// Inclusions
require_once 'includes/db.php';
require_once 'includes/auth.php';

// ---- Protection : utilisateur doit être connecté ----
// Redirige vers login.php si non connecté
requireLogin();

// ========================================
// 2. CONFIGURATION ET VARIABLES
// ========================================

// ---- Gestion de la langue ----
$lang = isset($_SESSION['lang']) ? $_SESSION['lang'] : 'fr';

// ---- Informations utilisateur ----
$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$role = $_SESSION['role'];
$dark_mode = isset($_SESSION['dark_mode']) ? $_SESSION['dark_mode'] : false;

// Récupérer quelques statistiques rapides
try {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM toilettes");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $total_toilettes = $result['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM toilettes WHERE acces_pmr = 1");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $total_pmr = $result['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM toilettes WHERE payant = 0");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $total_gratuit = $result['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM toilettes WHERE ouvert_24_7 = 1");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $total_24_7 = $result['total'];
} catch (Exception $e) {
    error_log("Stats error: " . $e->getMessage());
    $total_toilettes = $total_pmr = $total_gratuit = $total_24_7 = 0;
}
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" data-theme="<?php echo $dark_mode ? 'dark' : 'light'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $lang === 'fr' ? 'Carte des toilettes' : 'Toilets map'; ?> - PeePeeFinder</title>
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico">
    <link rel="stylesheet" href="assets/css/app.css">
    <script src="assets/js/app.js" defer></script>
    
    <!-- Leaflet CSS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css" />
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/feather-icons"></script>
    
    <style>
        #map { 
            height: calc(100vh - 140px);
            min-height: 500px;
        }
        
        .filter-panel {
            transition: transform 0.3s ease;
            max-height: calc(100vh - 160px);
            overflow-y: auto;
        }
        
        .filter-panel.collapsed {
            transform: translateX(-100%);
        }
        
        .filter-toggle {
            position: absolute;
            right: -40px;
            top: 20px;
            background: white;
            border-radius: 0 8px 8px 0;
            padding: 12px 8px;
            box-shadow: 2px 2px 8px rgba(0,0,0,0.15);
            cursor: pointer;
            z-index: 1000;
            transition: all 0.3s ease;
        }
        
        .filter-toggle:hover {
            background: #f3f4f6;
        }
        
        [data-theme="dark"] .filter-toggle {
            background: #374151;
            color: white;
        }
        
        [data-theme="dark"] .filter-toggle:hover {
            background: #4b5563;
        }
        
        /* Remove footer gap on map page */
        .site-footer {
            margin-top: 0;
        }
        
        .stats-card {
            transition: all 0.3s ease;
        }
        
        .stats-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.55);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 2000;
            padding: 1.5rem;
        }
        
        .modal-overlay.active {
            display: flex;
        }
        
        .modal-content {
            width: 100%;
            max-width: 720px;
            background: #ffffff;
            border-radius: 16px;
            box-shadow: 0 20px 45px rgba(15, 23, 42, 0.25);
            overflow: hidden;
        }
        
        [data-theme="dark"] .modal-content {
            background: #1f2937;
            color: #f9fafb;
        }
        
        [data-theme="dark"] .modal-content .text-gray-800 {
            color: #f9fafb !important;
        }
        
        [data-theme="dark"] .modal-content .text-gray-700 {
            color: #e5e7eb !important;
        }
        
        [data-theme="dark"] .modal-content .text-gray-600 {
            color: #d1d5db !important;
        }
        
        [data-theme="dark"] .modal-content .text-gray-500 {
            color: #9ca3af !important;
        }
        
        [data-theme="dark"] .modal-content .border-gray-200 {
            border-color: #374151 !important;
        }
        
        .avis-list {
            max-height: 260px;
            overflow-y: auto;
        }
        
        .badge-note {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: #2563eb;
            color: #ffffff;
            border-radius: 9999px;
            padding: 6px 12px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        
        [data-theme="dark"] .badge-note {
            background: #3b82f6;
        }
        
        .avis-stars {
            font-family: 'Segoe UI', sans-serif;
            letter-spacing: 2px;
            color: #f59e0b;
        }
        
        /* Custom marker popup styles */
        .leaflet-popup-content {
            margin: 0;
            min-width: 250px;
        }
        
        .toilet-popup {
            padding: 0;
        }
        
        .toilet-popup-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px;
            border-radius: 4px 4px 0 0;
        }
        
        .toilet-popup-body {
            padding: 12px;
        }
        
        .badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 500;
            margin: 2px;
        }
        
        .badge-pmr {
            background: #d1fae5;
            color: #065f46;
        }
        
        .badge-gratuit {
            background: #dbeafe;
            color: #1e40af;
        }
        
        .badge-payant {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .badge-24-7 {
            background: #fef3c7;
            color: #92400e;
        }
        
        .search-box {
            position: absolute;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1000;
            width: 90%;
            max-width: 520px;
        }
        
        .geolocation-btn {
            position: absolute;
            bottom: 120px;
            right: 20px;
            z-index: 1000;
            background: white;
            border-radius: 8px;
            padding: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .geolocation-btn:hover {
            background: #f3f4f6;
            transform: scale(1.05);
        }
        
        [data-theme="dark"] .geolocation-btn {
            background: #374151;
            color: white;
        }
        
        /* Dark mode styles */
        [data-theme="dark"] {
            background-color: #111827;
            color: #f9fafb;
        }
        
        [data-theme="dark"] .bg-white {
            background-color: #1f2937 !important;
        }
        
        [data-theme="dark"] .text-gray-800 {
            color: #f9fafb !important;
        }
        
        [data-theme="dark"] .text-gray-700 {
            color: #e5e7eb !important;
        }
        
        [data-theme="dark"] .text-gray-600 {
            color: #d1d5db !important;
        }
        
        [data-theme="dark"] .border-gray-300 {
            border-color: #4b5563 !important;
        }
        
        [data-theme="dark"] input, 
        [data-theme="dark"] select {
            background-color: #374151 !important;
            color: #f9fafb !important;
            border-color: #4b5563 !important;
        }
        
        .loading-spinner {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 9999;
        }
        
        .loading-spinner.active {
            display: block;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .spinner {
            border: 4px solid #f3f4f6;
            border-top: 4px solid #3b82f6;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
        }

        @media (max-width: 767px) {
            #filterPanel {
                position: fixed;
                top: 0;
                left: 0;
                bottom: 0;
                width: 85%;
                max-width: 320px;
                z-index: 3000;
                transform: translateX(-100%);
                transition: transform 0.3s ease-in-out;
                box-shadow: 4px 0 15px rgba(0,0,0,0.1);
                overflow-y: auto;
                border-radius: 0;
            }
            #filterPanel.open {
                transform: translateX(0);
            }
            .filter-overlay {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0,0,0,0.5);
                z-index: 2999;
                display: none;
                opacity: 0;
                transition: opacity 0.3s ease-in-out;
            }
            .filter-overlay.active {
                display: block;
                opacity: 1;
            }
            #map {
                /* The header + stats bar is around 120-140px */
                height: calc(100vh - 120px);
            }
            .geolocation-btn {
                bottom: 20px;
                right: 20px;
            }
            #filterToggleButton {
                bottom: 80px; /* Above geolocation button */
                right: 20px;
            }
        }
    </style>
</head>
<body class="font-sans antialiased bg-gray-50">
    <!-- Header -->
    <header class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div class="flex justify-between items-center nav-wrapper">
                <a href="index.php" class="text-xl font-bold text-blue-600 flex items-center">
                        <span class="text-2xl mr-2">🚽</span>
                        PeePeeFinder
                    </a>

                
                <div class="flex items-center space-x-3 md:space-x-4">
                    <button
                        class="mobile-nav-toggle md:hidden"
                        type="button"
                        aria-controls="primary-navigation"
                        aria-expanded="false"
                        aria-label="<?php echo $lang === 'fr' ? 'Ouvrir le menu' : 'Open menu'; ?>"
                        data-open-label="<?php echo $lang === 'fr' ? 'Ouvrir le menu' : 'Open menu'; ?>"
                        data-close-label="<?php echo $lang === 'fr' ? 'Fermer le menu' : 'Close menu'; ?>"
                    >
                        <i data-feather="menu" class="icon-menu"></i>
                        <i data-feather="x" class="icon-close"></i>
                    </button>

                    <nav id="primary-navigation" class="hidden md:flex items-center space-x-4 mobile-nav">
                        <a href="map.php" class="text-blue-600 hover:text-blue-700 flex items-center font-medium">
                            <i data-feather="map" class="w-4 h-4 mr-1"></i>
                            <?php echo $lang === 'fr' ? 'Carte' : 'Map'; ?>
                        </a>
                        <a href="dashboard.php" class="text-gray-600 hover:text-blue-600 flex items-center">
                            <i data-feather="bar-chart-2" class="w-4 h-4 mr-1"></i>
                            Dashboard
                        </a>
                        <?php if ($role === 'admin'): ?>
                            <a href="import.php" class="text-gray-600 hover:text-blue-600 flex items-center">
                                <i data-feather="upload" class="w-4 h-4 mr-1"></i>
                                Import
                            </a>
                        <?php endif; ?>
                    </nav>
                    <!-- Dark mode toggle -->
                    <button id="darkModeToggle" class="p-2 rounded-lg hover:bg-gray-100 transition duration-200">
                        <i data-feather="<?php echo $dark_mode ? 'sun' : 'moon'; ?>" class="w-5 h-5"></i>
                    </button>
                    
                    <!-- Language toggle -->
                    <button onclick="window.location.href='?lang=<?php echo $lang === 'fr' ? 'en' : 'fr'; ?>'" 
                            class="p-2 rounded-lg hover:bg-gray-100 transition duration-200">
                        <i data-feather="globe" class="w-5 h-5"></i>
                    </button>
                    
                    <!-- User menu -->
                    <div class="flex items-center space-x-2">
                        <a href="profil.php" class="text-gray-700 hover:text-blue-600 flex items-center">
                            <i data-feather="user" class="w-4 h-4 mr-1"></i>
                            <span class="hidden sm:inline"><?php echo htmlspecialchars($username); ?></span>
                        </a>
                        <a href="logout.php" class="px-3 py-1 bg-red-500 text-white rounded-lg hover:bg-red-600 transition duration-200 text-sm">
                            <?php echo $lang === 'fr' ? 'Déconnexion' : 'Logout'; ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Quick stats bar -->
    <div class="bg-white border-b py-3 px-4 stats-bar-container">
        <div class="max-w-7xl mx-auto stats-wrapper">
            <div class="stats-bar flex flex-wrap gap-4 justify-center md:justify-start">
                <div class="stats-card flex items-center gap-2 px-4 py-2 bg-blue-50 rounded-lg">
                    <i data-feather="map-pin" class="w-4 h-4 text-blue-600"></i>
                    <span class="stats-label text-sm font-medium text-gray-700">
                        <strong class="text-blue-600"><?php echo number_format($total_toilettes); ?></strong>
                        <?php echo $lang === 'fr' ? 'toilettes' : 'toilets'; ?>
                    </span>
                </div>
                <div class="stats-card flex items-center gap-2 px-4 py-2 bg-green-50 rounded-lg">
                    <span class="text-lg" aria-hidden="true">♿</span>
                    <span class="stats-label text-sm font-medium text-gray-700">
                        <strong class="text-green-600"><?php echo number_format($total_pmr); ?></strong>
                        PMR
                    </span>
                </div>
                <div class="stats-card flex items-center gap-2 px-4 py-2 bg-purple-50 rounded-lg">
                    <i data-feather="dollar-sign" class="w-4 h-4 text-purple-600" style="text-decoration: line-through;"></i>
                    <span class="stats-label text-sm font-medium text-gray-700">
                        <strong class="text-purple-600"><?php echo number_format($total_gratuit); ?></strong>
                        <?php echo $lang === 'fr' ? 'gratuit' : 'free'; ?>
                    </span>
                </div>
                <div class="stats-card flex items-center gap-2 px-4 py-2 bg-yellow-50 rounded-lg">
                    <i data-feather="clock" class="w-4 h-4 text-yellow-600"></i>
                    <span class="stats-label text-sm font-medium text-gray-700">
                        <strong class="text-yellow-600"><?php echo number_format($total_24_7); ?></strong>
                        24/7
                    </span>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- Main content -->
    <main class="flex map-layout h-full relative">
        <div id="filterOverlay" class="filter-overlay"></div>
        <!-- Filter panel -->
        <div class="relative">
            <div id="filterPanel" class="filter-panel bg-white shadow-lg w-full md:w-80 p-6 relative">
                <h2 class="text-xl font-bold mb-4 text-gray-800 flex items-center justify-between">
                    <span class="flex items-center">
                        <i data-feather="filter" class="w-5 h-5 mr-2 text-blue-600"></i>
                        <?php echo $lang === 'fr' ? 'Filtres' : 'Filters'; ?>
                    </span>
                    <button id="closeFilterPanel" class="md:hidden text-gray-500 hover:text-gray-700">
                        <i data-feather="x" class="w-6 h-6"></i>
                    </button>
                </h2>
                
                <div class="space-y-4">
                    <!-- Accessibility filter -->
                    <div class="border-b pb-4">
                        <h3 class="font-medium text-gray-700 mb-2">
                            <?php echo $lang === 'fr' ? 'Accessibilité' : 'Accessibility'; ?>
                        </h3>
                        <label class="flex items-center space-x-2 cursor-pointer">
                            <input type="checkbox" id="pmrFilter" class="rounded text-blue-600 focus:ring-blue-500">
                            <span class="text-gray-700">♿ <?php echo $lang === 'fr' ? 'Accès PMR' : 'PMR Access'; ?></span>
                        </label>
                    </div>
                    
                    <!-- Price filter -->
                    <div class="border-b pb-4">
                        <h3 class="font-medium text-gray-700 mb-2">
                            <?php echo $lang === 'fr' ? 'Tarif' : 'Price'; ?>
                        </h3>
                        <label class="flex items-center space-x-2 cursor-pointer">
                            <input type="checkbox" id="freeFilter" class="rounded text-blue-600 focus:ring-blue-500">
                            <span class="text-gray-700">💚 <?php echo $lang === 'fr' ? 'Gratuit uniquement' : 'Free only'; ?></span>
                        </label>
                    </div>

                    <?php if (isset($_SESSION['user_id'])): ?>
                    <!-- Favorites filter -->
                    <div class="border-b pb-4">
                        <h3 class="font-medium text-gray-700 mb-2">
                            <?php echo $lang === 'fr' ? 'Mes favoris' : 'My favorites'; ?>
                        </h3>
                        <label class="flex items-center space-x-2 cursor-pointer">
                            <input type="checkbox" id="favoritesFilter" class="rounded text-blue-600 focus:ring-blue-500">
                            <span class="text-gray-700">❤️ <?php echo $lang === 'fr' ? 'Favoris uniquement' : 'Favorites only'; ?></span>
                        </label>
                    </div>
                    <?php endif; ?>

                    <!-- Opening hours filter -->
                    <div class="border-b pb-4">
                        <h3 class="font-medium text-gray-700 mb-2">
                            <?php echo $lang === 'fr' ? 'Horaires' : 'Hours'; ?>
                        </h3>
                        <div class="space-y-2">
                            <label class="flex items-center space-x-2 cursor-pointer">
                                <input type="radio" name="horairesFilter" value="all" class="text-blue-600 focus:ring-blue-500" checked>
                                <span class="text-gray-700"><?php echo $lang === 'fr' ? 'Tous' : 'All'; ?></span>
                            </label>
                            <label class="flex items-center space-x-2 cursor-pointer">
                                <input type="radio" name="horairesFilter" value="open_24_7" class="text-blue-600 focus:ring-blue-500">
                                <span class="text-gray-700">⏰ <?php echo $lang === 'fr' ? 'Ouvert 24/7' : 'Open 24/7'; ?></span>
                            </label>
                            <label class="flex items-center space-x-2 cursor-pointer">
                                <input type="radio" name="horairesFilter" value="limited" class="text-blue-600 focus:ring-blue-500">
                                <span class="text-gray-700">🕒 <?php echo $lang === 'fr' ? 'Horaires limités' : 'Limited hours'; ?></span>
                            </label>
                            <label class="flex items-center space-x-2 cursor-pointer">
                                <input type="radio" name="horairesFilter" value="unknown" class="text-blue-600 focus:ring-blue-500">
                                <span class="text-gray-700">❓ <?php echo $lang === 'fr' ? 'Horaires non renseignés' : 'Unknown hours'; ?></span>
                            </label>
                        </div>
                    </div>
                    
                    <!-- Type filter -->
                    <div class="border-b pb-4">
                        <h3 class="font-medium text-gray-700 mb-2">
                            <?php echo $lang === 'fr' ? 'Type' : 'Type'; ?>
                        </h3>
                        <select id="typeFilter" class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500">
                            <option value="all"><?php echo $lang === 'fr' ? 'Tous types' : 'All types'; ?></option>
                            <option value="sanisette">Sanisette</option>
                            <option value="toilettes_publiques"><?php echo $lang === 'fr' ? 'Toilettes publiques' : 'Public toilets'; ?></option>
                            <option value="autres"><?php echo $lang === 'fr' ? 'Autres' : 'Others'; ?></option>
                        </select>
                    </div>
                    
                    <!-- Rating filter -->
                    <div class="border-b pb-4">
                        <h3 class="font-medium text-gray-700 mb-2">
                            ⭐ <?php echo $lang === 'fr' ? 'Note minimum' : 'Minimum rating'; ?>
                        </h3>
                        <select id="ratingFilter" class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500">
                            <option value="0"><?php echo $lang === 'fr' ? 'Toutes notes' : 'All ratings'; ?></option>
                            <option value="4">⭐⭐⭐⭐ (4+)</option>
                            <option value="3">⭐⭐⭐ (3+)</option>
                            <option value="2">⭐⭐ (2+)</option>
                        </select>
                    </div>
                    
                    <!-- Search by commune -->
                    <div class="pb-4">
                        <h3 class="font-medium text-gray-700 mb-2">
                            🏙️ <?php echo $lang === 'fr' ? 'Commune' : 'City'; ?>
                        </h3>
                        <input 
                            type="text" 
                            id="communeFilter" 
                            placeholder="<?php echo $lang === 'fr' ? 'Ex: Paris, Versailles...' : 'Ex: Paris, Versailles...'; ?>"
                            class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        >
                    </div>
                    
                    <!-- Action buttons -->
                    <div class="space-y-2 pt-4">
                        <button id="applyFilters" class="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition duration-200 flex items-center justify-center font-medium">
                            <i data-feather="check" class="w-4 h-4 mr-2"></i>
                            <?php echo $lang === 'fr' ? 'Appliquer les filtres' : 'Apply filters'; ?>
                        </button>
                        <button id="resetFilters" class="w-full bg-gray-200 text-gray-800 py-3 px-4 rounded-lg hover:bg-gray-300 transition duration-200 flex items-center justify-center font-medium">
                            <i data-feather="x" class="w-4 h-4 mr-2"></i>
                            <?php echo $lang === 'fr' ? 'Réinitialiser' : 'Reset'; ?>
                        </button>
                    </div>
                    
                    <!-- Results counter -->
                    <div class="text-center pt-4 border-t">
                        <p class="text-sm text-gray-600">
                            <span id="resultsCount">0</span> <?php echo $lang === 'fr' ? 'résultat(s)' : 'result(s)'; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Map container -->
        <div class="flex-1 relative">
            <!-- Search box -->
            <div class="search-box">
                <div class="search-controls">
                    <div class="relative search-input-wrapper">
                        <input 
                            type="text" 
                            id="searchBox" 
                            placeholder="<?php echo $lang === 'fr' ? 'Rechercher une adresse...' : 'Search for an address...'; ?>"
                            class="w-full px-4 py-3 pl-12 pr-12 rounded-lg shadow-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        >
                        <i data-feather="search" class="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5"></i>
                        <button id="clearSearch" class="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 hidden">
                            <i data-feather="x" class="w-5 h-5"></i>
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Filter toggle button for mobile -->
            <button id="filterToggleButton" class="md:hidden absolute right-5 z-[1000] bg-white p-3 rounded-lg shadow-lg flex items-center justify-center" title="<?php echo $lang === 'fr' ? 'Afficher les filtres' : 'Show filters'; ?>">
                <i data-feather="filter" class="w-5 h-5 text-blue-600"></i>
            </button>

            <!-- Geolocation button -->
            <button id="geolocateBtn" class="geolocation-btn" title="<?php echo $lang === 'fr' ? 'Me localiser' : 'Locate me'; ?>">
                <i data-feather="navigation" class="w-5 h-5 text-blue-600"></i>
            </button>
            
            <!-- Map -->
            <div id="map"></div>
        </div>
    </main>

    <!-- Avis modal -->
    <div id="avisModal" class="modal-overlay">
        <div class="modal-content">
            <div class="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
                <div>
                    <p class="text-xs uppercase tracking-wide text-gray-500">
                        <?php echo $lang === 'fr' ? 'Avis' : 'Reviews'; ?>
                    </p>
                    <h3 class="text-lg font-semibold" id="avisToiletName"></h3>
                </div>
                <button id="closeAvisModal" class="text-gray-400 hover:text-gray-600 focus:outline-none">
                    <i data-feather="x" class="w-5 h-5"></i>
                </button>
            </div>
            <div class="px-6 py-5 space-y-6">
                <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div class="flex items-center gap-3">
                        <div class="badge-note" id="avisAverageBadge">
                            <span id="avisAverageValue">0</span>/5
                        </div>
                        <div class="text-sm text-gray-600" id="avisCountLabel">
                            0 <?php echo $lang === 'fr' ? 'avis' : 'reviews'; ?>
                        </div>
                    </div>
                    <div class="text-sm text-gray-500" id="avisPropreteLabel"></div>
                </div>
                <div class="avis-list space-y-3" id="avisList">
                    <!-- Avis items will be injected here -->
                </div>
                <div id="avisEmptyState" class="hidden text-sm text-gray-500 text-center py-6">
                    <?php echo $lang === 'fr' 
                        ? 'Aucun avis pour le moment. Soyez le premier à partager votre expérience !'
                        : 'No reviews yet. Be the first to share your experience!'; ?>
                </div>
                <div id="avisFeedback" class="hidden text-sm font-medium px-4 py-3 rounded-lg"></div>
                <form id="avisForm" class="space-y-4">
                    <input type="hidden" id="avisToiletId" name="toilette_id">
                    <div>
                        <label for="avisNote" class="block text-sm font-medium text-gray-700">
                            <?php echo $lang === 'fr' ? 'Note globale' : 'Overall rating'; ?>
                        </label>
                        <select id="avisNote" class="mt-1 w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-blue-500 focus:border-blue-500">
                            <option value=""><?php echo $lang === 'fr' ? 'Choisissez une note' : 'Choose a rating'; ?></option>
                            <option value="5">5</option>
                            <option value="4">4</option>
                            <option value="3">3</option>
                            <option value="2">2</option>
                            <option value="1">1</option>
                        </select>
                    </div>
                    <div>
                        <label for="avisProprete" class="block text-sm font-medium text-gray-700">
                            <?php echo $lang === 'fr' ? 'Propreté' : 'Cleanliness'; ?> (<?php echo $lang === 'fr' ? 'optionnel' : 'optional'; ?>)
                        </label>
                        <select id="avisProprete" class="mt-1 w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-blue-500 focus:border-blue-500">
                            <option value=""><?php echo $lang === 'fr' ? 'Pas d\'évaluation' : 'No rating'; ?></option>
                            <option value="5">5</option>
                            <option value="4">4</option>
                            <option value="3">3</option>
                            <option value="2">2</option>
                            <option value="1">1</option>
                        </select>
                    </div>
                    <div>
                        <label for="avisCommentaire" class="block text-sm font-medium text-gray-700">
                            <?php echo $lang === 'fr' ? 'Commentaire' : 'Comment'; ?>
                        </label>
                        <textarea id="avisCommentaire" rows="3" class="mt-1 w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-blue-500 focus:border-blue-500" placeholder="<?php echo $lang === 'fr' ? 'Partagez votre expérience...' : 'Share your experience...'; ?>"></textarea>
                    </div>
                    <button type="submit" id="avisSubmitBtn" class="w-full bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 transition">
                        <?php echo $lang === 'fr' ? 'Publier l\'avis' : 'Submit review'; ?>
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Loading spinner -->
    <div class="loading-spinner" id="loadingSpinner">
        <div class="spinner"></div>
    </div>

    <!-- Leaflet JS -->
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js"></script>
    
    <!-- Custom JS -->
    <script>
        // Configuration
        var API_URL = 'api/toilettes.php';
        var lang = '<?php echo $lang; ?>';
        var userLocation = { lat: null, lng: null };
        var isLoggedIn = <?php echo isset($_SESSION['user_id']) ? 'true' : 'false'; ?>;
        var reverseGeocodeCache = {};
        
        // Avis modal elements
        var avisModal = document.getElementById('avisModal');
        var avisListContainer = document.getElementById('avisList');
        var avisEmptyState = document.getElementById('avisEmptyState');
        var avisFeedback = document.getElementById('avisFeedback');
        var avisAverageValue = document.getElementById('avisAverageValue');
        var avisCountLabel = document.getElementById('avisCountLabel');
        var avisPropreteLabel = document.getElementById('avisPropreteLabel');
        var avisToiletIdInput = document.getElementById('avisToiletId');
        var avisToiletName = document.getElementById('avisToiletName');
        var avisForm = document.getElementById('avisForm');
        var avisNoteInput = document.getElementById('avisNote');
        var avisPropreteInput = document.getElementById('avisProprete');
        var avisCommentaireInput = document.getElementById('avisCommentaire');
        var avisSubmitBtn = document.getElementById('avisSubmitBtn');
        var closeAvisModalBtn = document.getElementById('closeAvisModal');
        var currentAvisToiletId = null;
        
        function renderStars(value) {
            var stars = '';
            for (var i = 1; i <= 5; i++) {
                stars += i <= value ? '★' : '☆';
            }
            return '<span class="avis-stars">' + stars + '</span>';
        }
        
        function formatDate(dateString) {
            if (!dateString) return '';
            var normalized = dateString.replace(' ', 'T');
            var date = new Date(normalized);
            if (isNaN(date.getTime())) {
                return dateString;
            }
            var options = {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            };
            var locale = lang === 'fr' ? 'fr-FR' : 'en-US';
            return date.toLocaleDateString(locale, options);
        }
        
        function updateAvisStats(stats) {
            var total = stats && typeof stats.nombre_avis !== 'undefined' ? stats.nombre_avis : 0;
            var average = stats && typeof stats.note_moyenne !== 'undefined' ? stats.note_moyenne : 0;
            var avgProprete = stats && typeof stats.proprete_moyenne !== 'undefined' ? stats.proprete_moyenne : 0;
            
            avisAverageValue.textContent = average.toFixed(2);
            var label = lang === 'fr' ? 'avis' : 'reviews';
            avisCountLabel.textContent = total + ' ' + label;
            
            if (avgProprete > 0) {
                avisPropreteLabel.textContent = (lang === 'fr' ? 'Propreté moyenne:' : 'Average cleanliness:') + ' ' + avgProprete.toFixed(2) + '/5';
                avisPropreteLabel.classList.remove('hidden');
            } else {
                avisPropreteLabel.textContent = '';
                avisPropreteLabel.classList.add('hidden');
            }
        }
        
        function buildAvisItem(avis) {
            var wrapper = document.createElement('div');
            wrapper.className = 'border border-gray-200 rounded-lg p-4 shadow-sm';
            
            var header = document.createElement('div');
            header.className = 'flex items-center justify-between mb-2';
            
            var left = document.createElement('div');
            left.className = 'font-semibold text-gray-800';
            left.textContent = avis.username;
            
            var right = document.createElement('div');
            right.className = 'text-sm text-gray-500';
            right.textContent = formatDate(avis.created_at);
            
            header.appendChild(left);
            header.appendChild(right);
            
            var rating = document.createElement('div');
            rating.innerHTML = renderStars(avis.note) + ' <span class="ml-2 text-sm text-gray-600">(' + avis.note + '/5)</span>';
            
            var body = document.createElement('p');
            body.className = 'text-sm text-gray-700 mt-2';
            body.textContent = avis.commentaire || (lang === 'fr' ? 'Pas de commentaire.' : 'No comment.');
            
            wrapper.appendChild(header);
            wrapper.appendChild(rating);
            
            if (avis.proprete && avis.proprete > 0) {
                var proprete = document.createElement('div');
                proprete.className = 'text-xs text-gray-500 mt-1';
                proprete.textContent = (lang === 'fr' ? 'Propreté:' : 'Cleanliness:') + ' ' + avis.proprete + '/5';
                wrapper.appendChild(proprete);
            }
            
            wrapper.appendChild(body);
            return wrapper;
        }
        
        function populateAvisList(items) {
            avisListContainer.innerHTML = '';
            if (!items || items.length === 0) {
                avisEmptyState.classList.remove('hidden');
                return;
            }
            avisEmptyState.classList.add('hidden');
            items.forEach(function(item) {
                avisListContainer.appendChild(buildAvisItem(item));
            });
        }
        
        function resetAvisFeedback() {
            avisFeedback.classList.add('hidden');
            avisFeedback.textContent = '';
            avisFeedback.classList.remove('bg-green-100', 'text-green-700', 'bg-red-100', 'text-red-700');
        }
        
        function showAvisFeedback(success, message) {
            avisFeedback.textContent = message;
            avisFeedback.classList.remove('hidden');
            if (success) {
                avisFeedback.classList.add('bg-green-100', 'text-green-700');
                avisFeedback.classList.remove('bg-red-100', 'text-red-700');
            } else {
                avisFeedback.classList.add('bg-red-100', 'text-red-700');
                avisFeedback.classList.remove('bg-green-100', 'text-green-700');
            }
        }
        
        // Initialize map
        var map = L.map('map').setView([48.8566, 2.3522], 12);
        
        // Add tile layer
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
            maxZoom: 19
        }).addTo(map);
        
        // Marker cluster group
        var markers = L.markerClusterGroup({
            chunkedLoading: true,
            spiderfyOnMaxZoom: true,
            showCoverageOnHover: false,
            zoomToBoundsOnClick: true
        });
        
        var allToilets = [];
        var userMarker = null;
        
        // Load toilets data
        function loadToilets() {
            showLoading(true);
            
            fetch(API_URL, { cache: 'no-store' })
                .then(function(response) { return response.json(); })
                .then(function(data) {
                    if (data.success) {
                        allToilets = data.data;
                        displayToilets(allToilets);
                        updateResultsCount(allToilets.length);
                    } else {
                        alert(lang === 'fr' ? 'Erreur de chargement des données' : 'Error loading data');
                    }
                    showLoading(false);
                })
                .catch(function(error) {
                    console.error('Error:', error);
                    alert(lang === 'fr' ? 'Erreur de connexion' : 'Connection error');
                    showLoading(false);
                });
        }
        
        // Display toilets on map
        function displayToilets(toilets) {
            markers.clearLayers();
            
            toilets.forEach(function(toilet) {
                var iconColor = toilet.acces_pmr ? '#10b981' : '#3b82f6';
                var icon = L.divIcon({
                    className: 'custom-marker',
                    html: '<div style="background: ' + iconColor + '; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3);"><span style="font-size: 16px;">🚽</span></div>',
                    iconSize: [30, 30],
                    iconAnchor: [15, 15]
                });
                
                var marker = L.marker([toilet.latitude, toilet.longitude], { icon: icon })
                    .bindPopup(createPopupContent(toilet));
                
                marker.toiletData = toilet;
                if (needsReverseGeocoding(toilet)) {
                    toilet.addressStatus = 'pending';
                }
                marker.on('popupopen', function(event) {
                    resolveToiletAddress(event.target.toiletData, event.target);
                });
                markers.addLayer(marker);
            });
            
            map.addLayer(markers);
        }
        
        function needsReverseGeocoding(toilet) {
            if (!toilet) return false;
            if (toilet.resolvedAddress) return false;
            if (toilet.addressStatus === 'loading' || toilet.addressStatus === 'loaded' || toilet.addressStatus === 'fallback') return false;
            var rawAddress = (toilet.adresse || '').toString().trim().toLowerCase();
            var hasLat = typeof toilet.latitude !== 'undefined' && toilet.latitude !== null && toilet.latitude !== '';
            var hasLng = typeof toilet.longitude !== 'undefined' && toilet.longitude !== null && toilet.longitude !== '';
            if (!rawAddress || rawAddress === '0' || rawAddress === '-' || rawAddress === 'n/a' || rawAddress === 'null' || rawAddress === 'adresse inconnue' || rawAddress === 'unknown') {
                return hasLat && hasLng;
            }
            return false;
        }
        
        function formatResolvedAddress(address) {
            if (!address) return '';
            return address.split(',').map(function(part) {
                return part.trim();
            }).filter(function(part) {
                return part.length > 0;
            }).slice(0, 4).join('<br>');
        }

        var invalidAddressValues = ['0', '-', 'n/a', 'na', 'null', ''];
        
        function isInvalidAddressValue(value) {
            if (typeof value === 'undefined' || value === null) {
                return true;
            }
            var normalized = value.toString().trim().toLowerCase();
            if (normalized === '') {
                return true;
            }
            return invalidAddressValues.indexOf(normalized) !== -1;
        }
        
        function applyCoordinateFallback(toilet) {
            var fallbackText = lang === 'fr' ? 'Adresse en cours de verification' : 'Address pending verification';
            toilet.addressStatus = 'fallback';
            toilet.resolvedAddress = '';
            if (!toilet.adresse || isInvalidAddressValue(toilet.adresse)) {
                toilet.adresse = fallbackText;
            }
        }
        
        function formatToiletAddress(toilet) {
            var loadingText = lang === 'fr' ? 'Recherche de l\'adresse...' : 'Looking up the address...';
            var fallbackText = lang === 'fr' ? 'Adresse en cours de verification' : 'Address pending verification';
            var unknownText = lang === 'fr' ? 'Adresse inconnue' : 'Address unknown';
            
            if (toilet.addressStatus === 'loading') {
                return '<span class="text-gray-500 italic">' + loadingText + '</span>';
            }
            if (toilet.addressStatus === 'fallback') {
                return '<span class="text-gray-500 italic">' + fallbackText + '</span>';
            }
            
            if (toilet.resolvedAddress) {
                var resolvedHtml = formatResolvedAddress(toilet.resolvedAddress);
                if (resolvedHtml) {
                    return resolvedHtml;
                }
            }
            
            var segments = [];
            var street = (toilet.adresse || '').toString().trim();
            var postalCode = (toilet.code_postal || '').toString().trim();
            var city = (toilet.commune || '').toString().trim();
            
            if (!isInvalidAddressValue(street)) {
                segments.push(street);
            }
            
            var cityLineParts = [];
            if (!isInvalidAddressValue(postalCode)) {
                cityLineParts.push(postalCode);
            }
            if (!isInvalidAddressValue(city)) {
                cityLineParts.push(city);
            }
            var cityLine = cityLineParts.join(' ');
            if (cityLine) {
                segments.push(cityLine);
            }
            
            if (segments.length) {
                return segments.join('<br>');
            }
            
            return '<span class="text-gray-500 italic">' + unknownText + '</span>';
        }
        
        function resolveToiletAddress(toilet, marker) {
            if (!needsReverseGeocoding(toilet)) {
                return;
            }
            var hasLat = typeof toilet.latitude !== 'undefined' && toilet.latitude !== null && toilet.latitude !== '';
            var hasLng = typeof toilet.longitude !== 'undefined' && toilet.longitude !== null && toilet.longitude !== '';
            if (!hasLat || !hasLng) {
                toilet.addressStatus = 'error';
                if (marker.getPopup()) {
                    marker.setPopupContent(createPopupContent(toilet));
                }
                return;
            }
            
            var latValue = parseFloat(toilet.latitude);
            var lngValue = parseFloat(toilet.longitude);
            if (isNaN(latValue) || isNaN(lngValue)) {
                toilet.addressStatus = 'error';
                if (marker.getPopup()) {
                    marker.setPopupContent(createPopupContent(toilet));
                }
                return;
            }
            
            var cacheKey = latValue.toFixed(6) + ',' + lngValue.toFixed(6);
            
            toilet.addressStatus = 'loading';
            if (marker.getPopup()) {
                marker.setPopupContent(createPopupContent(toilet));
            }
            
            reverseGeocode(cacheKey, latValue, lngValue)
                .then(function(address) {
                    if (address) {
                        toilet.resolvedAddress = address;
                        toilet.addressStatus = 'loaded';
                        if (!toilet.adresse || isInvalidAddressValue(toilet.adresse)) {
                            toilet.adresse = address;
                        }
                    } else {
                        applyCoordinateFallback(toilet);
                    }
                    if (marker.getPopup()) {
                        marker.setPopupContent(createPopupContent(toilet));
                    }
                })
                .catch(function() {
                    applyCoordinateFallback(toilet);
                    if (marker.getPopup()) {
                        marker.setPopupContent(createPopupContent(toilet));
                    }
                });
        }
        
        function reverseGeocode(cacheKey, latitude, longitude) {
            if (!reverseGeocodeCache[cacheKey]) {
                var language = lang === 'fr' ? 'fr' : 'en';
                var latParam = latitude.toString();
                var lngParam = longitude.toString();
                var url = 'https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=' + encodeURIComponent(latParam) +
                    '&lon=' + encodeURIComponent(lngParam) +
                    '&zoom=18&addressdetails=0&accept-language=' + language;
                
                reverseGeocodeCache[cacheKey] = fetch(url, {
                    headers: { 'Accept': 'application/json' }
                })
                    .then(function(response) {
                        if (!response.ok) {
                            throw new Error('Reverse geocoding failed with status ' + response.status);
                        }
                        return response.json();
                    })
                    .then(function(data) {
                        return data && data.display_name ? data.display_name : '';
                    })
                    .catch(function(error) {
                        delete reverseGeocodeCache[cacheKey];
                        throw error;
                    });
            }
            
            return reverseGeocodeCache[cacheKey];
        }
        
        // Determine if a toilet should be considered 24/7, even if the flag is missing
        function isOpen247(toilet) {
            if (toilet.ouvert_24_7) return true;
            
            var horaires = (toilet.horaires || '').toString().toLowerCase();
            if (!horaires) return false;
            
            var patterns = [
                /24\s*h\s*sur\s*24/,
                /24\s*heures?\s*sur\s*24/,
                /24\s*h\s*\/\s*24/,
                /24h\/24/,
                /24h24/,
                /24\s*\/\s*7/,
                /24-7/,
                /ouvert\s*24h/,
                /ouverture\s*24h/
            ];
            
            for (var i = 0; i < patterns.length; i++) {
                if (patterns[i].test(horaires)) {
                    return true;
                }
            }
            
            return false;
        }
        
        // Create popup content
        function createPopupContent(toilet) {
            var distance = userLocation.lat 
                ? calculateDistance(userLocation.lat, userLocation.lng, toilet.latitude, toilet.longitude)
                : null;
            
            var content = '<div class="toilet-popup">';
            content += '<div class="toilet-popup-header">';
            content += '<h3 class="font-bold text-lg">' + toilet.nom + '</h3>';
            if (toilet.note_moyenne > 0) {
                content += '<div class="text-sm mt-1">⭐ ' + toilet.note_moyenne + '/5 (' + toilet.nombre_avis + ' avis)</div>';
            }
            content += '</div>';
            content += '<div class="toilet-popup-body">';
            var addressLabel = lang === 'fr' ? 'Adresse : ' : 'Address: ';
            var addressHtml = formatToiletAddress(toilet);
            content += '<p class="text-gray-700 text-sm mb-2">' + addressLabel + addressHtml + '</p>';
            if (distance) {
                content += '<p class="text-gray-600 text-sm mb-2">📍 ' + distance.toFixed(2) + ' km</p>';
            }
            var open247 = isOpen247(toilet);
            var horaires_text = lang === 'fr' ? "Pas d'informations sur les horaires" : "No schedule information";
            if (toilet.horaires && toilet.horaires.trim() !== '' && toilet.horaires.trim() !== '0' && toilet.horaires.trim() !== '45862') {
                content += '<p class="text-gray-600 text-sm mb-2">🕒 ' + toilet.horaires + '</p>';
            } else if (!open247) {
                // N'afficher "pas d'info" que si ce n'est pas un 24/7
                content += '<p class="text-gray-500 text-sm italic mb-2">🕒 ' + horaires_text + '</p>';
            }
            content += '<div class="flex flex-wrap gap-1 mb-3">';
            if (toilet.acces_pmr) content += '<span class="badge badge-pmr">♿ PMR</span>';
            content += toilet.payant ? '<span class="badge badge-payant">💰 Payant</span>' : '<span class="badge badge-gratuit">💚 Gratuit</span>';
            if (open247) content += '<span class="badge badge-24-7">⏰ 24/7</span>';
            content += '</div>';
            content += '<div class="flex gap-2 mb-2">';
            content += '<a href="https://www.google.com/maps/dir/?api=1&destination=' + toilet.latitude + ',' + toilet.longitude + '" target="_blank" class="flex-1 bg-blue-600 text-white text-center py-2 px-3 rounded text-sm hover:bg-blue-700">📍 Itinéraire</a>';
            content += '<button onclick="showAvisModal(' + toilet.id + ')" class="flex-1 bg-green-600 text-white py-2 px-3 rounded text-sm hover:bg-green-700">⭐ Avis</button>';
            content += '</div>';
            // Bouton favori
            var isFavorite = toilet.is_favorite || false;
            var favoriteClass = isFavorite ? 'bg-red-500 hover:bg-red-600' : 'bg-gray-300 hover:bg-gray-400 text-gray-700';
            var favoriteIcon = isFavorite ? '❤️' : '🤍';
            var favoriteText = lang === 'fr' ? (isFavorite ? 'Retirer des favoris' : 'Ajouter aux favoris') : (isFavorite ? 'Remove from favorites' : 'Add to favorites');
            content += '<button onclick="toggleFavorite(' + toilet.id + ')" id="favorite-btn-' + toilet.id + '" class="w-full ' + favoriteClass + ' text-white py-2 px-3 rounded text-sm transition-colors">';
            content += favoriteIcon + ' ' + favoriteText;
            content += '</button>';
            content += '</div>';
            content += '</div>';
            
            return content;
        }
        
        // Calculate distance between two points (Haversine formula)
        function calculateDistance(lat1, lon1, lat2, lon2) {
            var R = 6371; // Earth radius in km
            var dLat = (lat2 - lat1) * Math.PI / 180;
            var dLon = (lon2 - lon1) * Math.PI / 180;
            var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                      Math.sin(dLon/2) * Math.sin(dLon/2);
            var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
            return R * c;
        }


        
        // Apply filters
        function applyFilters() {
            var pmr = document.getElementById('pmrFilter').checked;
            var free = document.getElementById('freeFilter').checked;
            var favoritesOnly = document.getElementById('favoritesFilter') ? document.getElementById('favoritesFilter').checked : false;
            var horaires = document.querySelector('input[name="horairesFilter"]:checked').value;
            var type = document.getElementById('typeFilter').value;
            var rating = parseFloat(document.getElementById('ratingFilter').value);
            var commune = document.getElementById('communeFilter').value.toLowerCase().trim();

            var filtered = allToilets.filter(function(toilet) {
                if (pmr && !toilet.acces_pmr) return false;
                if (free && toilet.payant) return false;
                if (favoritesOnly && !toilet.is_favorite) return false;
                
                // Logique de filtre horaire stricte
                var hasKnownHours = toilet.horaires && toilet.horaires.trim() !== '' && toilet.horaires.trim() !== '0' && toilet.horaires.trim() !== '45862';
                var open247 = isOpen247(toilet);

                if (horaires === 'open_24_7') {
                    if (!open247) return false;
                } else if (horaires === 'limited') {
                    // Doit avoir des horaires connus ET ne pas être 24/7
                    if (open247 || !hasKnownHours) return false;
                } else if (horaires === 'unknown') {
                    // Ne doit PAS avoir d'horaires connus ET ne pas être 24/7
                    if (hasKnownHours || open247) return false;
                }
                
                if (type !== 'all' && toilet.type !== type) return false;
                if (rating > 0 && toilet.note_moyenne < rating) return false;
                if (commune && toilet.commune.toLowerCase().indexOf(commune) === -1) return false;
                return true;
            });
            
            displayToilets(filtered);
            updateResultsCount(filtered.length);
        }
        
        // Reset filters
        function resetFilters() {
            document.getElementById('pmrFilter').checked = false;
            document.getElementById('freeFilter').checked = false;
            if (document.getElementById('favoritesFilter')) {
                document.getElementById('favoritesFilter').checked = false;
            }
            document.querySelector('input[name="horairesFilter"][value="all"]').checked = true;
            document.getElementById('typeFilter').value = 'all';
            document.getElementById('ratingFilter').value = '0';
            document.getElementById('communeFilter').value = '';

            displayToilets(allToilets);
            updateResultsCount(allToilets.length);
        }
        
        // Update results count
        function updateResultsCount(count) {
            document.getElementById('resultsCount').textContent = count;
        }
        
        // Show/hide loading spinner
        function showLoading(show) {
            var spinner = document.getElementById('loadingSpinner');
            if (show) {
                spinner.classList.add('active');
            } else {
                spinner.classList.remove('active');
            }
        }
        
        function showAvisModal(toiletId) {
            resetAvisFeedback();
            currentAvisToiletId = toiletId;
            avisToiletIdInput.value = toiletId;
            
            var toilet = allToilets.find(function(item) { return item.id === toiletId; });
            avisToiletName.textContent = toilet ? toilet.nom : '';
            
            if (avisModal) {
                avisModal.classList.add('active');
                document.body.classList.add('overflow-hidden');
            }
            
            loadAvis(toiletId);
        }
        
        function closeAvisModal() {
            if (avisModal) {
                avisModal.classList.remove('active');
                document.body.classList.remove('overflow-hidden');
            }
            resetAvisFeedback();
            currentAvisToiletId = null;
        }
        
        function loadAvis(toiletId) {
            if (!toiletId) return;
            showLoading(true);
            fetch('api/get_avis.php?toilette_id=' + toiletId)
                .then(function(response) { return response.json(); })
                .then(function(data) {
                    if (!data.success) {
                        showAvisFeedback(false, data.message || (lang === 'fr' ? 'Erreur de chargement des avis' : 'Unable to load reviews'));
                        return;
                    }
                    populateAvisList(data.data);
                    updateAvisStats(data.stats);
                    
                    if (data.user_review) {
                        avisNoteInput.value = data.user_review.note || '';
                        avisPropreteInput.value = data.user_review.proprete || '';
                        avisCommentaireInput.value = data.user_review.commentaire || '';
                        avisSubmitBtn.textContent = lang === 'fr' ? 'Mettre à jour l\'avis' : 'Update review';
                    } else {
                        avisNoteInput.value = '';
                        avisPropreteInput.value = '';
                        avisCommentaireInput.value = '';
                        avisSubmitBtn.textContent = lang === 'fr' ? 'Publier l\'avis' : 'Submit review';
                    }
                })
                .catch(function(error) {
                    console.error('Avis error:', error);
                    showAvisFeedback(false, lang === 'fr' ? 'Impossible de charger les avis' : 'Cannot load reviews');
                })
                .finally(function() {
                    showLoading(false);
                    feather.replace();
                });
        }
        
        // Geolocation
        document.getElementById('geolocateBtn').addEventListener('click', function() {
            if (!navigator.geolocation) {
                alert(lang === 'fr' ? 'Géolocalisation non supportée' : 'Geolocation not supported');
                return;
            }
            
            showLoading(true);
            
            navigator.geolocation.getCurrentPosition(
                function(position) {
                    userLocation.lat = position.coords.latitude;
                    userLocation.lng = position.coords.longitude;
                    
                    // Remove old marker
                    if (userMarker) {
                        map.removeLayer(userMarker);
                    }
                    
                    // Add user marker
                    var userIcon = L.divIcon({
                        className: 'user-marker',
                        html: '<div style="background: #ef4444; width: 20px; height: 20px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3);"></div>',
                        iconSize: [20, 20],
                        iconAnchor: [10, 10]
                    });
                    
                    userMarker = L.marker([userLocation.lat, userLocation.lng], { icon: userIcon })
                        .bindPopup(lang === 'fr' ? '📍 Vous êtes ici' : '📍 You are here')
                        .addTo(map);
                    
                    // Center map on user
                    map.setView([userLocation.lat, userLocation.lng], 15);
                    
                    // Refresh markers to show distances
                    displayToilets(allToilets);
                    
                    showLoading(false);
                },
                function(error) {
                    showLoading(false);
                    alert(lang === 'fr' ? 'Impossible de vous localiser' : 'Unable to locate you');
                    console.error('Geolocation error:', error);
                }
            );
        });
        // Event listeners
        document.getElementById('applyFilters').addEventListener('click', applyFilters);
        document.getElementById('resetFilters').addEventListener('click', resetFilters);
        closeAvisModalBtn.addEventListener('click', closeAvisModal);
        if (avisModal) {
            avisModal.addEventListener('click', function(e) {
                if (e.target === avisModal) {
                    closeAvisModal();
                }
            });
        }
        document.addEventListener('keydown', function(e) {
            if (e.key !== 'Escape') {
                return;
            }
            if (avisModal && avisModal.classList.contains('active')) {
                closeAvisModal();
                return;
            }
        });
        
        avisForm.addEventListener('submit', function(event) {
            event.preventDefault();
            resetAvisFeedback();
            
            if (!currentAvisToiletId) {
                showAvisFeedback(false, lang === 'fr' ? 'Sélection invalide' : 'Invalid selection');
                return;
            }
            
            var note = parseInt(avisNoteInput.value, 10);
            var proprete = avisPropreteInput.value ? parseInt(avisPropreteInput.value, 10) : 0;
            var commentaire = avisCommentaireInput.value.trim();
            
            if (!note || note < 1 || note > 5) {
                showAvisFeedback(false, lang === 'fr' ? 'Merci de choisir une note entre 1 et 5' : 'Please choose a rating between 1 and 5');
                return;
            }
            
            avisSubmitBtn.disabled = true;
            avisSubmitBtn.classList.add('opacity-60', 'cursor-not-allowed');
            
            fetch('api/add_avis.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    toilette_id: currentAvisToiletId,
                    note: note,
                    proprete: proprete,
                    commentaire: commentaire
                })
            })
            .then(function(response) { return response.json(); })
            .then(function(data) {
                if (!data.success) {
                    showAvisFeedback(false, data.message || (lang === 'fr' ? 'Impossible d\'enregistrer l\'avis' : 'Cannot save review'));
                    return;
                }
                
                showAvisFeedback(true, data.message || (lang === 'fr' ? 'Avis enregistré' : 'Review saved'));
                loadAvis(currentAvisToiletId);
                
                if (data.stats) {
                    var updated = allToilets.find(function(item) { return item.id === currentAvisToiletId; });
                    if (updated) {
                        updated.note_moyenne = data.stats.note_moyenne;
                        updated.nombre_avis = data.stats.nombre_avis;
                    }
                    applyFilters();
                }
            })
            .catch(function(error) {
                console.error('Save avis error:', error);
                showAvisFeedback(false, lang === 'fr' ? 'Erreur serveur' : 'Server error');
            })
            .finally(function() {
                avisSubmitBtn.disabled = false;
                avisSubmitBtn.classList.remove('opacity-60', 'cursor-not-allowed');
            });
        });
        
        // Search box functionality
        var searchBox = document.getElementById('searchBox');
        var clearSearch = document.getElementById('clearSearch');
        
        searchBox.addEventListener('input', function() {
            if (this.value.length > 0) {
                clearSearch.classList.remove('hidden');
            } else {
                clearSearch.classList.add('hidden');
            }
        });
        
        clearSearch.addEventListener('click', function() {
            searchBox.value = '';
            this.classList.add('hidden');
            searchBox.focus();
        });
        
        searchBox.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                var query = this.value.toLowerCase().trim();
                
                if (query) {
                    var found = allToilets.filter(function(toilet) {
                        return toilet.nom.toLowerCase().indexOf(query) !== -1 ||
                               toilet.adresse.toLowerCase().indexOf(query) !== -1 ||
                               toilet.commune.toLowerCase().indexOf(query) !== -1;
                    });
                    
                    if (found.length > 0) {
                        displayToilets(found);
                        updateResultsCount(found.length);
                        
                        // Zoom to first result
                        map.setView([found[0].latitude, found[0].longitude], 16);
                    } else {
                        alert(lang === 'fr' ? 'Aucun résultat trouvé' : 'No results found');
                    }
                }
            }
        });
        
        // Toggle favorite
        window.toggleFavorite = function(toiletId) {
            fetch('api/toggle_favorite.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ toilette_id: toiletId })
            })
            .then(function(response) { return response.json(); })
            .then(function(data) {
                if (data.success) {
                    // Mettre à jour l'état dans allToilets
                    var toilet = allToilets.find(function(t) { return t.id === toiletId; });
                    if (toilet) {
                        toilet.is_favorite = data.is_favorite;
                    }

                    // Mettre à jour le bouton
                    var btn = document.getElementById('favorite-btn-' + toiletId);
                    if (btn) {
                        var isFavorite = data.is_favorite;
                        var favoriteClass = isFavorite ? 'bg-red-500 hover:bg-red-600' : 'bg-gray-300 hover:bg-gray-400 text-gray-700';
                        var favoriteIcon = isFavorite ? '❤️' : '🤍';
                        var favoriteText = lang === 'fr' ? (isFavorite ? 'Retirer des favoris' : 'Ajouter aux favoris') : (isFavorite ? 'Remove from favorites' : 'Add to favorites');

                        btn.className = 'w-full ' + favoriteClass + ' text-white py-2 px-3 rounded text-sm transition-colors';
                        btn.innerHTML = favoriteIcon + ' ' + favoriteText;
                    }

                    // Afficher une notification
                    var message = lang === 'fr' ? data.message : (data.action === 'added' ? 'Added to favorites' : 'Removed from favorites');
                    showNotification(message, 'success');
                } else {
                    showNotification(data.message || (lang === 'fr' ? 'Erreur lors de la mise à jour' : 'Error updating favorites'), 'error');
                }
            })
            .catch(function(error) {
                console.error('Error:', error);
                showNotification(lang === 'fr' ? 'Erreur de connexion' : 'Connection error', 'error');
            });
        };

        // Fonction pour afficher une notification
        function showNotification(message, type) {
            // Créer l'élément de notification
            var notif = document.createElement('div');
            notif.className = 'fixed top-20 right-4 px-6 py-3 rounded-lg shadow-lg z-[9999] transition-opacity duration-300';
            notif.style.opacity = '0';

            if (type === 'success') {
                notif.className += ' bg-green-500 text-white';
            } else {
                notif.className += ' bg-red-500 text-white';
            }

            notif.textContent = message;
            document.body.appendChild(notif);

            // Fade in
            setTimeout(function() {
                notif.style.opacity = '1';
            }, 10);

            // Fade out et supprimer après 3 secondes
            setTimeout(function() {
                notif.style.opacity = '0';
                setTimeout(function() {
                    document.body.removeChild(notif);
                }, 300);
            }, 3000);
        }

        // Dark mode toggle
        document.getElementById('darkModeToggle').addEventListener('click', function() {
            fetch('api/toggle_dark_mode.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(function(response) { return response.json(); })
            .then(function(data) {
                if (data.success) {
                    location.reload();
                }
            })
            .catch(function(error) {
                console.error('Error:', error);
            });
        });
        
        // Initialize
        feather.replace();
        loadToilets();
        
        // Auto-refresh every 5 minutes
        setInterval(function() {
            loadToilets();
        }, 300000);
        
        // Refresh map on popup open
        map.on('popupopen', function() {
            feather.replace();
        });

        // Mobile filter panel logic
        var filterToggleButton = document.getElementById('filterToggleButton');
        var filterPanel = document.getElementById('filterPanel');
        var closeFilterPanel = document.getElementById('closeFilterPanel');
        var filterOverlay = document.getElementById('filterOverlay');

        if (filterToggleButton && filterPanel && closeFilterPanel && filterOverlay) {
            filterToggleButton.addEventListener('click', function() {
                filterPanel.classList.add('open');
                filterOverlay.classList.add('active');
                document.body.classList.add('overflow-hidden');
            });

            function closePanel() {
                filterPanel.classList.remove('open');
                filterOverlay.classList.remove('active');
                document.body.classList.remove('overflow-hidden');
            }

            closeFilterPanel.addEventListener('click', closePanel);
            filterOverlay.addEventListener('click', closePanel);
            
            document.getElementById('applyFilters').addEventListener('click', function() {
                if (window.innerWidth < 768) {
                    closePanel();
                }
            });
            
            document.getElementById('resetFilters').addEventListener('click', function() {
                if (window.innerWidth < 768) {
                    // Give a moment for the filters to reset before closing
                    setTimeout(closePanel, 100);
                }
            });
        }
    </script>
<?php include 'partials/footer.php'; ?>
</body>
</html>
