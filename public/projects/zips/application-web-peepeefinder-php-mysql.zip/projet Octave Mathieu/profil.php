<?php
/**
 * ========================================
 * PAGE DE PROFIL UTILISATEUR (PROFILE)
 * ========================================
 *
 * Fichier: profil.php
 * Description: Page de gestion du profil utilisateur avec statistiques et paramètres
 *
 * Fonctionnalités:
 * - Affichage des informations utilisateur (username, email, role)
 * - Statistiques personnelles (nombre d'avis, favoris, ancienneté)
 * - Modification des informations personnelles (username, email)
 * - Changement de mot de passe avec vérification
 * - Validation côté serveur des modifications
 * - Protection contre les doublons (username/email déjà utilisés)
 * - Support multilingue (FR/EN)
 * - Mode sombre/clair avec toggle
 * - Interface responsive et moderne
 *
 * Sécurité:
 * - Protection par authentification (requireLogin)
 * - Vérification du mot de passe actuel avant changement
 * - Hashage bcrypt des nouveaux mots de passe
 * - Validation des emails avec FILTER_VALIDATE_EMAIL
 * - Échappement HTML des sorties (htmlspecialchars)
 * - Protection contre les doublons d'username/email
 * - Headers de sécurité (no-cache, UTF-8)
 * - Prepared statements PDO contre injections SQL
 *
 * Tables utilisées:
 * - users: Lecture et modification des données utilisateur
 * - avis: Comptage des avis déposés par l'utilisateur
 * - favorites: Comptage des favoris avec vérification d'existence des toilettes
 *
 * @author PeePeeFinder Team
 * @version 1.0
 */

// ========================================
// 1. INITIALISATION ET SÉCURITÉ
// ========================================

// Démarrer la session pour accéder aux données utilisateur
session_start();

// ---- Headers de sécurité et optimisation ----
// UTF-8 pour l'affichage correct des caractères accentués
header('Content-Type: text/html; charset=utf-8');

// Désactiver le cache pour toujours afficher les données à jour
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

// Inclusion des fichiers de configuration
require_once 'includes/db.php';      // Connexion à la base de données PDO
require_once 'includes/auth.php';    // Fonctions d'authentification

// ---- Protection : utilisateur doit être connecté ----
// Redirection automatique vers login.php si non connecté
requireLogin();

// ========================================
// 2. GESTION DE LA LANGUE
// ========================================
// Récupérer la préférence de langue depuis la session (par défaut: français)
$lang = isset($_SESSION['lang']) ? $_SESSION['lang'] : 'fr';

// ========================================
// 3. INITIALISATION DES VARIABLES
// ========================================
$user_id = $_SESSION['user_id'];  // ID de l'utilisateur connecté
$errors = array();                 // Tableau pour stocker les erreurs de validation
$success = '';                     // Message de succès après modification

// ========================================
// 4. RÉCUPÉRATION DES DONNÉES UTILISATEUR
// ========================================
try {
    // ---- Charger les informations complètes de l'utilisateur ----
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute(array($user_id));
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Si l'utilisateur n'existe plus en base, déconnecter
    if (!$user) {
        header('Location: logout.php');
        exit();
    }

    // ---- Statistique 1: Nombre d'avis déposés ----
    // Compter tous les avis (reviews) créés par cet utilisateur
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM avis WHERE user_id = ?");
    $stmt->execute(array($user_id));
    $nb_avis = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

    // ---- Statistique 2: Nombre de favoris ----
    // Compter les favoris en vérifiant que la toilette existe encore (INNER JOIN)
    // Cela évite de compter des favoris orphelins si une toilette a été supprimée
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM favorites f
                           INNER JOIN toilettes t ON f.toilette_id = t.id
                           WHERE f.user_id = ?");
    $stmt->execute(array($user_id));
    $nb_favoris = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

} catch (Exception $e) {
    // ---- Gestion des erreurs de chargement ----
    // Logger l'erreur technique sans l'exposer à l'utilisateur
    error_log("Profil error: " . $e->getMessage());
    // Afficher un message générique à l'utilisateur
    $errors[] = $lang === 'fr' ? 'Erreur de chargement du profil' : 'Profile loading error';
}

// ========================================
// 5. TRAITEMENT: MODIFICATION DU PROFIL
// ========================================
// Vérifier que c'est un POST avec l'action "update_profile"
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_profile') {
    // ---- Récupération des nouvelles valeurs ----
    $new_username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $new_email = isset($_POST['email']) ? trim($_POST['email']) : '';

    // ---- Validation du username ----
    if (empty($new_username)) {
        $errors[] = $lang === 'fr' ? 'Le nom d\'utilisateur est requis' : 'Username is required';
    }

    // ---- Validation de l'email ----
    if (empty($new_email)) {
        $errors[] = $lang === 'fr' ? 'L\'email est requis' : 'Email is required';
    } elseif (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
        // Vérifier que l'email a un format valide (avec @, domaine, etc.)
        $errors[] = $lang === 'fr' ? 'Format d\'email invalide' : 'Invalid email format';
    }

    // ---- Si validation réussie, procéder à la mise à jour ----
    if (empty($errors)) {
        try {
            // ---- Vérifier l'unicité de l'email ----
            // S'assurer que l'email n'est pas déjà pris par un AUTRE utilisateur (id != current user)
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $stmt->execute(array($new_email, $user_id));
            if ($stmt->fetch()) {
                $errors[] = $lang === 'fr' ? 'Cet email est déjà utilisé' : 'This email is already taken';
            }

            // ---- Vérifier l'unicité du username ----
            // S'assurer que le username n'est pas déjà pris par un AUTRE utilisateur
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
            $stmt->execute(array($new_username, $user_id));
            if ($stmt->fetch()) {
                $errors[] = $lang === 'fr' ? 'Ce nom d\'utilisateur est déjà utilisé' : 'This username is already taken';
            }

            // ---- Si pas de doublons, effectuer la mise à jour ----
            if (empty($errors)) {
                // Mettre à jour en base de données
                $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ? WHERE id = ?");
                $stmt->execute(array($new_username, $new_email, $user_id));

                // Mettre à jour les données en session pour cohérence
                $_SESSION['username'] = $new_username;
                $_SESSION['email'] = $new_email;

                // Message de succès
                $success = $lang === 'fr' ? 'Profil mis à jour avec succès' : 'Profile updated successfully';

                // Mettre à jour le tableau $user pour affichage immédiat
                $user['username'] = $new_username;
                $user['email'] = $new_email;
            }
        } catch (Exception $e) {
            // ---- Gestion des erreurs SQL ----
            error_log("Update profile error: " . $e->getMessage());
            $errors[] = $lang === 'fr' ? 'Erreur lors de la mise à jour' : 'Update error';
        }
    }
}

// ========================================
// 6. TRAITEMENT: CHANGEMENT MOT DE PASSE
// ========================================
// Vérifier que c'est un POST avec l'action "change_password"
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_password') {
    // ---- Récupération des mots de passe ----
    $current_password = isset($_POST['current_password']) ? $_POST['current_password'] : '';
    $new_password = isset($_POST['new_password']) ? $_POST['new_password'] : '';
    $confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

    // ---- Validation du mot de passe actuel ----
    if (empty($current_password)) {
        $errors[] = $lang === 'fr' ? 'Le mot de passe actuel est requis' : 'Current password is required';
    }

    // ---- Validation du nouveau mot de passe ----
    if (empty($new_password)) {
        $errors[] = $lang === 'fr' ? 'Le nouveau mot de passe est requis' : 'New password is required';
    }
    // Note: Pas de limite de longueur minimale pour permettre des mots de passe courts

    // ---- Validation de la confirmation ----
    if ($new_password !== $confirm_password) {
        $errors[] = $lang === 'fr' ? 'Les mots de passe ne correspondent pas' : 'Passwords do not match';
    }

    // ---- Si validation réussie, procéder au changement ----
    if (empty($errors)) {
        try {
            // ---- Vérifier que le mot de passe actuel est correct ----
            // password_verify() compare le mot de passe en clair avec le hash stocké
            if (password_verify($current_password, $user['password_hash'])) {
                // ---- Hasher le nouveau mot de passe ----
                // PASSWORD_DEFAULT utilise bcrypt (actuellement l'algorithme le plus sécurisé)
                $new_hash = password_hash($new_password, PASSWORD_DEFAULT);

                // ---- Mettre à jour le hash en base de données ----
                $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
                $stmt->execute(array($new_hash, $user_id));

                // Message de succès
                $success = $lang === 'fr' ? 'Mot de passe changé avec succès' : 'Password changed successfully';
            } else {
                // Le mot de passe actuel fourni ne correspond pas
                $errors[] = $lang === 'fr' ? 'Mot de passe actuel incorrect' : 'Current password is incorrect';
            }
        } catch (Exception $e) {
            // ---- Gestion des erreurs SQL ----
            error_log("Change password error: " . $e->getMessage());
            $errors[] = $lang === 'fr' ? 'Erreur lors du changement de mot de passe' : 'Password change error';
        }
    }
}

// ========================================
// 7. PRÉPARATION DU MODE SOMBRE
// ========================================
// Récupérer la préférence de thème depuis la session
$dark_mode = isset($_SESSION['dark_mode']) ? $_SESSION['dark_mode'] : false;
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" data-theme="<?php echo $dark_mode ? 'dark' : 'light'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $lang === 'fr' ? 'Mon profil' : 'My profile'; ?> - PeePeeFinder</title>
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico">
    <link rel="stylesheet" href="assets/css/app.css">
    <script src="assets/js/app.js" defer></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/feather-icons"></script>

    <!-- ========================================
         STYLES PERSONNALISÉS - MODE SOMBRE
         ======================================== -->
    <style>
        /* Thème sombre global */
        [data-theme="dark"] {
            background-color: #111827;
            color: #f9fafb;
        }
        /* Cartes blanches → grises en mode sombre */
        [data-theme="dark"] .bg-white {
            background-color: #1f2937 !important;
        }
        /* Ajustement des couleurs de texte */
        [data-theme="dark"] .text-gray-800 {
            color: #f9fafb !important;
        }
        [data-theme="dark"] .text-gray-700 {
            color: #e5e7eb !important;
        }
        [data-theme="dark"] .text-gray-600 {
            color: #d1d5db !important;
        }
        /* Ajustement des bordures */
        [data-theme="dark"] .border-gray-300 {
            border-color: #4b5563 !important;
        }
        /* Champs de formulaire en mode sombre */
        [data-theme="dark"] input {
            background-color: #374151 !important;
            color: #f9fafb !important;
            border-color: #4b5563 !important;
        }
    </style>
</head>
<body class="font-sans antialiased bg-gray-50">

    <!-- ========================================
         HEADER - NAVIGATION
         ======================================== -->
    <header class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div class="flex justify-between items-center nav-wrapper">
                <!-- Logo -->
                <a href="index.php" class="text-xl font-bold text-blue-600 flex items-center">
                    <span class="text-2xl mr-2">🚽</span>
                    PeePeeFinder
                </a>

                <!-- Navigation et actions -->
                <div class="flex items-center space-x-3 md:space-x-4">
                    <!-- Bouton menu mobile -->
                    <button
                        class="mobile-nav-toggle md:hidden"
                        type="button"
                        aria-controls="primary-navigation"
                        aria-expanded="false"
                        aria-label="<?php echo $lang === 'fr' ? 'Ouvrir le menu' : 'Open menu'; ?>"
                        data-open-label="<?php echo $lang === 'fr' ? 'Ouvrir le menu' : 'Open menu'; ?>"
                        data-close-label="<?php echo $lang === 'fr' ? 'Fermer le menu' : 'Close menu'; ?>"
                    >
                        <i data-feather="menu" class="icon-menu"></i>
                        <i data-feather="x" class="icon-close"></i>
                    </button>

                    <!-- Menu de navigation principal -->
                    <nav id="primary-navigation" class="hidden md:flex items-center space-x-4 mobile-nav">
                        <a href="map.php" class="text-gray-600 hover:text-blue-600 flex items-center">
                            <i data-feather="map" class="w-4 h-4 mr-1"></i>
                            <?php echo $lang === 'fr' ? 'Carte' : 'Map'; ?>
                        </a>
                        <a href="dashboard.php" class="text-gray-600 hover:text-blue-600 flex items-center">
                            <i data-feather="bar-chart-2" class="w-4 h-4 mr-1"></i>
                            Dashboard
                        </a>
                        <!-- Page active: Profil -->
                        <a href="profil.php" class="text-blue-600 hover:text-blue-700 flex items-center font-medium">
                            <i data-feather="user" class="w-4 h-4 mr-1"></i>
                            <?php echo $lang === 'fr' ? 'Profil' : 'Profile'; ?>
                        </a>
                    </nav>

                    <!-- Toggle mode sombre/clair -->
                    <button id="darkModeToggle" class="p-2 rounded-lg hover:bg-gray-100 transition duration-200">
                        <i data-feather="<?php echo $dark_mode ? 'sun' : 'moon'; ?>" class="w-5 h-5"></i>
                    </button>

                    <!-- Bouton déconnexion -->
                    <a href="logout.php" class="px-3 py-1 bg-red-500 text-white rounded-lg hover:bg-red-600 transition duration-200 text-sm">
                        <?php echo $lang === 'fr' ? 'Déconnexion' : 'Logout'; ?>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- ========================================
         CONTENU PRINCIPAL
         ======================================== -->
    <main class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Titre de la page -->
        <h1 class="text-3xl font-bold text-gray-800 mb-8 flex items-center">
            <i data-feather="user" class="w-8 h-8 mr-3 text-blue-600"></i>
            <?php echo $lang === 'fr' ? 'Mon profil' : 'My profile'; ?>
        </h1>

        <!-- ========================================
             MESSAGES D'ERREUR
             ======================================== -->
        <?php if (!empty($errors)): ?>
            <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded">
                <div class="flex items-start">
                    <i data-feather="alert-circle" class="text-red-500 mr-2 flex-shrink-0" style="width: 20px; height: 20px;"></i>
                    <div class="flex-1">
                        <?php foreach ($errors as $error): ?>
                            <p class="text-red-700 text-sm"><?php echo htmlspecialchars($error); ?></p>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- ========================================
             MESSAGE DE SUCCÈS
             ======================================== -->
        <?php if ($success): ?>
            <div class="bg-green-50 border-l-4 border-green-500 p-4 mb-6 rounded">
                <div class="flex items-start">
                    <i data-feather="check-circle" class="text-green-500 mr-2 flex-shrink-0" style="width: 20px; height: 20px;"></i>
                    <p class="text-green-700 text-sm"><?php echo htmlspecialchars($success); ?></p>
                </div>
            </div>
        <?php endif; ?>

        <!-- ========================================
             GRILLE PRINCIPALE: STATS + FORMULAIRES
             ======================================== -->
        <div class="grid md:grid-cols-3 gap-6">

            <!-- ========================================
                 COLONNE GAUCHE: STATISTIQUES
                 ======================================== -->
            <div class="md:col-span-1 space-y-4">
                <!-- Carte profil utilisateur -->
                <div class="bg-white p-6 rounded-xl shadow-md">
                    <div class="text-center">
                        <!-- Avatar (icône utilisateur) -->
                        <div class="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i data-feather="user" class="w-12 h-12 text-blue-600"></i>
                        </div>
                        <!-- Username -->
                        <h2 class="text-xl font-bold text-gray-800"><?php echo htmlspecialchars($user['username']); ?></h2>
                        <!-- Email -->
                        <p class="text-gray-600 text-sm"><?php echo htmlspecialchars($user['email']); ?></p>
                        <!-- Badge rôle (Admin ou User) -->
                        <span class="inline-block px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium mt-2">
                            <?php echo $user['role'] === 'admin' ? 'Admin' : 'User'; ?>
                        </span>
                    </div>
                </div>

                <!-- Carte statistiques -->
                <div class="bg-white p-6 rounded-xl shadow-md">
                    <h3 class="font-bold text-gray-800 mb-4"><?php echo $lang === 'fr' ? 'Statistiques' : 'Statistics'; ?></h3>
                    <div class="space-y-3">
                        <!-- Nombre d'avis déposés -->
                        <div class="flex justify-between">
                            <span class="text-gray-600">⭐ <?php echo $lang === 'fr' ? 'Avis déposés' : 'Reviews'; ?></span>
                            <span class="font-bold text-blue-600"><?php echo $nb_avis; ?></span>
                        </div>
                        <!-- Nombre de favoris -->
                        <div class="flex justify-between">
                            <span class="text-gray-600">❤️ <?php echo $lang === 'fr' ? 'Favoris' : 'Favorites'; ?></span>
                            <span class="font-bold text-pink-600"><?php echo $nb_favoris; ?></span>
                        </div>
                        <!-- Date d'inscription -->
                        <div class="flex justify-between">
                            <span class="text-gray-600">📅 <?php echo $lang === 'fr' ? 'Membre depuis' : 'Member since'; ?></span>
                            <span class="font-bold text-gray-800"><?php echo date('d/m/Y', strtotime($user['created_at'])); ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ========================================
                 COLONNE DROITE: FORMULAIRES
                 ======================================== -->
            <div class="md:col-span-2 space-y-6">

                <!-- ========================================
                     FORMULAIRE: MODIFIER PROFIL
                     ======================================== -->
                <div class="bg-white p-6 rounded-xl shadow-md">
                    <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                        <i data-feather="edit-3" class="w-5 h-5 mr-2 text-blue-600"></i>
                        <?php echo $lang === 'fr' ? 'Modifier mes informations' : 'Edit my information'; ?>
                    </h3>
                    <form method="POST" class="space-y-4">
                        <!-- Champ caché pour identifier l'action -->
                        <input type="hidden" name="action" value="update_profile">

                        <!-- Champ Username -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                <?php echo $lang === 'fr' ? 'Nom d\'utilisateur' : 'Username'; ?>
                            </label>
                            <input
                                type="text"
                                name="username"
                                value="<?php echo htmlspecialchars($user['username']); ?>"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                required
                            >
                        </div>

                        <!-- Champ Email -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                            <input
                                type="email"
                                name="email"
                                value="<?php echo htmlspecialchars($user['email']); ?>"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                required
                            >
                        </div>

                        <!-- Bouton soumettre -->
                        <button type="submit" class="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition duration-200">
                            <?php echo $lang === 'fr' ? 'Enregistrer les modifications' : 'Save changes'; ?>
                        </button>
                    </form>
                </div>

                <!-- ========================================
                     FORMULAIRE: CHANGER MOT DE PASSE
                     ======================================== -->
                <div class="bg-white p-6 rounded-xl shadow-md">
                    <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                        <i data-feather="lock" class="w-5 h-5 mr-2 text-blue-600"></i>
                        <?php echo $lang === 'fr' ? 'Changer mon mot de passe' : 'Change my password'; ?>
                    </h3>
                    <form method="POST" class="space-y-4">
                        <!-- Champ caché pour identifier l'action -->
                        <input type="hidden" name="action" value="change_password">

                        <!-- Champ Mot de passe actuel -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                <?php echo $lang === 'fr' ? 'Mot de passe actuel' : 'Current password'; ?>
                            </label>
                            <input
                                type="password"
                                name="current_password"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                required
                            >
                        </div>

                        <!-- Champ Nouveau mot de passe -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                <?php echo $lang === 'fr' ? 'Nouveau mot de passe' : 'New password'; ?>
                            </label>
                            <input
                                type="password"
                                name="new_password"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                required
                            >
                        </div>

                        <!-- Champ Confirmer nouveau mot de passe -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                <?php echo $lang === 'fr' ? 'Confirmer le nouveau mot de passe' : 'Confirm new password'; ?>
                            </label>
                            <input
                                type="password"
                                name="confirm_password"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                required
                            >
                        </div>

                        <!-- Bouton soumettre -->
                        <button type="submit" class="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition duration-200">
                            <?php echo $lang === 'fr' ? 'Changer le mot de passe' : 'Change password'; ?>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <!-- ========================================
         JAVASCRIPT - INTERACTIONS
         ======================================== -->
    <script>
        /**
         * Initialiser les icônes Feather
         * Remplace les balises <i data-feather="..."> par les SVG correspondants
         */
        feather.replace();

        /**
         * Toggle Mode Sombre/Clair
         * Appel API pour basculer le mode et recharger la page
         */
        document.getElementById('darkModeToggle').addEventListener('click', function() {
            // Appel asynchrone à l'API de toggle
            fetch('api/toggle_dark_mode.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(function(response) { return response.json(); })
            .then(function(data) {
                // Si succès, recharger la page pour appliquer le nouveau thème
                if (data.success) {
                    location.reload();
                }
            })
            .catch(function(error) {
                console.error('Error:', error);
            });
        });
    </script>

<?php
    // ========================================
    // FOOTER - Inclure le pied de page commun
    // ========================================
    include 'partials/footer.php';
?>
</body>
</html>
