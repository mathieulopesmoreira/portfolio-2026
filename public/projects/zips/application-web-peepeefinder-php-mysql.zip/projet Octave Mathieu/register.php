﻿<?php
/**
 * ========================================
 * PAGE D'INSCRIPTION (REGISTER)
 * ========================================
 *
 * Fichier: register.php
 * Description: Formulaire d'inscription pour créer un nouveau compte utilisateur
 *
 * Fonctionnalités:
 * - Création de compte avec validation complète
 * - Vérification d'unicité (username, email)
 * - Hashage sécurisé du mot de passe (password_hash)
 * - Notification de bienvenue automatique
 * - Support multilingue (FR/EN)
 * - Validation côté serveur ET côté client
 * - Interface moderne et responsive
 *
 * Sécurité:
 * - Protection CSRF via session
 * - Validation stricte des entrées
 * - Hashage bcrypt des mots de passe
 * - Échappement HTML des sorties
 * - Redirection si déjà connecté
 *
 * @author PeePeeFinder Team
 * @version 1.0
 */

// ========================================
// INITIALISATION DE LA SESSION
// ========================================
session_start();
header('Content-Type: text/html; charset=utf-8');

// ========================================
// PROTECTION: Redirection si déjà connecté
// ========================================
// Si l'utilisateur est déjà authentifié, le rediriger vers la carte
if (isset($_SESSION['user_id'])) {
    header('Location: map.php');
    exit();
}

// ========================================
// CONNEXION À LA BASE DE DONNÉES
// ========================================
require_once 'includes/db.php';

// ========================================
// GESTION DE LA LANGUE (i18n)
// ========================================
// Par défaut en français, stocké en session
$lang = isset($_SESSION['lang']) ? $_SESSION['lang'] : 'fr';

// Si changement de langue via URL (?lang=en ou ?lang=fr)
if (isset($_GET['lang']) && in_array($_GET['lang'], ['fr', 'en'])) {
    $lang = $_GET['lang'];
    $_SESSION['lang'] = $lang;
    // Recharger la page pour appliquer la nouvelle langue
    header('Location: register.php');
    exit();
}

// ========================================
// VARIABLES POUR LES MESSAGES
// ========================================
$errors = array();  // Tableau pour stocker les erreurs de validation
$success = '';      // Message de succès (non utilisé ici, redirection vers login)

// ========================================
// TRAITEMENT DU FORMULAIRE POST
// ========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ----------------------------------------
    // 1. RÉCUPÉRATION ET NETTOYAGE DES DONNÉES
    // ----------------------------------------
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $password_confirm = isset($_POST['password_confirm']) ? $_POST['password_confirm'] : '';
    $accept_terms = isset($_POST['accept_terms']);

    // ----------------------------------------
    // 2. VALIDATION DU NOM D'UTILISATEUR
    // ----------------------------------------
    // Vérifier que le champ n'est pas vide
    if (empty($username)) {
        $errors[] = $lang === 'fr' ? 'Le nom d\'utilisateur est requis' : 'Username is required';
    }
    // Vérifier la longueur minimale (3 caractères)
    elseif (strlen($username) < 3) {
        $errors[] = $lang === 'fr' ? 'Le nom d\'utilisateur doit contenir au moins 3 caractères' : 'Username must be at least 3 characters';
    }
    // Vérifier la longueur maximale (50 caractères)
    elseif (strlen($username) > 50) {
        $errors[] = $lang === 'fr' ? 'Le nom d\'utilisateur ne peut pas dépasser 50 caractères' : 'Username cannot exceed 50 characters';
    }
    // Vérifier le format (uniquement lettres, chiffres, underscore et tiret)
    elseif (!preg_match('/^[a-zA-Z0-9_-]+$/', $username)) {
        $errors[] = $lang === 'fr' ? 'Le nom d\'utilisateur ne peut contenir que des lettres, chiffres, _ et -' : 'Username can only contain letters, numbers, _ and -';
    }

    // ----------------------------------------
    // 3. VALIDATION DE L'EMAIL
    // ----------------------------------------
    // Vérifier que le champ n'est pas vide
    if (empty($email)) {
        $errors[] = $lang === 'fr' ? 'L\'email est requis' : 'Email is required';
    }
    // Vérifier le format de l'email avec filtre PHP
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = $lang === 'fr' ? 'Format d\'email invalide' : 'Invalid email format';
    }

    // ----------------------------------------
    // 4. VALIDATION DU MOT DE PASSE
    // ----------------------------------------
    // Vérifier que le champ n'est pas vide
    if (empty($password)) {
        $errors[] = $lang === 'fr' ? 'Le mot de passe est requis' : 'Password is required';
    }

    // ----------------------------------------
    // 5. VÉRIFICATION CONFIRMATION MOT DE PASSE
    // ----------------------------------------
    // Les deux mots de passe doivent être identiques
    if ($password !== $password_confirm) {
        $errors[] = $lang === 'fr' ? 'Les mots de passe ne correspondent pas' : 'Passwords do not match';
    }

    // ----------------------------------------
    // 6. VÉRIFICATION ACCEPTATION DES CONDITIONS
    // ----------------------------------------
    // L'utilisateur doit cocher la case des CGU
    if (!$accept_terms) {
        $errors[] = $lang === 'fr' ? 'Vous devez accepter les conditions d\'utilisation' : 'You must accept the terms of use';
    }

    // ----------------------------------------
    // 7. VÉRIFICATION D'UNICITÉ EN BASE DE DONNÉES
    // ----------------------------------------
    // Si toutes les validations précédentes sont passées
    if (empty($errors)) {
        try {
            // ========================================
            // VÉRIFIER SI LE USERNAME EXISTE DÉJÀ
            // ========================================
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->execute(array($username));
            if ($stmt->fetch()) {
                $errors[] = $lang === 'fr' ? 'Ce nom d\'utilisateur est déjà utilisé' : 'This username is already taken';
            }

            // ========================================
            // VÉRIFIER SI L'EMAIL EXISTE DÉJÀ
            // ========================================
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute(array($email));
            if ($stmt->fetch()) {
                $errors[] = $lang === 'fr' ? 'Cet email est déjà utilisé' : 'This email is already taken';
            }

            // ========================================
            // CRÉATION DU COMPTE UTILISATEUR
            // ========================================
            // Si toujours aucune erreur après vérifications d'unicité
            if (empty($errors)) {
                // ----------------------------------------
                // HASHER LE MOT DE PASSE (SÉCURITÉ)
                // ----------------------------------------
                // Utilise bcrypt par défaut, génère un salt automatiquement
                $password_hash = password_hash($password, PASSWORD_DEFAULT);

                // ----------------------------------------
                // INSÉRER L'UTILISATEUR DANS LA TABLE users
                // ----------------------------------------
                $stmt = $pdo->prepare("
                    INSERT INTO users (username, email, password_hash, role, created_at)
                    VALUES (?, ?, ?, 'user', NOW())
                ");
                $stmt->execute(array($username, $email, $password_hash));

                // Récupérer l'ID auto-généré du nouvel utilisateur
                $user_id = $pdo->lastInsertId();

                // ========================================
                // CRÉATION D'UNE NOTIFICATION DE BIENVENUE
                // ========================================
                // Tentative "best effort" : on continue même si ça échoue
                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO notifications (user_id, type, title, message, created_at)
                        VALUES (?, 'welcome', ?, ?, NOW())
                    ");

                    // Messages de bienvenue selon la langue
                    $welcome_title = $lang === 'fr' ? 'Bienvenue sur PeePeeFinder !' : 'Welcome to PeePeeFinder!';
                    $welcome_message = $lang === 'fr'
                        ? 'Merci de vous être inscrit ! Explorez la carte pour trouver des toilettes près de vous.'
                        : 'Thank you for signing up! Explore the map to find toilets near you.';

                    $stmt->execute(array($user_id, $welcome_title, $welcome_message));
                } catch (Exception $notificationError) {
                    // Enregistrer l'erreur dans les logs mais ne pas bloquer l'inscription
                    error_log("Registration notification error: " . $notificationError->getMessage());
                }

                // ========================================
                // JOURNALISATION (LOGS)
                // ========================================
                // Enregistrer l'inscription dans les logs serveur pour audit
                error_log("New user registered: $username (ID: $user_id)");

                // ========================================
                // REDIRECTION VERS LA PAGE DE CONNEXION
                // ========================================
                // Paramètre registered=1 pour afficher un message de succès
                header('Location: login.php?registered=1');
                exit();
            }
        } catch (Exception $e) {
            // ========================================
            // GESTION DES ERREURS DE BASE DE DONNÉES
            // ========================================
            // Enregistrer l'erreur technique dans les logs
            error_log("Registration error: " . $e->getMessage());

            // Afficher un message générique à l'utilisateur (sécurité)
            $errors[] = $lang === 'fr'
                ? 'Erreur lors de l\'inscription. Veuillez réessayer.'
                : 'Registration error. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <!-- ========================================
         META TAGS ET CONFIGURATION
         ======================================== -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $lang === 'fr' ? 'Inscription' : 'Sign up'; ?> - PeePeeFinder</title>

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico">

    <!-- Feuille de style personnalisée -->
    <link rel="stylesheet" href="assets/css/app.css">

    <!-- ========================================
         BIBLIOTHÈQUES EXTERNES (CDN)
         ======================================== -->
    <!-- Tailwind CSS : Framework CSS utility-first -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Feather Icons : Icônes SVG modernes -->
    <script src="https://unpkg.com/feather-icons"></script>

    <!-- ========================================
         STYLES CSS PERSONNALISÉS
         ======================================== -->
    <style>
        /* Container principal avec dégradé violet */
        .register-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 2rem 0;
        }

        /* Animation d'entrée de la carte */
        .register-card {
            animation: slideIn 0.5s ease-out;
        }

        /* Définition de l'animation slideIn */
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Groupe d'input avec icône */
        .input-group {
            position: relative;
        }

        /* Icône à gauche de l'input */
        .input-icon {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #9ca3af;
        }

        /* Padding pour faire de la place à l'icône gauche */
        .input-field {
            padding-left: 40px;
        }

        /* Icône toggle du mot de passe (œil) */
        .password-toggle {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #9ca3af;
        }

        /* Hover sur l'icône toggle */
        .password-toggle:hover {
            color: #4b5563;
        }
    </style>
</head>
<body class="font-sans antialiased">
    <!-- ========================================
         CONTAINER PRINCIPAL
         ======================================== -->
    <div class="register-container">
        <div class="register-card bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md mx-4">

            <!-- ========================================
                 LOGO ET TITRE
                 ======================================== -->
            <div class="text-center mb-6">
                <a href="index.php" class="inline-flex items-center justify-center text-3xl font-bold text-blue-600">
                    <span class="text-4xl mr-2">🚽</span>
                    PeePeeFinder
                </a>
                <p class="text-gray-600 mt-2">
                    <?php echo $lang === 'fr' ? 'Créez votre compte' : 'Create your account'; ?>
                </p>
            </div>

            <!-- ========================================
                 AFFICHAGE DES ERREURS DE VALIDATION
                 ======================================== -->
            <?php if (!empty($errors)): ?>
                <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded">
                    <div class="flex items-start">
                        <!-- Icône d'alerte -->
                        <i data-feather="alert-circle" class="text-red-500 mr-2 flex-shrink-0" style="width: 20px; height: 20px;"></i>
                        <div class="flex-1">
                            <!-- Boucle pour afficher toutes les erreurs -->
                            <?php foreach ($errors as $error): ?>
                                <p class="text-red-700 text-sm"><?php echo htmlspecialchars($error); ?></p>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- ========================================
                 FORMULAIRE D'INSCRIPTION
                 ======================================== -->
            <form method="POST" action="register.php" class="space-y-4" id="registerForm">

                <!-- ========================================
                     CHAMP: NOM D'UTILISATEUR
                     ======================================== -->
                <div>
                    <label for="username" class="block text-sm font-medium text-gray-700 mb-2">
                        <?php echo $lang === 'fr' ? 'Nom d\'utilisateur' : 'Username'; ?>
                    </label>
                    <div class="input-group">
                        <!-- Icône utilisateur -->
                        <i data-feather="user" class="input-icon" style="width: 20px; height: 20px;"></i>

                        <!-- Input avec validation HTML5 -->
                        <input
                            type="text"
                            id="username"
                            name="username"
                            value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"
                            class="input-field w-full py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition duration-200"
                            placeholder="<?php echo $lang === 'fr' ? 'Choisissez un nom d\'utilisateur' : 'Choose a username'; ?>"
                            required
                            autocomplete="username"
                            minlength="3"
                            maxlength="50"
                            pattern="[a-zA-Z0-9_-]+"
                        >
                    </div>
                    <!-- Aide pour l'utilisateur -->
                    <p class="text-xs text-gray-500 mt-1">
                        <?php echo $lang === 'fr' ? 'Lettres, chiffres, _ et - uniquement (3-50 caractères)' : 'Letters, numbers, _ and - only (3-50 characters)'; ?>
                    </p>
                </div>

                <!-- ========================================
                     CHAMP: EMAIL
                     ======================================== -->
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-2">
                        Email
                    </label>
                    <div class="input-group">
                        <!-- Icône email -->
                        <i data-feather="mail" class="input-icon" style="width: 20px; height: 20px;"></i>

                        <!-- Input email avec validation HTML5 -->
                        <input
                            type="email"
                            id="email"
                            name="email"
                            value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>"
                            class="input-field w-full py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition duration-200"
                            placeholder="<?php echo $lang === 'fr' ? 'Votre adresse email' : 'Your email address'; ?>"
                            required
                            autocomplete="email"
                        >
                    </div>
                </div>

                <!-- ========================================
                     CHAMP: MOT DE PASSE
                     ======================================== -->
                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700 mb-2">
                        <?php echo $lang === 'fr' ? 'Mot de passe' : 'Password'; ?>
                    </label>
                    <div class="input-group">
                        <!-- Icône cadenas -->
                        <i data-feather="lock" class="input-icon" style="width: 20px; height: 20px;"></i>

                        <!-- Input password (masqué par défaut) -->
                        <input
                            type="password"
                            id="password"
                            name="password"
                            class="input-field w-full py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition duration-200"
                            placeholder="<?php echo $lang === 'fr' ? 'Créez un mot de passe sécurisé' : 'Create a secure password'; ?>"
                            required
                            autocomplete="new-password">

                        <!-- Icône œil pour afficher/masquer le mot de passe -->
                        <i data-feather="eye" class="password-toggle" id="togglePassword" style="width: 20px; height: 20px;"></i>
                    </div>
                </div>

                <!-- ========================================
                     CHAMP: CONFIRMATION MOT DE PASSE
                     ======================================== -->
                <div>
                    <label for="password_confirm" class="block text-sm font-medium text-gray-700 mb-2">
                        <?php echo $lang === 'fr' ? 'Confirmer le mot de passe' : 'Confirm password'; ?>
                    </label>
                    <div class="input-group">
                        <!-- Icône cadenas -->
                        <i data-feather="lock" class="input-icon" style="width: 20px; height: 20px;"></i>

                        <!-- Input confirmation password -->
                        <input
                            type="password"
                            id="password_confirm"
                            name="password_confirm"
                            class="input-field w-full py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition duration-200"
                            placeholder="<?php echo $lang === 'fr' ? 'Retapez votre mot de passe' : 'Retype your password'; ?>"
                            required
                            autocomplete="new-password"
                        >

                        <!-- Icône œil pour toggle visibility -->
                        <i data-feather="eye" class="password-toggle" id="togglePasswordConfirm" style="width: 20px; height: 20px;"></i>
                    </div>

                    <!-- Message d'erreur temps réel (masqué par défaut) -->
                    <p class="text-xs text-red-600 mt-1 hidden" id="passwordMismatch">
                        <?php echo $lang === 'fr' ? 'Les mots de passe ne correspondent pas' : 'Passwords do not match'; ?>
                    </p>
                </div>

                <!-- ========================================
                     CHECKBOX: ACCEPTATION DES CONDITIONS
                     ======================================== -->
                <div>
                    <label class="flex items-start">
                        <input
                            type="checkbox"
                            name="accept_terms"
                            id="accept_terms"
                            class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500 mt-1"
                            required
                        >
                        <span class="ml-2 text-sm text-gray-600">
                            <?php echo $lang === 'fr'
                                ? 'J\'accepte les <a href="#" class="text-blue-600 hover:underline">conditions d\'utilisation</a> et la <a href="#" class="text-blue-600 hover:underline">politique de confidentialité</a>'
                                : 'I accept the <a href="#" class="text-blue-600 hover:underline">terms of use</a> and <a href="#" class="text-blue-600 hover:underline">privacy policy</a>'; ?>
                        </span>
                    </label>
                </div>

                <!-- ========================================
                     BOUTON SUBMIT
                     ======================================== -->
                <button
                    type="submit"
                    class="w-full bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 focus:ring-4 focus:ring-blue-300 transition duration-200 flex items-center justify-center"
                    id="submitBtn"
                >
                    <i data-feather="user-plus" class="mr-2" style="width: 20px; height: 20px;"></i>
                    <?php echo $lang === 'fr' ? 'S\'inscrire' : 'Sign up'; ?>
                </button>
            </form>

            <!-- ========================================
                 SÉPARATEUR "OU"
                 ======================================== -->
            <div class="relative my-6">
                <div class="absolute inset-0 flex items-center">
                    <div class="w-full border-t border-gray-300"></div>
                </div>
                <div class="relative flex justify-center text-sm">
                    <span class="px-2 bg-white text-gray-500">
                        <?php echo $lang === 'fr' ? 'ou' : 'or'; ?>
                    </span>
                </div>
            </div>

            <!-- ========================================
                 LIEN VERS LA PAGE DE CONNEXION
                 ======================================== -->
            <div class="text-center">
                <p class="text-sm text-gray-600">
                    <?php echo $lang === 'fr' ? 'Vous avez déjà un compte ?' : 'Already have an account?'; ?>
                    <a href="login.php" class="text-blue-600 hover:text-blue-800 font-medium transition duration-200">
                        <?php echo $lang === 'fr' ? 'Connectez-vous' : 'Sign in'; ?>
                    </a>
                </p>
            </div>

            <!-- ========================================
                 LIEN RETOUR À L'ACCUEIL
                 ======================================== -->
            <div class="mt-6 text-center">
                <a href="index.php" class="inline-flex items-center text-sm text-gray-600 hover:text-gray-800 transition duration-200">
                    <i data-feather="arrow-left" class="mr-2" style="width: 16px; height: 16px;"></i>
                    <?php echo $lang === 'fr' ? 'Retour à l\'accueil' : 'Back to home'; ?>
                </a>
            </div>

            <!-- ========================================
                 SWITCH DE LANGUE
                 ======================================== -->
            <div class="mt-4 text-center">
                <?php $new_lang = $lang === 'fr' ? 'en' : 'fr'; ?>
                <button
                    onclick="window.location.href='register.php?lang=<?php echo $new_lang; ?>'"
                    class="inline-flex items-center text-sm text-gray-600 hover:text-gray-800 transition duration-200"
                >
                    <i data-feather="globe" class="mr-2" style="width: 16px; height: 16px;"></i>
                    <?php echo $new_lang === 'en' ? 'English' : 'Français'; ?>
                </button>
            </div>
        </div>
    </div>

    <!-- ========================================
         JAVASCRIPT POUR INTERACTIONS
         ======================================== -->
    <script>
        // ========================================
        // INITIALISATION DES ICÔNES FEATHER
        // ========================================
        feather.replace();

        // ========================================
        // TOGGLE VISIBILITÉ DU MOT DE PASSE
        // ========================================

        const passwordInput = document.getElementById('password');

        // Listener sur l'icône du champ "mot de passe"
        document.getElementById('togglePassword').addEventListener('click', function() {
            togglePasswordVisibility(document.getElementById('password'), this);
        });

        // Listener sur l'icône du champ "confirmation mot de passe"
        document.getElementById('togglePasswordConfirm').addEventListener('click', function() {
            togglePasswordVisibility(document.getElementById('password_confirm'), this);
        });

        /**
         * Fonction pour basculer entre type="password" et type="text"
         * @param {HTMLElement} field - Le champ input
         * @param {HTMLElement} icon - L'icône œil
         */
        function togglePasswordVisibility(field, icon) {
            if (field.type === 'password') {
                // Afficher le mot de passe
                field.type = 'text';
                // Changer l'icône en "eye-off" (œil barré)
                icon.innerHTML = feather.icons['eye-off'].toSvg({ style: 'width: 20px; height: 20px;' });
            } else {
                // Masquer le mot de passe
                field.type = 'password';
                // Changer l'icône en "eye" (œil)
                icon.innerHTML = feather.icons['eye'].toSvg({ style: 'width: 20px; height: 20px;' });
            }
        }

        // ========================================
        // VÉRIFICATION TEMPS RÉEL: CORRESPONDANCE DES MOTS DE PASSE
        // ========================================

        const passwordConfirm = document.getElementById('password_confirm');
        const mismatchMsg = document.getElementById('passwordMismatch');

        // Listener sur la saisie dans le champ confirmation
        passwordConfirm.addEventListener('input', function() {
            // Si le champ n'est pas vide ET ne correspond pas au premier mot de passe
            if (this.value && this.value !== passwordInput.value) {
                // Afficher le message d'erreur
                mismatchMsg.classList.remove('hidden');
                // Ajouter une bordure rouge
                this.classList.add('border-red-500');
            } else {
                // Masquer le message d'erreur
                mismatchMsg.classList.add('hidden');
                // Retirer la bordure rouge
                this.classList.remove('border-red-500');
            }
        });

        // ========================================
        // AUTO-FOCUS SUR LE PREMIER CHAMP
        // ========================================
        // Placer automatiquement le curseur dans le champ username
        document.getElementById('username').focus();
    </script>

    <!-- ========================================
         INCLUSION DU FOOTER
         ======================================== -->
<?php include 'partials/footer.php'; ?>
</body>
</html>
