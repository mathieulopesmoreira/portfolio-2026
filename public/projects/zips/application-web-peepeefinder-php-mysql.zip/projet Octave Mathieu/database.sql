-- ========================================
-- DATABASE: peepefinder
-- Description: Base de données complète pour PeePeeFinder
-- Version: 2.1 - Optimisée pour affichage visuel propre
-- ========================================

CREATE DATABASE IF NOT EXISTS peepefinder CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE peepefinder;

-- ========================================
-- ORDRE DE CRÉATION DES TABLES
-- ========================================
-- Organisation en 3 niveaux pour éviter les croisements de liens:
--
-- NIVEAU 1 - Tables indépendantes (0 clé étrangère)
--   ┌─────────────┐     ┌─────────────────┐     ┌────────────────┐
--   │   users     │     │   toilettes     │     │login_attempts  │
--   └─────────────┘     └─────────────────┘     └────────────────┘
--
-- NIVEAU 2 - Tables dépendantes simples (1 clé étrangère)
--   ┌──────────────────┐     ┌──────────────┐
--   │ remember_tokens  │     │imports_logs  │
--   │   (→users)       │     │  (→users)    │
--   └──────────────────┘     └──────────────┘
--
-- NIVEAU 3 - Tables de liaison (2 clés étrangères)
--   ┌────────────────────┐     ┌────────────────────┐     ┌────────────────────┐
--   │      avis          │     │    favorites       │     │     reports        │
--   │ (→users+toilettes) │     │ (→users+toilettes) │     │ (→users+toilettes) │
--   └────────────────────┘     └────────────────────┘     └────────────────────┘
-- ========================================


-- ╔═══════════════════════════════════════════════════════════════════════════╗
-- ║                          NIVEAU 1 - TABLES INDÉPENDANTES                  ║
-- ╚═══════════════════════════════════════════════════════════════════════════╝

-- ========================================
-- TABLE: users
-- Description: Gestion des utilisateurs et authentification
-- Dépendances: AUCUNE
-- ========================================
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    dark_mode BOOLEAN DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_login DATETIME NULL,
    is_active BOOLEAN DEFAULT 1,
    email_verified BOOLEAN DEFAULT 0,

    INDEX idx_username (username),
    INDEX idx_email (email),
    INDEX idx_role (role),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='Gestion des utilisateurs et authentification';

-- ========================================
-- TABLE: toilettes
-- Description: Données des toilettes publiques (structure OpenData)
-- Dépendances: AUCUNE
-- ========================================
CREATE TABLE IF NOT EXISTS toilettes (
    id INT PRIMARY KEY AUTO_INCREMENT,

    -- Colonnes OpenData (CSV import)
    Source VARCHAR(255),
    `Accessible au public` VARCHAR(50),
    Tarif VARCHAR(50),
    `Accessibilite PMR` VARCHAR(50),
    `Indications de localisation` TEXT,
    Type VARCHAR(100),
    `Horaires d'ouverture` TEXT,
    `Relais bébé` VARCHAR(50),
    coord_geo VARCHAR(100),
    osm_id VARCHAR(100),
    nom_de_la_commune VARCHAR(100),
    code_geogrephique_commune VARCHAR(20),
    nom_departement VARCHAR(100),
    code_geographique_departement VARCHAR(20),

    -- Colonnes normalisées pour l'application
    nom VARCHAR(255),
    type_normalise VARCHAR(100) DEFAULT 'autres',
    adresse VARCHAR(255),
    commune VARCHAR(100),
    code_postal VARCHAR(10),
    payant BOOLEAN DEFAULT 0,
    acces_pmr BOOLEAN DEFAULT 0,
    ouvert_24_7 BOOLEAN DEFAULT 0,
    latitude DECIMAL(9,6),
    longitude DECIMAL(9,6),

    -- Métadonnées et statistiques
    source_id VARCHAR(100) UNIQUE,
    date_maj DATE,
    note_moyenne DECIMAL(3,2) DEFAULT 0,
    nombre_avis INT DEFAULT 0,
    horaires TEXT,
    description TEXT,
    telephone VARCHAR(20),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_commune (commune),
    INDEX idx_type (type_normalise),
    INDEX idx_coords (latitude, longitude),
    INDEX idx_pmr (acces_pmr),
    INDEX idx_payant (payant),
    INDEX idx_24_7 (ouvert_24_7),
    INDEX idx_source (source_id),
    INDEX idx_note (note_moyenne),
    INDEX idx_osm (osm_id),
    INDEX idx_search (commune, acces_pmr, payant, ouvert_24_7)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='Données des toilettes publiques OpenData';

-- ========================================
-- TABLE: login_attempts
-- Description: Suivi des tentatives de connexion (sécurité anti-brute-force)
-- Dépendances: AUCUNE (pas de clé étrangère - juste des logs)
-- ========================================
CREATE TABLE IF NOT EXISTS login_attempts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    ip_address VARCHAR(45) NOT NULL,
    username VARCHAR(100),
    attempt_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    success BOOLEAN DEFAULT 0,
    user_agent TEXT,

    INDEX idx_ip_time (ip_address, attempt_time),
    INDEX idx_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='Logs des tentatives de connexion (sécurité)';


-- ╔═══════════════════════════════════════════════════════════════════════════╗
-- ║                    NIVEAU 2 - TABLES DÉPENDANTES SIMPLES                  ║
-- ╚═══════════════════════════════════════════════════════════════════════════╝

-- ========================================
-- TABLE: remember_tokens
-- Description: Tokens pour "Se souvenir de moi"
-- Dépendances: users
-- ========================================
CREATE TABLE IF NOT EXISTS remember_tokens (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    token VARCHAR(64) NOT NULL UNIQUE,
    expiry DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_used DATETIME NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,

    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_token (token),
    INDEX idx_expiry (expiry),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='Tokens de connexion persistante (Se souvenir de moi)';

-- ========================================
-- TABLE: imports_logs
-- Description: Historique des imports de données OpenData
-- Dépendances: users
-- ========================================
CREATE TABLE IF NOT EXISTS imports_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    filename VARCHAR(255),
    source_url TEXT,
    rows_total INT DEFAULT 0,
    rows_imported INT DEFAULT 0,
    rows_updated INT DEFAULT 0,
    rows_failed INT DEFAULT 0,
    import_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    duration_seconds INT,
    status ENUM('success', 'partial', 'failed') DEFAULT 'success',
    error_log TEXT,

    FOREIGN KEY (user_id) REFERENCES users(id),
    INDEX idx_user (user_id),
    INDEX idx_date (import_date),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='Historique et logs des imports CSV';


-- ╔═══════════════════════════════════════════════════════════════════════════╗
-- ║                      NIVEAU 3 - TABLES DE LIAISON                         ║
-- ╚═══════════════════════════════════════════════════════════════════════════╝

-- ========================================
-- TABLE: avis
-- Description: Système d'avis et notations
-- Dépendances: users, toilettes
-- ========================================
CREATE TABLE IF NOT EXISTS avis (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    toilette_id INT NOT NULL,
    note INT NOT NULL CHECK (note BETWEEN 1 AND 5),
    proprete INT CHECK (proprete BETWEEN 1 AND 5),
    commentaire TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_moderated BOOLEAN DEFAULT 0,
    is_visible BOOLEAN DEFAULT 1,

    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (toilette_id) REFERENCES toilettes(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_toilette (user_id, toilette_id),
    INDEX idx_user (user_id),
    INDEX idx_toilette (toilette_id),
    INDEX idx_note (note),
    INDEX idx_created (created_at),
    INDEX idx_visible (toilette_id, is_visible, note)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='Avis et notations des utilisateurs';

-- ========================================
-- TABLE: favorites
-- Description: Toilettes favorites des utilisateurs
-- Dépendances: users, toilettes
-- ========================================
CREATE TABLE IF NOT EXISTS favorites (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    toilette_id INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (toilette_id) REFERENCES toilettes(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_toilette (user_id, toilette_id),
    INDEX idx_user (user_id),
    INDEX idx_toilette (toilette_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='Toilettes favorites sauvegardées par les utilisateurs';

-- ========================================
-- TABLE: reports
-- Description: Signalement de problèmes sur les toilettes
-- Dépendances: users, toilettes
-- ========================================
CREATE TABLE IF NOT EXISTS reports (
    id INT PRIMARY KEY AUTO_INCREMENT,
    toilette_id INT NOT NULL,
    user_id INT NULL,
    type ENUM('ferme', 'sale', 'casse', 'info_incorrecte', 'autre') NOT NULL,
    description TEXT,
    status ENUM('pending', 'reviewed', 'resolved', 'rejected') DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    resolved_at DATETIME NULL,
    resolved_by INT NULL,
    admin_notes TEXT,

    FOREIGN KEY (toilette_id) REFERENCES toilettes(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (resolved_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_toilette (toilette_id),
    INDEX idx_status (status),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='Signalements de problèmes (future fonctionnalité)';


-- ╔═══════════════════════════════════════════════════════════════════════════╗
-- ║                          TRIGGERS AUTOMATIQUES                            ║
-- ╚═══════════════════════════════════════════════════════════════════════════╝

DELIMITER //

-- Trigger après insertion d'un avis
CREATE TRIGGER update_note_moyenne_after_insert AFTER INSERT ON avis
FOR EACH ROW
BEGIN
    UPDATE toilettes
    SET note_moyenne = (
        SELECT AVG(note)
        FROM avis
        WHERE toilette_id = NEW.toilette_id AND is_visible = 1
    ),
    nombre_avis = (
        SELECT COUNT(*)
        FROM avis
        WHERE toilette_id = NEW.toilette_id AND is_visible = 1
    )
    WHERE id = NEW.toilette_id;
END//

-- Trigger après modification d'un avis
CREATE TRIGGER update_note_moyenne_after_update AFTER UPDATE ON avis
FOR EACH ROW
BEGIN
    UPDATE toilettes
    SET note_moyenne = (
        SELECT AVG(note)
        FROM avis
        WHERE toilette_id = NEW.toilette_id AND is_visible = 1
    ),
    nombre_avis = (
        SELECT COUNT(*)
        FROM avis
        WHERE toilette_id = NEW.toilette_id AND is_visible = 1
    )
    WHERE id = NEW.toilette_id;
END//

-- Trigger après suppression d'un avis
CREATE TRIGGER update_note_moyenne_after_delete AFTER DELETE ON avis
FOR EACH ROW
BEGIN
    UPDATE toilettes
    SET note_moyenne = COALESCE((
        SELECT AVG(note)
        FROM avis
        WHERE toilette_id = OLD.toilette_id AND is_visible = 1
    ), 0),
    nombre_avis = (
        SELECT COUNT(*)
        FROM avis
        WHERE toilette_id = OLD.toilette_id AND is_visible = 1
    )
    WHERE id = OLD.toilette_id;
END//

DELIMITER ;


-- ╔═══════════════════════════════════════════════════════════════════════════╗
-- ║                          VUES (VIEWS) STATISTIQUES                        ║
-- ╚═══════════════════════════════════════════════════════════════════════════╝

-- Vue: Statistiques globales
CREATE OR REPLACE VIEW stats_globales AS
SELECT
    COUNT(*) as total_toilettes,
    SUM(CASE WHEN acces_pmr = 1 THEN 1 ELSE 0 END) as total_pmr,
    SUM(CASE WHEN payant = 0 THEN 1 ELSE 0 END) as total_gratuit,
    SUM(CASE WHEN ouvert_24_7 = 1 THEN 1 ELSE 0 END) as total_24_7,
    COUNT(DISTINCT commune) as total_communes,
    AVG(note_moyenne) as note_moyenne_globale,
    SUM(nombre_avis) as total_avis
FROM toilettes;

-- Vue: Toilettes les mieux notées
CREATE OR REPLACE VIEW toilettes_top_rated AS
SELECT
    t.*,
    ROUND(t.note_moyenne, 2) as note
FROM toilettes t
WHERE t.nombre_avis >= 3
ORDER BY t.note_moyenne DESC, t.nombre_avis DESC
LIMIT 20;

-- Vue: Statistiques par commune
CREATE OR REPLACE VIEW stats_par_commune AS
SELECT
    commune,
    COUNT(*) as total,
    SUM(acces_pmr = 1) as pmr,
    SUM(payant = 0) as gratuit,
    SUM(ouvert_24_7 = 1) as ouvert_24_7,
    AVG(note_moyenne) as note_moyenne,
    SUM(nombre_avis) as total_avis
FROM toilettes
WHERE commune IS NOT NULL
GROUP BY commune
ORDER BY total DESC;

-- Vue: Activité utilisateurs
CREATE OR REPLACE VIEW user_activity AS
SELECT
    u.id,
    u.username,
    u.role,
    COUNT(DISTINCT a.id) as nombre_avis,
    COUNT(DISTINCT f.id) as nombre_favoris,
    COUNT(DISTINCT r.id) as nombre_reports,
    u.created_at,
    u.last_login
FROM users u
LEFT JOIN avis a ON u.id = a.user_id
LEFT JOIN favorites f ON u.id = f.user_id
LEFT JOIN reports r ON u.id = r.user_id
GROUP BY u.id;


-- ╔═══════════════════════════════════════════════════════════════════════════╗
-- ║                      PROCÉDURES STOCKÉES (MAINTENANCE)                    ║
-- ╚═══════════════════════════════════════════════════════════════════════════╝

DELIMITER //

-- Nettoyer les anciennes tentatives de login (> 30 jours)
CREATE PROCEDURE clean_old_login_attempts()
BEGIN
    DELETE FROM login_attempts
    WHERE attempt_time < DATE_SUB(NOW(), INTERVAL 30 DAY);
END//

-- Nettoyer les tokens expirés
CREATE PROCEDURE clean_expired_tokens()
BEGIN
    DELETE FROM remember_tokens
    WHERE expiry < NOW();
END//

DELIMITER ;


-- ╔═══════════════════════════════════════════════════════════════════════════╗
-- ║                       COMPTE ADMINISTRATEUR                               ║
-- ╚═══════════════════════════════════════════════════════════════════════════╝

-- ========================================
-- CRÉATION DU COMPTE ADMINISTRATEUR
-- ========================================
--
-- ⚠️ IMPORTANT: Le compte admin est créé automatiquement par index.php
-- lors du premier lancement du site. Vous n'avez rien à faire ici.
--
-- Identifiants par défaut:
-- Username: admin
-- Password: Admin123!
--
-- ⚠️ PENSEZ À CHANGER LE MOT DE PASSE après la première connexion !
--


-- ╔═══════════════════════════════════════════════════════════════════════════╗
-- ║                              FIN DU SCRIPT                                ║
-- ╚═══════════════════════════════════════════════════════════════════════════╝

SELECT '✅ Base de données créée avec succès!' as status;
SELECT '📊 8 tables créées (users, toilettes, avis, favorites, reports, login_attempts, remember_tokens, imports_logs)' as tables;
SELECT '🔧 3 triggers créés (mise à jour automatique des notes)' as triggers;
SELECT '📈 4 vues créées (statistiques)' as vues;
SELECT '⚙️ 2 procédures stockées (maintenance)' as procedures;
SELECT '👤 Le compte admin sera créé automatiquement au premier lancement' as admin_info;
SELECT '⚠️ CHANGEZ LE MOT DE PASSE ADMIN IMMÉDIATEMENT!' as securite;
SHOW TABLES;
