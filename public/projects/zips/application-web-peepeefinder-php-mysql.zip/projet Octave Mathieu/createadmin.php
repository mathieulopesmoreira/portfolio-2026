<?php
// fix_admin.php
require_once 'includes/db.php';
header('Content-Type: text/html; charset=utf-8');

$nouveau_password = 'Admin123!';
$hash = password_hash($nouveau_password, PASSWORD_DEFAULT);

$stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE username = 'admin'");
$stmt->execute(array($hash));

echo "✅ Hash admin mis à jour !<br>";
echo "Username: admin<br>";
echo "Password: " . htmlspecialchars($nouveau_password) . "<br>";
echo "<a href='login.php'>Aller à la connexion</a>";
?>
