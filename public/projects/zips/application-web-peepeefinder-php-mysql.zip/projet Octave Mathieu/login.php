<?php
/**
 * ========================================
 * PAGE DE CONNEXION (LOGIN)
 * ========================================
 *
 * Fichier: login.php
 * Description: Formulaire de connexion avec authentification sécurisée
 *
 * Fonctionnalités:
 * - Authentification par username OU email
 * - Vérification du mot de passe avec password_verify()
 * - Protection contre le brute force (rate limiting)
 * - Cookie "Se souvenir de moi" (30 jours)
 * - Reconnexion automatique via token
 * - Support multilingue (FR/EN)
 * - Redirection personnalisable
 * - Tracking des tentatives de connexion échouées
 *
 * Sécurité:
 * - Rate limiting: 5 tentatives max par IP / 15 minutes
 * - Tokens "remember me" hashés en SHA-256
 * - Cookies HttpOnly pour éviter XSS
 * - Enregistrement des tentatives suspectes
 * - Protection CSRF via session
 * - Échappement HTML des sorties
 *
 * Tables utilisées:
 * - users: Authentification et données utilisateur
 * - login_attempts: Tracking des tentatives échouées
 * - remember_tokens: Tokens de reconnexion automatique
 *
 * @author PeePeeFinder Team
 * @version 1.0
 */

// ========================================
// INITIALISATION DE LA SESSION
// ========================================
session_start();
header('Content-Type: text/html; charset=utf-8');

// ========================================
// PROTECTION: Redirection si déjà connecté
// ========================================
// Si l'utilisateur est déjà authentifié, le rediriger vers la carte
if (isset($_SESSION['user_id'])) {
    header('Location: map.php');
    exit();
}

// ========================================
// CONNEXION À LA BASE DE DONNÉES
// ========================================
require_once 'includes/db.php';

// ========================================
// GESTION DE LA LANGUE (i18n)
// ========================================
// Par défaut en français, stocké en session
$lang = isset($_SESSION['lang']) ? $_SESSION['lang'] : 'fr';

// Si changement de langue via URL (?lang=en ou ?lang=fr)
// Préserver le paramètre redirect s'il existe
if (isset($_GET['lang']) && in_array($_GET['lang'], ['fr', 'en'])) {
    $lang = $_GET['lang'];
    $_SESSION['lang'] = $lang;
    // Recharger la page en conservant le paramètre redirect
    header('Location: login.php' . (isset($_GET['redirect']) ? '?redirect=' . urlencode($_GET['redirect']) : ''));
    exit();
}

// ========================================
// VARIABLES POUR LES MESSAGES
// ========================================
$errors = array();  // Tableau pour stocker les erreurs de validation
$success = '';      // Message de succès (non utilisé ici)

// ========================================
// TRAITEMENT DU FORMULAIRE POST
// ========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ----------------------------------------
    // 1. RÉCUPÉRATION ET NETTOYAGE DES DONNÉES
    // ----------------------------------------
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $remember = isset($_POST['remember']);  // Checkbox "Se souvenir de moi"

    // ----------------------------------------
    // 2. VALIDATION DES CHAMPS OBLIGATOIRES
    // ----------------------------------------
    if (empty($username)) {
        $errors[] = $lang === 'fr' ? 'Le nom d\'utilisateur est requis' : 'Username is required';
    }

    if (empty($password)) {
        $errors[] = $lang === 'fr' ? 'Le mot de passe est requis' : 'Password is required';
    }

    // ----------------------------------------
    // 3. TENTATIVE D'AUTHENTIFICATION
    // ----------------------------------------
    // Si toutes les validations précédentes sont passées
    if (empty($errors)) {
        try {
            // ========================================
            // RECHERCHE DE L'UTILISATEUR EN BASE
            // ========================================
            // Accepte username OU email pour plus de flexibilité
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1");
            $stmt->execute(array($username, $username));
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // ========================================
            // VÉRIFICATION DU MOT DE PASSE
            // ========================================
            // password_verify() compare le mot de passe en clair avec le hash bcrypt
            if ($user && password_verify($password, $user['password_hash'])) {

                // ----------------------------------------
                // RATE LIMITING: Vérifier les tentatives récentes
                // ----------------------------------------
                // Compter les tentatives échouées des 15 dernières minutes pour cette IP
                $ip = $_SERVER['REMOTE_ADDR'];
                $stmt = $pdo->prepare("SELECT COUNT(*) as attempts FROM login_attempts WHERE ip_address = ? AND attempt_time > DATE_SUB(NOW(), INTERVAL 15 MINUTE)");
                $stmt->execute(array($ip));
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                $attempts = $result['attempts'];

                // Si plus de 5 tentatives échouées, bloquer temporairement
                if ($attempts >= 5) {
                    $errors[] = $lang === 'fr'
                        ? 'Trop de tentatives. Réessayez dans 15 minutes.'
                        : 'Too many attempts. Try again in 15 minutes.';
                } else {
                    // ========================================
                    // CONNEXION RÉUSSIE: Créer la session
                    // ========================================
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['role'] = $user['role'];
                    $_SESSION['dark_mode'] = (bool)$user['dark_mode'];

                    // ========================================
                    // MISE À JOUR DE LA DATE DE DERNIÈRE CONNEXION
                    // ========================================
                    $stmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
                    $stmt->execute(array($user['id']));

                    // ========================================
                    // NETTOYAGE DES TENTATIVES ÉCHOUÉES
                    // ========================================
                    // Supprimer les tentatives de connexion échouées pour cette IP
                    $stmt = $pdo->prepare("DELETE FROM login_attempts WHERE ip_address = ?");
                    $stmt->execute(array($ip));

                    // ========================================
                    // GESTION DU COOKIE "SE SOUVENIR DE MOI"
                    // ========================================
                    if ($remember) {
                        // Générer un token aléatoire sécurisé (64 caractères hexadécimaux)
                        $token = bin2hex(random_bytes(32));

                        // Expiration dans 30 jours
                        $expiry = time() + (30 * 24 * 60 * 60);

                        // Créer le cookie (HttpOnly = protection XSS)
                        setcookie('remember_token', $token, $expiry, '/', '', false, true);

                        // Stocker le token hashé en base de données (sécurité)
                        // On hash le token avant stockage pour éviter vol direct
                        $stmt = $pdo->prepare("INSERT INTO remember_tokens (user_id, token, expiry) VALUES (?, ?, FROM_UNIXTIME(?))");
                        $stmt->execute(array($user['id'], hash('sha256', $token), $expiry));
                    }

                    // ========================================
                    // REDIRECTION VERS LA PAGE DEMANDÉE
                    // ========================================
                    // Par défaut vers map.php, sinon vers la page spécifiée en paramètre
                    $redirect = isset($_GET['redirect']) ? $_GET['redirect'] : 'map.php';
                    header('Location: ' . $redirect);
                    exit();
                }
            } else {
                // ========================================
                // ÉCHEC DE CONNEXION: Enregistrer la tentative
                // ========================================
                $ip = $_SERVER['REMOTE_ADDR'];
                $stmt = $pdo->prepare("INSERT INTO login_attempts (ip_address, username, attempt_time) VALUES (?, ?, NOW())");
                $stmt->execute(array($ip, $username));

                // Message d'erreur générique pour ne pas révéler si username existe
                $errors[] = $lang === 'fr'
                    ? 'Identifiants incorrects'
                    : 'Invalid credentials';
            }
        } catch (Exception $e) {
            // ========================================
            // GESTION DES ERREURS DE BASE DE DONNÉES
            // ========================================
            // Enregistrer l'erreur technique dans les logs
            error_log("Login error: " . $e->getMessage());

            // Afficher un message générique à l'utilisateur (sécurité)
            $errors[] = $lang === 'fr'
                ? 'Erreur de connexion. Veuillez réessayer.'
                : 'Connection error. Please try again.';
        }
    }
}

// ========================================
// RECONNEXION AUTOMATIQUE VIA COOKIE
// ========================================
// Vérifier le cookie "Se souvenir de moi" si l'utilisateur n'est pas connecté
if (!isset($_SESSION['user_id']) && isset($_COOKIE['remember_token'])) {
    try {
        $token = $_COOKIE['remember_token'];

        // Hasher le token pour correspondre au hash stocké en BDD
        $hashed_token = hash('sha256', $token);

        // ----------------------------------------
        // RECHERCHE DU TOKEN EN BASE DE DONNÉES
        // ----------------------------------------
        $stmt = $pdo->prepare("
            SELECT u.* FROM users u
            INNER JOIN remember_tokens rt ON u.id = rt.user_id
            WHERE rt.token = ? AND rt.expiry > NOW()
            LIMIT 1
        ");
        $stmt->execute(array($hashed_token));
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // ----------------------------------------
        // TOKEN VALIDE: Reconnecter automatiquement
        // ----------------------------------------
        if ($user) {
            // Recréer la session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['dark_mode'] = (bool)$user['dark_mode'];

            // Rediriger vers la carte
            header('Location: map.php');
            exit();
        }
    } catch (Exception $e) {
        // Enregistrer l'erreur mais ne pas bloquer l'affichage de la page
        error_log("Remember token error: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <!-- ========================================
         META TAGS ET CONFIGURATION
         ======================================== -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $lang === 'fr' ? 'Connexion' : 'Login'; ?> - PeePeeFinder</title>

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico">

    <!-- Feuille de style personnalisée -->
    <link rel="stylesheet" href="assets/css/app.css">

    <!-- ========================================
         BIBLIOTHÈQUES EXTERNES (CDN)
         ======================================== -->
    <!-- Tailwind CSS : Framework CSS utility-first -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Feather Icons : Icônes SVG modernes -->
    <script src="https://unpkg.com/feather-icons"></script>

    <!-- ========================================
         STYLES CSS PERSONNALISÉS
         ======================================== -->
    <style>
        /* Container principal avec dégradé violet */
        .login-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        /* Animation d'entrée de la carte */
        .login-card {
            animation: slideIn 0.5s ease-out;
        }

        /* Définition de l'animation slideIn */
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Groupe d'input avec icône */
        .input-group {
            position: relative;
        }

        /* Icône à gauche de l'input */
        .input-icon {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #9ca3af;
        }

        /* Padding pour faire de la place à l'icône gauche */
        .input-field {
            padding-left: 40px;
        }

        /* Icône toggle du mot de passe (œil) */
        .password-toggle {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #9ca3af;
        }

        /* Hover sur l'icône toggle */
        .password-toggle:hover {
            color: #4b5563;
        }
    </style>
</head>
<body class="font-sans antialiased">
    <!-- ========================================
         CONTAINER PRINCIPAL
         ======================================== -->
    <div class="login-container">
        <div class="login-card bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md mx-4">

            <!-- ========================================
                 LOGO ET TITRE
                 ======================================== -->
            <div class="text-center mb-8">
                <a href="index.php" class="inline-flex items-center justify-center text-3xl font-bold text-blue-600">
                    <span class="text-4xl mr-2">🚽</span>
                    PeePeeFinder
                </a>
                <p class="text-gray-600 mt-2">
                    <?php echo $lang === 'fr' ? 'Connectez-vous à votre compte' : 'Sign in to your account'; ?>
                </p>
            </div>

            <!-- ========================================
                 AFFICHAGE DES ERREURS D'AUTHENTIFICATION
                 ======================================== -->
            <?php if (!empty($errors)): ?>
                <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded">
                    <div class="flex items-start">
                        <!-- Icône d'alerte -->
                        <i data-feather="alert-circle" class="text-red-500 mr-2 flex-shrink-0" style="width: 20px; height: 20px;"></i>
                        <div class="flex-1">
                            <!-- Boucle pour afficher toutes les erreurs -->
                            <?php foreach ($errors as $error): ?>
                                <p class="text-red-700 text-sm"><?php echo htmlspecialchars($error); ?></p>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- ========================================
                 MESSAGE DE SUCCÈS (INSCRIPTION RÉUSSIE)
                 ======================================== -->
            <!-- Affiché si redirection depuis register.php avec ?registered=1 -->
            <?php if (isset($_GET['registered'])): ?>
                <div class="bg-green-50 border-l-4 border-green-500 p-4 mb-6 rounded">
                    <div class="flex items-start">
                        <!-- Icône de succès -->
                        <i data-feather="check-circle" class="text-green-500 mr-2 flex-shrink-0" style="width: 20px; height: 20px;"></i>
                        <p class="text-green-700 text-sm">
                            <?php echo $lang === 'fr' ? 'Compte créé avec succès ! Vous pouvez maintenant vous connecter.' : 'Account created successfully! You can now log in.'; ?>
                        </p>
                    </div>
                </div>
            <?php endif; ?>

            <!-- ========================================
                 FORMULAIRE DE CONNEXION
                 ======================================== -->
            <!-- Préserver le paramètre redirect dans l'action du formulaire -->
            <form method="POST" action="login.php<?php echo isset($_GET['redirect']) ? '?redirect=' . urlencode($_GET['redirect']) : ''; ?>" class="space-y-6">

                <!-- ========================================
                     CHAMP: NOM D'UTILISATEUR OU EMAIL
                     ======================================== -->
                <div>
                    <label for="username" class="block text-sm font-medium text-gray-700 mb-2">
                        <?php echo $lang === 'fr' ? 'Nom d\'utilisateur ou Email' : 'Username or Email'; ?>
                    </label>
                    <div class="input-group">
                        <!-- Icône utilisateur -->
                        <i data-feather="user" class="input-icon" style="width: 20px; height: 20px;"></i>

                        <!-- Input accepte username OU email -->
                        <input
                            type="text"
                            id="username"
                            name="username"
                            value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"
                            class="input-field w-full py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition duration-200"
                            placeholder="<?php echo $lang === 'fr' ? 'Votre identifiant' : 'Your username'; ?>"
                            required
                            autocomplete="username"
                        >
                    </div>
                </div>

                <!-- ========================================
                     CHAMP: MOT DE PASSE
                     ======================================== -->
                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700 mb-2">
                        <?php echo $lang === 'fr' ? 'Mot de passe' : 'Password'; ?>
                    </label>
                    <div class="input-group">
                        <!-- Icône cadenas -->
                        <i data-feather="lock" class="input-icon" style="width: 20px; height: 20px;"></i>

                        <!-- Input password (masqué par défaut) -->
                        <input
                            type="password"
                            id="password"
                            name="password"
                            class="input-field w-full py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition duration-200"
                            placeholder="<?php echo $lang === 'fr' ? 'Votre mot de passe' : 'Your password'; ?>"
                            required
                            autocomplete="current-password"
                        >

                        <!-- Icône œil pour afficher/masquer le mot de passe -->
                        <i data-feather="eye" class="password-toggle" id="togglePassword" style="width: 20px; height: 20px;"></i>
                    </div>
                </div>

                <!-- ========================================
                     OPTIONS: SE SOUVENIR & MOT DE PASSE OUBLIÉ
                     ======================================== -->
                <div class="flex items-center justify-between">
                    <!-- Checkbox "Se souvenir de moi" (cookie 30 jours) -->
                    <label class="flex items-center">
                        <input
                            type="checkbox"
                            name="remember"
                            class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                        >
                        <span class="ml-2 text-sm text-gray-600">
                            <?php echo $lang === 'fr' ? 'Se souvenir de moi' : 'Remember me'; ?>
                        </span>
                    </label>

                    <!-- Lien mot de passe oublié -->
                    <a href="#" class="text-sm text-blue-600 hover:text-blue-800 transition duration-200">
                        <?php echo $lang === 'fr' ? 'Mot de passe oublié ?' : 'Forgot password?'; ?>
                    </a>
                </div>

                <!-- ========================================
                     BOUTON SUBMIT
                     ======================================== -->
                <button
                    type="submit"
                    class="w-full bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 focus:ring-4 focus:ring-blue-300 transition duration-200 flex items-center justify-center"
                >
                    <i data-feather="log-in" class="mr-2" style="width: 20px; height: 20px;"></i>
                    <?php echo $lang === 'fr' ? 'Se connecter' : 'Sign in'; ?>
                </button>
            </form>

            <!-- ========================================
                 SÉPARATEUR "OU"
                 ======================================== -->
            <div class="relative my-6">
                <div class="absolute inset-0 flex items-center">
                    <div class="w-full border-t border-gray-300"></div>
                </div>
                <div class="relative flex justify-center text-sm">
                    <span class="px-2 bg-white text-gray-500">
                        <?php echo $lang === 'fr' ? 'ou' : 'or'; ?>
                    </span>
                </div>
            </div>

            <!-- ========================================
                 LIEN VERS LA PAGE D'INSCRIPTION
                 ======================================== -->
            <div class="text-center">
                <p class="text-sm text-gray-600">
                    <?php echo $lang === 'fr' ? 'Pas encore de compte ?' : 'Don\'t have an account?'; ?>
                    <a href="register.php" class="text-blue-600 hover:text-blue-800 font-medium transition duration-200">
                        <?php echo $lang === 'fr' ? 'Inscrivez-vous' : 'Sign up'; ?>
                    </a>
                </p>
            </div>

            <!-- ========================================
                 LIEN RETOUR À L'ACCUEIL
                 ======================================== -->
            <div class="mt-6 text-center">
                <a href="index.php" class="inline-flex items-center text-sm text-gray-600 hover:text-gray-800 transition duration-200">
                    <i data-feather="arrow-left" class="mr-2" style="width: 16px; height: 16px;"></i>
                    <?php echo $lang === 'fr' ? 'Retour à l\'accueil' : 'Back to home'; ?>
                </a>
            </div>

            <!-- ========================================
                 SWITCH DE LANGUE
                 ======================================== -->
            <!-- Préserver le paramètre redirect lors du changement de langue -->
            <div class="mt-6 text-center">
                <?php $new_lang = $lang === 'fr' ? 'en' : 'fr'; ?>
                <button
                    onclick="window.location.href='login.php?lang=<?php echo $new_lang; ?><?php echo isset($_GET['redirect']) ? '&redirect=' . urlencode($_GET['redirect']) : ''; ?>'"
                    class="inline-flex items-center text-sm text-gray-600 hover:text-gray-800 transition duration-200"
                >
                    <i data-feather="globe" class="mr-2" style="width: 16px; height: 16px;"></i>
                    <?php echo $new_lang === 'en' ? 'English' : 'Français'; ?>
                </button>
            </div>
        </div>
    </div>

    <!-- ========================================
         JAVASCRIPT POUR INTERACTIONS
         ======================================== -->
    <script>
        // ========================================
        // INITIALISATION DES ICÔNES FEATHER
        // ========================================
        feather.replace();

        // ========================================
        // TOGGLE VISIBILITÉ DU MOT DE PASSE
        // ========================================
        const togglePassword = document.getElementById('togglePassword');

        togglePassword.addEventListener('click', function() {
            const passwordField = document.getElementById('password');

            // Basculer entre type="password" et type="text"
            if (passwordField.type === 'password') {
                // Afficher le mot de passe
                passwordField.type = 'text';
                // Changer l'icône en "eye-off" (œil barré)
                this.innerHTML = feather.icons['eye-off'].toSvg({ style: 'width: 20px; height: 20px;' });
            } else {
                // Masquer le mot de passe
                passwordField.type = 'password';
                // Changer l'icône en "eye" (œil)
                this.innerHTML = feather.icons['eye'].toSvg({ style: 'width: 20px; height: 20px;' });
            }
        });

        // ========================================
        // AUTO-FOCUS SUR LE PREMIER CHAMP
        // ========================================
        // Placer automatiquement le curseur dans le champ username
        document.getElementById('username').focus();
    </script>

    <!-- ========================================
         INCLUSION DU FOOTER
         ======================================== -->
<?php include 'partials/footer.php'; ?>
</body>
</html>
