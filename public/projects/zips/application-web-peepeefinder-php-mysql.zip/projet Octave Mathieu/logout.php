<?php
/**
 * ========================================
 * PAGE DE DÉCONNEXION (LOGOUT)
 * ========================================
 *
 * Fichier: logout.php
 * Description: Déconnexion sécurisée avec nettoyage complet de session
 *
 * Fonctionnalités:
 * - Déconnexion immédiate de l'utilisateur
 * - Destruction complète de la session PHP
 * - Suppression des tokens "remember me" (base de données + cookie)
 * - Nettoyage des cookies de session
 * - Redirection vers page d'accueil avec paramètre de confirmation
 * - Logging des erreurs éventuelles
 *
 * Sécurité:
 * - Suppression des tokens persistants de la base de données
 * - Suppression du cookie "remember_token" avec expiration passée
 * - Suppression du cookie de session PHP (PHPSESSID)
 * - Destruction complète du tableau $_SESSION
 * - Destruction de la session serveur (session_destroy)
 * - Gestion des erreurs avec logging sans exposition
 *
 * Flux de déconnexion:
 * 1. Démarrage de session (pour accéder aux données)
 * 2. Si utilisateur connecté → nettoyage tokens "remember me"
 * 3. Suppression des variables de session
 * 4. Suppression du cookie de session
 * 5. Destruction de la session serveur
 * 6. Redirection vers index.php?logout=1
 *
 * Tables utilisées:
 * - remember_tokens: Suppression des tokens d'auto-connexion
 *
 * @author PeePeeFinder Team
 * @version 1.0
 */

// ========================================
// 1. INITIALISATION DE SESSION
// ========================================
// Démarrer la session pour accéder aux données utilisateur et effectuer le nettoyage
session_start();

// Inclusion de la connexion à la base de données pour supprimer les tokens
require_once 'includes/db.php';

// ========================================
// 2. NETTOYAGE DES TOKENS "REMEMBER ME"
// ========================================
// Si un utilisateur est connecté, nettoyer ses tokens d'auto-connexion
if (isset($_SESSION['user_id'])) {
    try {
        // ---- Vérifier si un cookie "remember me" existe ----
        if (isset($_COOKIE['remember_token'])) {
            // Récupérer le token en clair du cookie
            $token = $_COOKIE['remember_token'];

            // Hasher le token avec SHA-256 pour comparaison avec la base de données
            // Les tokens sont stockés hashés pour la sécurité
            $hashed_token = hash('sha256', $token);

            // ---- Supprimer le token de la base de données ----
            // Utilisation de prepared statement pour éviter les injections SQL
            $stmt = $pdo->prepare("DELETE FROM remember_tokens WHERE token = ?");
            $stmt->execute([$hashed_token]);

            // ---- Supprimer le cookie du navigateur ----
            // Définir l'expiration dans le passé (time() - 3600) pour forcer la suppression
            // Le "/" indique que le cookie est valable pour tout le site
            setcookie('remember_token', '', time() - 3600, '/');
        }
    } catch (Exception $e) {
        // ---- Gestion des erreurs ----
        // Logger l'erreur sans l'afficher à l'utilisateur (sécurité)
        // La déconnexion continue même en cas d'erreur de nettoyage des tokens
        error_log("Logout error: " . $e->getMessage());
    }
}

// ========================================
// 3. DESTRUCTION DE LA SESSION
// ========================================

// ---- Vider toutes les variables de session ----
// Réinitialiser le tableau $_SESSION à un tableau vide
// Cela supprime toutes les données stockées (user_id, role, lang, etc.)
$_SESSION = [];

// ---- Supprimer le cookie de session PHP ----
// session_name() retourne le nom du cookie de session (généralement PHPSESSID)
if (isset($_COOKIE[session_name()])) {
    // Définir l'expiration dans le passé pour supprimer le cookie
    // Cela force le navigateur à oublier l'identifiant de session
    setcookie(session_name(), '', time() - 3600, '/');
}

// ---- Détruire la session côté serveur ----
// Supprime le fichier de session sur le serveur
// Aucune donnée de session ne persiste après cette étape
session_destroy();

// ========================================
// 4. REDIRECTION
// ========================================
// Rediriger vers la page d'accueil avec paramètre ?logout=1
// Le paramètre permet d'afficher un message de confirmation de déconnexion
header('Location: index.php?logout=1');
exit(); // Arrêter l'exécution du script après la redirection
?>
