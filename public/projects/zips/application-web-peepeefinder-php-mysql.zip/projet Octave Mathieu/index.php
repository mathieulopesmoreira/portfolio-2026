<?php
/**
 * ========================================
 * PAGE D'ACCUEIL (LANDING PAGE)
 * ========================================
 *
 * Fichier: index.php
 * Description: Page d'accueil publique du site PeePeeFinder
 *
 * Fonctionnalités:
 * - Affichage de la page d'accueil avec présentation du projet
 * - Statistiques globales (nombre total de toilettes, PMR, gratuites, communes)
 * - Création automatique du compte administrateur au premier lancement
 * - Gestion multilingue (FR/EN) avec switcher de langue
 * - Arrière-plan animé avec Vanta.js (effet vagues)
 * - Navigation adaptative selon l'état de connexion
 * - Section héro avec call-to-action
 * - Section fonctionnalités (cartes interactives)
 * - Section à propos du projet
 * - Responsive et animations
 *
 * Initialisation automatique:
 * - Vérifie l'existence de la table 'users'
 * - Crée automatiquement un compte 'admin' si inexistant
 * - Identifiants par défaut: admin / Admin123!
 *
 * Sécurité:
 * - Échappement HTML des données affichées (htmlspecialchars)
 * - Vérification de l'existence des tables avant requêtes
 * - Gestion silencieuse des erreurs d'initialisation
 * - Protection contre les injections SQL avec prepared statements
 *
 * SEO et Accessibilité:
 * - Balises meta description et keywords
 * - Balises sémantiques HTML5
 * - Attributs ARIA pour navigation mobile
 * - Structure claire et hiérarchie de titres
 *
 * @author PeePeeFinder Team
 * @version 1.0
 */

// ========================================
// 1. INITIALISATION DE SESSION
// ========================================
session_start();

// Définir l'encodage UTF-8 pour l'affichage correct des caractères accentués
header('Content-Type: text/html; charset=utf-8');

// Inclusion de la connexion à la base de données
require_once 'includes/db.php';

// ========================================
// 2. CRÉATION AUTOMATIQUE DU COMPTE ADMIN
// ========================================
// Cette section s'exécute au premier lancement pour créer le compte administrateur
try {
    // ---- Vérifier si la table 'users' existe ----
    // SHOW TABLES LIKE retourne une ligne si la table existe
    $tableCheck = $pdo->query("SHOW TABLES LIKE 'users'");

    if ($tableCheck->rowCount() > 0) {
        // La table existe, vérifier si un utilisateur 'admin' existe
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = 'admin' LIMIT 1");
        $stmt->execute();
        $adminExists = $stmt->fetch();

        // ---- Si aucun admin n'existe, en créer un ----
        if (!$adminExists) {
            // Identifiants par défaut du compte administrateur
            $admin_username = 'admin';
            $admin_email = 'admin@peepefinder.fr';
            $admin_password = 'Admin123!';  // Mot de passe par défaut (à changer après première connexion)
            $admin_password_hash = password_hash($admin_password, PASSWORD_DEFAULT);

            try {
                // ---- Insérer le compte admin ----
                // email_verified = 1 pour éviter la vérification email
                // role = 'admin' pour les permissions administrateur
                $stmt = $pdo->prepare("INSERT INTO users (username, email, password_hash, role, email_verified, created_at)
                                       VALUES (?, ?, ?, 'admin', 1, NOW())");
                $stmt->execute([$admin_username, $admin_email, $admin_password_hash]);
            } catch (PDOException $insertError) {
                // ---- Gestion de l'email en doublon ----
                // Code 23000 = violation de contrainte d'unicité
                if ($insertError->getCode() == 23000) {
                    // Si l'email existe déjà, utiliser un email unique avec timestamp
                    $admin_email = 'admin' . time() . '@peepefinder.fr';
                    $stmt = $pdo->prepare("INSERT INTO users (username, email, password_hash, role, email_verified, created_at)
                                           VALUES (?, ?, ?, 'admin', 1, NOW())");
                    $stmt->execute([$admin_username, $admin_email, $admin_password_hash]);
                }
            }
        }
    }
} catch (Exception $e) {
    // ---- Gestion des erreurs d'initialisation ----
    // En cas d'erreur, on continue silencieusement pour ne pas bloquer le site
    // L'utilisateur pourra créer manuellement un compte admin si nécessaire
    error_log("Admin creation error: " . $e->getMessage());
}

// ========================================
// 3. RÉCUPÉRATION DES STATISTIQUES
// ========================================
// Récupérer quelques statistiques clés pour afficher sur la page d'accueil
try {
    // ---- Initialiser le tableau de statistiques ----
    $stats = [
        'total' => 0,      // Nombre total de toilettes
        'pmr' => 0,        // Nombre de toilettes accessibles PMR
        'gratuit' => 0,    // Nombre de toilettes gratuites
        'communes' => 0    // Nombre de communes couvertes
    ];

    // ---- Statistique 1: Nombre total de toilettes ----
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM toilettes");
    $stats['total'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

    // ---- Statistique 2: Toilettes accessibles PMR ----
    // acces_pmr = 1 signifie accessible aux Personnes à Mobilité Réduite
    $stmt = $pdo->query("SELECT COUNT(*) as pmr FROM toilettes WHERE acces_pmr = 1");
    $stats['pmr'] = $stmt->fetch(PDO::FETCH_ASSOC)['pmr'];

    // ---- Statistique 3: Toilettes gratuites ----
    // payant = 0 signifie gratuit (pas de paiement requis)
    $stmt = $pdo->query("SELECT COUNT(*) as gratuit FROM toilettes WHERE payant = 0");
    $stats['gratuit'] = $stmt->fetch(PDO::FETCH_ASSOC)['gratuit'];

    // ---- Statistique 4: Nombre de communes distinctes ----
    // COUNT(DISTINCT commune) compte les noms de communes uniques
    $stmt = $pdo->query("SELECT COUNT(DISTINCT commune) as communes FROM toilettes");
    $stats['communes'] = $stmt->fetch(PDO::FETCH_ASSOC)['communes'];

} catch (PDOException $e) {
    // ---- Gestion des erreurs de base de données ----
    // Si la base n'est pas encore configurée ou si les tables n'existent pas,
    // utiliser des valeurs par défaut (0) pour éviter une erreur fatale
    error_log("Stats error: " . $e->getMessage());
    $stats = [
        'total' => 0,
        'pmr' => 0,
        'gratuit' => 0,
        'communes' => 0
    ];
}

// ========================================
// 4. GESTION DE LA LANGUE
// ========================================
// Par défaut français, sinon récupérer depuis la session
$lang = isset($_SESSION['lang']) ? $_SESSION['lang'] : 'fr';

// ---- Switcher de langue via paramètre GET ----
// Si l'utilisateur clique sur le bouton de langue (?lang=en ou ?lang=fr)
if (isset($_GET['lang']) && in_array($_GET['lang'], ['fr', 'en'])) {
    $lang = $_GET['lang'];
    $_SESSION['lang'] = $lang;  // Stocker en session pour persistance
}
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <!-- ========================================
         META TAGS ET SEO
         ======================================== -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $lang === 'fr' ? 'Trouvez facilement des toilettes publiques en Île-de-France' : 'Find public toilets easily in Île-de-France'; ?>">
    <meta name="keywords" content="toilettes publiques, Paris, Île-de-France, PMR, accessibilité">
    <title>PeePeeFinder - <?php echo $lang === 'fr' ? 'Toilettes publiques en Île-de-France' : 'Public toilets in Île-de-France'; ?></title>

    <!-- ========================================
         RESSOURCES CSS ET JS
         ======================================== -->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico">
    <link rel="stylesheet" href="assets/css/app.css">
    <script src="assets/js/app.js" defer></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/feather-icons"></script>
    <!-- Three.js pour les effets 3D de Vanta -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <!-- Vanta.js pour l'arrière-plan animé -->
    <script src="https://cdn.jsdelivr.net/npm/vanta@latest/dist/vanta.waves.min.js"></script>

    <!-- ========================================
         STYLES PERSONNALISÉS
         ======================================== -->
    <style>
        /* Arrière-plan animé Vanta.js */
        .vanta-bg {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            opacity: 0.3;  /* Semi-transparent pour ne pas gêner la lisibilité */
        }

        /* Cartes de statistiques avec effet hover */
        .stat-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);  /* Légère montée au survol */
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);  /* Ombre plus prononcée */
        }

        /* Cartes de fonctionnalités avec effet hover */
        .feature-card {
            transition: all 0.3s ease;
        }
        .feature-card:hover {
            transform: translateY(-10px);  /* Montée plus prononcée */
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
        }

        /* Boutons principaux avec effet hover */
        .btn-primary {
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            transform: scale(1.05);  /* Légère augmentation de taille */
            box-shadow: 0 10px 20px rgba(37, 99, 235, 0.3);
        }

        /* Animation de fade-in au chargement de la page */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .fade-in-up {
            animation: fadeInUp 0.8s ease-out;
        }

        /* Styles pour le mode sombre */
        [data-theme="dark"] {
            background-color: #1f2937;
            color: #f9fafb;
        }
        [data-theme="dark"] .bg-white {
            background-color: #374151 !important;
        }
        [data-theme="dark"] .text-gray-800 {
            color: #f9fafb !important;
        }
        [data-theme="dark"] .text-gray-600 {
            color: #d1d5db !important;
        }
        [data-theme="dark"] .bg-gray-50 {
            background-color: #111827 !important;
        }
        [data-theme="dark"] .bg-blue-50 {
            background-color: #1e3a5f !important;
        }
    </style>
</head>
<body class="font-sans antialiased bg-gray-50" data-theme="<?php echo isset($_SESSION['dark_mode']) && $_SESSION['dark_mode'] ? 'dark' : 'light'; ?>">
    <!-- Arrière-plan animé Vanta.js -->
    <div id="vanta-bg" class="vanta-bg"></div>

    <!-- ========================================
         HEADER - NAVIGATION
         ======================================== -->
    <header class="py-6 px-4 sm:px-6 lg:px-8">
        <div class="max-w-7xl mx-auto flex justify-between items-center nav-wrapper">
            <!-- Logo -->
            <a href="index.php" class="text-2xl font-bold text-blue-600 flex items-center">
                <span class="text-3xl mr-2">🚽</span>
                PeePeeFinder
            </a>

            <!-- Navigation et actions -->
            <div class="flex items-center space-x-4">
                <!-- Bouton menu mobile -->
                <button
                    class="mobile-nav-toggle md:hidden"
                    type="button"
                    aria-controls="primary-navigation"
                    aria-expanded="false"
                    aria-label="<?php echo $lang === 'fr' ? 'Ouvrir le menu' : 'Open menu'; ?>"
                    data-open-label="<?php echo $lang === 'fr' ? 'Ouvrir le menu' : 'Open menu'; ?>"
                    data-close-label="<?php echo $lang === 'fr' ? 'Fermer le menu' : 'Close menu'; ?>"
                >
                    <i data-feather="menu" class="icon-menu"></i>
                    <i data-feather="x" class="icon-close"></i>
                </button>

                <!-- Menu principal -->
                <nav id="primary-navigation" class="hidden md:flex items-center space-x-4 mobile-nav">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <!-- Menu pour utilisateur connecté -->
                        <a href="map.php" class="text-gray-600 hover:text-blue-600 transition duration-300 flex items-center">
                            <i data-feather="map" class="w-4 h-4 mr-2"></i>
                            <span><?php echo $lang === 'fr' ? 'Carte' : 'Map'; ?></span>
                        </a>
                        <a href="dashboard.php" class="text-gray-600 hover:text-blue-600 transition duration-300 flex items-center">
                            <i data-feather="bar-chart-2" class="w-4 h-4 mr-2"></i>
                            <span><?php echo $lang === 'fr' ? 'Dashboard' : 'Dashboard'; ?></span>
                        </a>
                        <a href="profil.php" class="text-gray-600 hover:text-blue-600 transition duration-300 flex items-center">
                            <i data-feather="user" class="w-4 h-4 mr-2"></i>
                            <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                        </a>
                        <a href="logout.php" class="px-4 py-2 bg-red-500 text-white rounded-full hover:bg-red-600 transition duration-300">
                            <?php echo $lang === 'fr' ? 'Déconnexion' : 'Logout'; ?>
                        </a>
                    <?php else: ?>
                        <!-- Menu pour visiteur non connecté -->
                        <a href="login.php" class="text-gray-600 hover:text-blue-600 transition duration-300">
                            <?php echo $lang === 'fr' ? 'Connexion' : 'Login'; ?>
                        </a>
                        <a href="register.php" class="px-4 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition duration-300">
                            <?php echo $lang === 'fr' ? 'Inscription' : 'Sign up'; ?>
                        </a>
                    <?php endif; ?>

                    <!-- Bouton de changement de langue -->
                    <button id="toggleLanguage" class="flex items-center px-3 py-2 border border-blue-500 text-blue-600 rounded-full hover:bg-blue-50 transition duration-300">
                        <i data-feather="globe" class="w-4 h-4 mr-2"></i>
                        <span id="languageText"><?php echo $lang === 'fr' ? 'English' : 'Français'; ?></span>
                    </button>
                </nav>
            </div>
        </div>
    </header>

    <!-- ========================================
         SECTION HÉRO (HERO SECTION)
         ======================================== -->
    <section class="py-16 px-4 sm:px-6 lg:px-8 text-center fade-in-up">
        <!-- Titre principal -->
        <h1 class="text-4xl md:text-6xl font-bold text-gray-800 mb-4">
            <?php echo $lang === 'fr' ? 'PeePeeFinder Paris' : 'PeePeeFinder Paris'; ?>
        </h1>

        <!-- Sous-titre -->
        <p class="text-xl md:text-2xl text-gray-600 mb-8">
            <?php echo $lang === 'fr' ? 'Localisez les toilettes publiques en Île-de-France' : 'Find public toilets in Île-de-France'; ?>
        </p>

        <!-- Boutons d'action (Call-to-Action) -->
        <div class="flex flex-wrap justify-center gap-4">
            <?php if (!isset($_SESSION['user_id'])): ?>
                <!-- Boutons pour visiteurs non connectés -->
                <a href="login.php" class="btn-primary px-8 py-3 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition duration-300 font-medium">
                    <?php echo $lang === 'fr' ? 'Connexion' : 'Login'; ?>
                </a>
                <a href="register.php" class="btn-primary px-8 py-3 bg-white text-blue-600 border-2 border-blue-600 rounded-full hover:bg-blue-50 transition duration-300 font-medium">
                    <?php echo $lang === 'fr' ? 'Créer un compte' : 'Create account'; ?>
                </a>
            <?php endif; ?>

            <!-- Bouton "Explorer la carte" (pour tous) -->
            <!-- Si non connecté, redirige vers login avec redirect vers map -->
            <a href="<?php echo isset($_SESSION['user_id']) ? 'map.php' : 'login.php?redirect=map.php'; ?>" class="btn-primary px-8 py-3 bg-green-600 text-white rounded-full hover:bg-green-700 transition duration-300 font-medium flex items-center">
                <i data-feather="map-pin" class="w-5 h-5 mr-2"></i>
                <?php echo $lang === 'fr' ? 'Explorer la carte' : 'Explore the map'; ?>
            </a>
        </div>
    </section>

    <!-- ========================================
         SECTION STATISTIQUES
         ======================================== -->
    <!-- Afficher uniquement si des données existent -->
    <?php if ($stats['total'] > 0): ?>
    <section class="py-12 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
        <div class="grid grid-cols-2 md:grid-cols-4 gap-6">
            <!-- Statistique 1: Nombre total de toilettes -->
            <div class="stat-card bg-white p-6 rounded-xl shadow-md text-center">
                <div class="text-4xl font-bold text-blue-600 mb-2"><?php echo number_format($stats['total']); ?></div>
                <div class="text-gray-600"><?php echo $lang === 'fr' ? 'Toilettes' : 'Toilets'; ?></div>
            </div>

            <!-- Statistique 2: Toilettes accessibles PMR -->
            <div class="stat-card bg-white p-6 rounded-xl shadow-md text-center">
                <div class="text-4xl font-bold text-green-600 mb-2"><?php echo number_format($stats['pmr']); ?></div>
                <div class="text-gray-600"><?php echo $lang === 'fr' ? 'Accès PMR' : 'PMR Access'; ?></div>
            </div>

            <!-- Statistique 3: Toilettes gratuites -->
            <div class="stat-card bg-white p-6 rounded-xl shadow-md text-center">
                <div class="text-4xl font-bold text-purple-600 mb-2"><?php echo number_format($stats['gratuit']); ?></div>
                <div class="text-gray-600"><?php echo $lang === 'fr' ? 'Gratuit' : 'Free'; ?></div>
            </div>

            <!-- Statistique 4: Nombre de communes -->
            <div class="stat-card bg-white p-6 rounded-xl shadow-md text-center">
                <div class="text-4xl font-bold text-orange-600 mb-2"><?php echo number_format($stats['communes']); ?></div>
                <div class="text-gray-600"><?php echo $lang === 'fr' ? 'Communes' : 'Cities'; ?></div>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- ========================================
         SECTION FONCTIONNALITÉS
         ======================================== -->
    <section class="py-12 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
        <div class="grid md:grid-cols-3 gap-8">
            <!-- Fonctionnalité 1: Carte interactive -->
            <div class="feature-card bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition duration-300">
                <div class="text-blue-500 mb-4">
                    <i data-feather="map" class="w-10 h-10"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">
                    <?php echo $lang === 'fr' ? 'Carte interactive' : 'Interactive map'; ?>
                </h3>
                <p class="text-gray-600">
                    <?php echo $lang === 'fr'
                        ? 'Trouvez les toilettes publiques près de vous avec notre carte interactive et des filtres avancés.'
                        : 'Find public toilets near you with our interactive map and advanced filters.'; ?>
                </p>
            </div>

            <!-- Fonctionnalité 2: Statistiques -->
            <div class="feature-card bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition duration-300">
                <div class="text-blue-500 mb-4">
                    <i data-feather="bar-chart-2" class="w-10 h-10"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">
                    <?php echo $lang === 'fr' ? 'Statistiques' : 'Statistics'; ?>
                </h3>
                <p class="text-gray-600">
                    <?php echo $lang === 'fr'
                        ? 'Découvrez les analyses et tendances sur les toilettes publiques en Île-de-France.'
                        : 'Discover analytics and trends about public toilets in Île-de-France.'; ?>
                </p>
            </div>

            <!-- Fonctionnalité 3: Communauté -->
            <div class="feature-card bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition duration-300">
                <div class="text-blue-500 mb-4">
                    <i data-feather="users" class="w-10 h-10"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">
                    <?php echo $lang === 'fr' ? 'Communauté' : 'Community'; ?>
                </h3>
                <p class="text-gray-600">
                    <?php echo $lang === 'fr'
                        ? 'Contribuez en ajoutant des évaluations et des commentaires sur les toilettes.'
                        : 'Contribute by adding ratings and comments on toilets.'; ?>
                </p>
            </div>

            <!-- Fonctionnalité 4: Filtres avancés -->
            <div class="feature-card bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition duration-300">
                <div class="text-blue-500 mb-4">
                    <i data-feather="search" class="w-10 h-10"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">
                    <?php echo $lang === 'fr' ? 'Filtres avancés' : 'Advanced filters'; ?>
                </h3>
                <p class="text-gray-600">
                    <?php echo $lang === 'fr'
                        ? 'Filtrez par accessibilité PMR, gratuité, disponibilité 24/7 et plus encore.'
                        : 'Filter by PMR accessibility, free access, 24/7 availability and more.'; ?>
                </p>
            </div>

            <!-- Fonctionnalité 5: Système d'avis -->
            <div class="feature-card bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition duration-300">
                <div class="text-blue-500 mb-4">
                    <i data-feather="star" class="w-10 h-10"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">
                    <?php echo $lang === 'fr' ? 'Système d\'avis' : 'Review system'; ?>
                </h3>
                <p class="text-gray-600">
                    <?php echo $lang === 'fr'
                        ? 'Notez et commentez les toilettes pour aider la communauté.'
                        : 'Rate and comment on toilets to help the community.'; ?>
                </p>
            </div>

            <!-- Fonctionnalité 6: Données ouvertes -->
            <div class="feature-card bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition duration-300">
                <div class="text-blue-500 mb-4">
                    <i data-feather="database" class="w-10 h-10"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">
                    <?php echo $lang === 'fr' ? 'Données ouvertes' : 'Open data'; ?>
                </h3>
                <p class="text-gray-600">
                    <?php echo $lang === 'fr'
                        ? 'Utilise les données publiques de la région Île-de-France.'
                        : 'Uses public data from the Île-de-France region.'; ?>
                </p>
            </div>
        </div>
    </section>

    <!-- ========================================
         SECTION À PROPOS
         ======================================== -->
    <section class="py-12 px-4 sm:px-6 lg:px-8 bg-blue-50">
        <div class="max-w-4xl mx-auto text-center">
            <!-- Titre -->
            <h2 class="text-3xl font-bold text-gray-800 mb-6">
                <?php echo $lang === 'fr' ? 'À propos du projet' : 'About the project'; ?>
            </h2>

            <!-- Description du projet -->
            <p class="text-gray-600 mb-8 text-lg leading-relaxed">
                <?php echo $lang === 'fr'
                    ? 'PeePeeFinder utilise les données ouvertes de la région Île-de-France pour vous aider à trouver rapidement des toilettes publiques. Notre objectif est de rendre cette information essentielle accessible à tous, y compris aux personnes à mobilité réduite.'
                    : 'PeePeeFinder uses open data from the Île-de-France region to help you quickly find public toilets. Our goal is to make this essential information accessible to everyone, including people with reduced mobility.'; ?>
            </p>

            <!-- Grille de valeurs (Mission, Accessibilité, Open Data) -->
            <div class="grid md:grid-cols-3 gap-6 mt-8">
                <!-- Valeur 1: Mission -->
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <div class="text-4xl mb-3">🎯</div>
                    <h4 class="font-bold text-gray-800 mb-2">
                        <?php echo $lang === 'fr' ? 'Mission' : 'Mission'; ?>
                    </h4>
                    <p class="text-gray-600 text-sm">
                        <?php echo $lang === 'fr'
                            ? 'Faciliter l\'accès aux toilettes publiques'
                            : 'Facilitate access to public toilets'; ?>
                    </p>
                </div>

                <!-- Valeur 2: Accessibilité -->
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <div class="text-4xl mb-3">♿</div>
                    <h4 class="font-bold text-gray-800 mb-2">
                        <?php echo $lang === 'fr' ? 'Accessibilité' : 'Accessibility'; ?>
                    </h4>
                    <p class="text-gray-600 text-sm">
                        <?php echo $lang === 'fr'
                            ? 'Informations détaillées sur l\'accès PMR'
                            : 'Detailed information on PMR access'; ?>
                    </p>
                </div>

                <!-- Valeur 3: Open Data -->
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <div class="text-4xl mb-3">🌍</div>
                    <h4 class="font-bold text-gray-800 mb-2">
                        <?php echo $lang === 'fr' ? 'Open Data' : 'Open Data'; ?>
                    </h4>
                    <p class="text-gray-600 text-sm">
                        <?php echo $lang === 'fr'
                            ? 'Données publiques et transparentes'
                            : 'Public and transparent data'; ?>
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- ========================================
         FOOTER - Inclure le pied de page commun
         ======================================== -->
    <?php include 'partials/footer.php'; ?>

    <!-- ========================================
         JAVASCRIPT - INTERACTIONS
         ======================================== -->
    <script>
        /**
         * Initialiser les icônes Feather
         * Remplace les balises <i data-feather="..."> par les SVG correspondants
         */
        feather.replace();

        /**
         * Arrière-plan animé Vanta.js (effet vagues)
         * Vérifie que la bibliothèque est chargée avant d'initialiser
         */
        if (typeof VANTA !== 'undefined') {
            VANTA.WAVES({
                el: "#vanta-bg",       // Élément cible
                color: 0x1e40af,       // Couleur bleue
                waveHeight: 20,        // Hauteur des vagues
                shininess: 50,         // Brillance
                waveSpeed: 0.5,        // Vitesse des vagues
                zoom: 0.8              // Niveau de zoom
            });
        }

        /**
         * Switcher de langue
         * Recharge la page avec le paramètre ?lang=xx
         */
        document.getElementById('toggleLanguage').addEventListener('click', function() {
            const currentLang = '<?php echo $lang; ?>';
            const newLang = currentLang === 'fr' ? 'en' : 'fr';
            window.location.href = 'index.php?lang=' + newLang;
        });
    </script>
</body>
</html>
