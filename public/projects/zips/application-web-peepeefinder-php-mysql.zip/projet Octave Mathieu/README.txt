1 - Importer la base de données "database.sql" dans phpMyAdmin
2 - Ouvrir index.php pour accéder au site web
3 - Se connecter avec l' identifiant "admin" et le mot de passe "Admin123!"
4 - Se rendre dans l'onglet import afin d'importer le fichier "toilettes-publiques-en-ile-de-france.csv" qui se trouve dans le dossier uploads du projet
5 - Profiter