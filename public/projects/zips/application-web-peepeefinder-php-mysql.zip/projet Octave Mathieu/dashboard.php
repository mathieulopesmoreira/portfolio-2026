<?php
/**
 * ========================================
 * PAGE DASHBOARD - STATISTIQUES ET ANALYSES
 * ========================================
 *
 * Fichier: dashboard.php
 * Description: Tableau de bord avec statistiques détaillées et visualisations des données
 *
 * **AUTHENTIFICATION REQUISE**
 *
 * Fonctionnalités principales:
 * - Affichage de statistiques globales en temps réel
 * - Visualisations graphiques (graphiques en barres et camemberts)
 * - Analyses par commune (top 10)
 * - Répartition PMR, payant/gratuit, disponibilité 24/7
 * - Graphiques interactifs avec Chart.js et Flot
 * - Statistiques d'avis (moyenne globale, total)
 * - Interface responsive avec mode sombre
 * - Export possible des données (via graphiques)
 *
 * Statistiques affichées:
 * - Nombre total de toilettes
 * - Nombre de toilettes accessibles PMR
 * - Nombre de toilettes gratuites
 * - Nombre de toilettes ouvertes 24/7
 * - Note moyenne globale
 * - Nombre total d'avis
 * - Top 10 communes avec le plus de toilettes
 * - Répartition PMR (graphique camembert)
 * - Répartition payant/gratuit (graphique camembert)
 * - Répartition 24/7 (graphique camembert)
 * - Évolution mensuelle des toilettes (graphique en barres)
 *
 * Bibliothèques de graphiques utilisées:
 * - Chart.js: Graphiques en barres (bar charts) modernes
 * - Flot (jQuery): Graphiques camemberts (pie charts) pour les répartitions
 * - Feather Icons: Icônes SVG pour l'interface
 *
 * Types de graphiques:
 * 1. Graphique en barres (Chart.js):
 *    - Toilettes par commune (top 10)
 *    - Évolution mensuelle (si données de dates disponibles)
 *
 * 2. Graphiques camemberts (Flot):
 *    - Répartition PMR vs Non-PMR
 *    - Répartition Payant vs Gratuit
 *    - Répartition 24/7 vs Horaires limités
 *
 * Sécurité:
 * - Protection par requireLogin() (utilisateurs connectés uniquement)
 * - Headers UTF-8 pour encodage correct
 * - Échappement HTML des données affichées
 * - Préparation des requêtes SQL avec PDO
 *
 * Tables utilisées:
 * - toilettes: Toutes les statistiques principales
 * - avis: Statistiques sur les avis et notes
 *
 * Interactivité:
 * - Mode sombre/clair (toggle)
 * - Graphiques interactifs (hover pour détails)
 * - Navigation responsive (menu mobile)
 * - Mise à jour en temps réel des statistiques
 *
 * Couleurs utilisées (graphiques):
 * - Vert (#10b981): PMR accessible, gratuit, 24/7
 * - Gris (#d1d5db): Non-PMR, payant, horaires limités
 * - Bleu (#3b82f6): Graphiques en barres principales
 * - Dégradés: Pour les graphiques Chart.js
 *
 * @author PeePeeFinder Team
 * @version 1.0
 */

// ========================================
// 1. INITIALISATION ET SÉCURITÉ
// ========================================
session_start();

// Header UTF-8 pour l'affichage correct des caractères accentués
header('Content-Type: text/html; charset=utf-8');

// Inclusions
require_once 'includes/db.php';
require_once 'includes/auth.php';

// ---- Protection : utilisateur doit être connecté ----
// Redirige vers login.php si non connecté
requireLogin();

// ========================================
// 2. CONFIGURATION ET VARIABLES
// ========================================

// ---- Gestion de la langue ----
$lang = isset($_SESSION['lang']) ? $_SESSION['lang'] : 'fr';

// ---- Informations utilisateur ----
$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$role = $_SESSION['role'];
$dark_mode = isset($_SESSION['dark_mode']) ? $_SESSION['dark_mode'] : false;

// Récupérer les statistiques
try {
    // Stats globales
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM toilettes");
    $total_toilettes = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM toilettes WHERE acces_pmr = 1");
    $total_pmr = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM toilettes WHERE payant = 0");
    $total_gratuit = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM toilettes WHERE ouvert_24_7 = 1");
    $total_24_7 = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    $stmt = $pdo->query("SELECT AVG(note_moyenne) as moyenne FROM toilettes WHERE nombre_avis > 0");
    $avgResult = $stmt->fetch(PDO::FETCH_ASSOC);
    $note_globale = isset($avgResult['moyenne']) && $avgResult['moyenne'] !== null
        ? round((float)$avgResult['moyenne'], 2)
        : 0;
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM avis");
    $total_avis = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // Répartition par commune (top 10)
    $stmt = $pdo->query("
        SELECT commune, COUNT(*) as total 
        FROM toilettes 
        GROUP BY commune 
        ORDER BY total DESC 
        LIMIT 10
    ");
    $par_commune = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Répartition par type
    $stmt = $pdo->query("
        SELECT type, COUNT(*) as total 
        FROM toilettes 
        GROUP BY type
    ");
    $par_type = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Évolution (derniers 6 mois)
    $stmt = $pdo->query("
        SELECT DATE_FORMAT(created_at, '%Y-%m') as mois, COUNT(*) as total 
        FROM toilettes 
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
        GROUP BY DATE_FORMAT(created_at, '%Y-%m')
        ORDER BY mois ASC
    ");
    $evolution = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Top communes par note moyenne
    $stmt = $pdo->query("
        SELECT commune, AVG(note_moyenne) as note, COUNT(*) as total
        FROM toilettes
        WHERE nombre_avis > 0
        GROUP BY commune
        HAVING total >= 2
        ORDER BY note DESC
        LIMIT 10
    ");
    $top_notes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // NOUVEAUX TABLEAUX - Données pour les tableaux HTML

    // Tableau 1: Derniers avis avec détails
    $stmt = $pdo->query("
        SELECT
            a.id,
            a.note,
            a.proprete,
            a.commentaire,
            a.created_at,
            u.username,
            t.nom as toilette_nom,
            t.commune
        FROM avis a
        JOIN users u ON a.user_id = u.id
        JOIN toilettes t ON a.toilette_id = t.id
        WHERE a.is_visible = 1
        ORDER BY a.created_at DESC
        LIMIT 10
    ");
    $derniers_avis = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Tableau 2: Toilettes les plus populaires (plus d'avis)
    $stmt = $pdo->query("
        SELECT
            id,
            nom,
            commune,
            note_moyenne,
            nombre_avis,
            acces_pmr,
            payant,
            ouvert_24_7
        FROM toilettes
        WHERE nombre_avis > 0
        ORDER BY nombre_avis DESC
        LIMIT 10
    ");
    $toilettes_populaires = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Tableau 3: Statistiques par type de toilette
    $stmt = $pdo->query("
        SELECT
            type_normalise as type,
            COUNT(*) as nombre,
            SUM(CASE WHEN acces_pmr = 1 THEN 1 ELSE 0 END) as pmr,
            SUM(CASE WHEN payant = 0 THEN 1 ELSE 0 END) as gratuit,
            SUM(CASE WHEN ouvert_24_7 = 1 THEN 1 ELSE 0 END) as ouvert_24_7,
            AVG(CASE WHEN nombre_avis > 0 THEN note_moyenne ELSE NULL END) as note_moyenne
        FROM toilettes
        GROUP BY type_normalise
        ORDER BY nombre DESC
    ");
    $stats_par_type = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Tableau 4: Utilisateurs les plus actifs
    $stmt = $pdo->query("
        SELECT
            u.username,
            COUNT(DISTINCT a.id) as nb_avis,
            COUNT(DISTINCT f.id) as nb_favoris,
            u.created_at
        FROM users u
        LEFT JOIN avis a ON u.id = a.user_id
        LEFT JOIN favorites f ON u.id = f.user_id
        WHERE u.role = 'user'
        GROUP BY u.id
        HAVING nb_avis > 0 OR nb_favoris > 0
        ORDER BY nb_avis DESC
        LIMIT 10
    ");
    $utilisateurs_actifs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Tableau 5: Répartition géographique détaillée
    $stmt = $pdo->query("
        SELECT
            commune,
            COUNT(*) as total,
            SUM(CASE WHEN acces_pmr = 1 THEN 1 ELSE 0 END) as pmr,
            SUM(CASE WHEN payant = 0 THEN 1 ELSE 0 END) as gratuit,
            SUM(CASE WHEN ouvert_24_7 = 1 THEN 1 ELSE 0 END) as ouvert_24_7,
            AVG(CASE WHEN nombre_avis > 0 THEN note_moyenne ELSE NULL END) as note_moyenne,
            SUM(nombre_avis) as total_avis
        FROM toilettes
        WHERE commune IS NOT NULL
        GROUP BY commune
        ORDER BY total DESC
        LIMIT 15
    ");
    $repartition_geo = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    error_log("Dashboard stats error: " . $e->getMessage());
    $total_toilettes = $total_pmr = $total_gratuit = $total_24_7 = 0;
    $note_globale = 0;
    $total_avis = 0;
    $par_commune = array();
    $par_type = array();
    $evolution = array();
    $top_notes = array();
    $derniers_avis = array();
    $toilettes_populaires = array();
    $stats_par_type = array();
    $utilisateurs_actifs = array();
    $repartition_geo = array();
}
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" data-theme="<?php echo $dark_mode ? 'dark' : 'light'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $lang === 'fr' ? 'Tableau de bord' : 'Dashboard'; ?> - PeePeeFinder</title>
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico">
    <link rel="stylesheet" href="assets/css/app.css">
    
    <script src="assets/js/app.js" defer></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/feather-icons"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flot@4.2.6/dist/es5/jquery.flot.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flot@4.2.6/source/jquery.flot.pie.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flot@4.2.6/source/jquery.flot.categories.js"></script>
    
    <style>
        [data-theme="dark"] {
            background-color: #111827;
            color: #f9fafb;
        }
        [data-theme="dark"] .bg-white {
            background-color: #1f2937 !important;
        }
        [data-theme="dark"] .text-gray-800 {
            color: #f9fafb !important;
        }
        [data-theme="dark"] .text-gray-700 {
            color: #e5e7eb !important;
        }
        [data-theme="dark"] .text-gray-600 {
            color: #d1d5db !important;
        }
        [data-theme="dark"] .border-gray-200 {
            border-color: #374151 !important;
        }
        .stat-card {
            transition: all 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        }
        .chart-container {
            position: relative;
            height: 300px;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }
        .data-table thead {
            background-color: #f3f4f6;
        }
        [data-theme="dark"] .data-table thead {
            background-color: #374151;
        }
        .data-table th {
            padding: 12px;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid #e5e7eb;
        }
        [data-theme="dark"] .data-table th {
            border-bottom-color: #4b5563;
        }
        .data-table td {
            padding: 12px;
            border-bottom: 1px solid #f3f4f6;
        }
        [data-theme="dark"] .data-table td {
            border-bottom-color: #374151;
        }
        .data-table tbody tr:hover {
            background-color: #f9fafb;
        }
        [data-theme="dark"] .data-table tbody tr:hover {
            background-color: #1f2937;
        }
        .badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }
        .badge-success {
            background-color: #10b981;
            color: white;
        }
        .badge-danger {
            background-color: #ef4444;
            color: white;
        }
        .badge-warning {
            background-color: #f59e0b;
            color: white;
        }
        .badge-secondary {
            background-color: #6b7280;
            color: white;
        }
        .table-container {
            overflow-x: auto;
            max-height: 500px;
        }
        .fade-in {
            animation: fadeIn 0.5s ease-in;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Custom Legend Styles */
        .custom-legend {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 15px;
            padding: 10px;
            flex-wrap: wrap;
        }
        .legend-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            color: #374151;
        }
        [data-theme="dark"] .legend-item {
            color: #d1d5db;
        }
        .legend-color {
            display: inline-block;
            width: 16px;
            height: 16px;
            border-radius: 3px;
            border: 1px solid rgba(0, 0, 0, 0.1);
        }
        [data-theme="dark"] .legend-color {
            border-color: rgba(255, 255, 255, 0.2);
        }
    </style>
</head>
<body class="font-sans antialiased bg-gray-50">
    <!-- Header -->
    <header class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div class="flex justify-between items-center nav-wrapper">
                    <a href="index.php" class="text-xl font-bold text-blue-600 flex items-center">
                        <span class="text-2xl mr-2">🚽</span>
                        PeePeeFinder
                    </a>

                
                <div class="flex items-center space-x-3 md:space-x-4">
                    <button
                        class="mobile-nav-toggle md:hidden"
                        type="button"
                        aria-controls="primary-navigation"
                        aria-expanded="false"
                        aria-label="<?php echo $lang === 'fr' ? 'Ouvrir le menu' : 'Open menu'; ?>"
                        data-open-label="<?php echo $lang === 'fr' ? 'Ouvrir le menu' : 'Open menu'; ?>"
                        data-close-label="<?php echo $lang === 'fr' ? 'Fermer le menu' : 'Close menu'; ?>"
                    >
                        <i data-feather="menu" class="icon-menu"></i>
                        <i data-feather="x" class="icon-close"></i>
                    </button>

                    <nav id="primary-navigation" class="hidden md:flex items-center space-x-4 mobile-nav">
                        <a href="map.php" class="text-gray-600 hover:text-blue-600 flex items-center">
                            <i data-feather="map" class="w-4 h-4 mr-1"></i>
                            <?php echo $lang === 'fr' ? 'Carte' : 'Map'; ?>
                        </a>
                        <a href="dashboard.php" class="text-blue-600 hover:text-blue-700 flex items-center font-medium">
                            <i data-feather="bar-chart-2" class="w-4 h-4 mr-1"></i>
                            Dashboard
                        </a>
                        <?php if ($role === 'admin'): ?>
                            <a href="import.php" class="text-gray-600 hover:text-blue-600 flex items-center">
                                <i data-feather="upload" class="w-4 h-4 mr-1"></i>
                                Import
                            </a>
                        <?php endif; ?>
                    </nav>
                    <button id="darkModeToggle" class="p-2 rounded-lg hover:bg-gray-100 transition duration-200">
                        <i data-feather="<?php echo $dark_mode ? 'sun' : 'moon'; ?>" class="w-5 h-5"></i>
                    </button>
                    
                    <button onclick="window.location.href='?lang=<?php echo $lang === 'fr' ? 'en' : 'fr'; ?>'" 
                            class="p-2 rounded-lg hover:bg-gray-100 transition duration-200">
                        <i data-feather="globe" class="w-5 h-5"></i>
                    </button>
                    
                    <div class="flex items-center space-x-2">
                        <a href="profil.php" class="text-gray-700 hover:text-blue-600 flex items-center">
                            <i data-feather="user" class="w-4 h-4 mr-1"></i>
                            <span class="hidden sm:inline"><?php echo htmlspecialchars($username); ?></span>
                        </a>
                        <a href="logout.php" class="px-3 py-1 bg-red-500 text-white rounded-lg hover:bg-red-600 transition duration-200 text-sm">
                            <?php echo $lang === 'fr' ? 'Déconnexion' : 'Logout'; ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Page Title -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-800 flex items-center">
                <i data-feather="bar-chart-2" class="w-8 h-8 mr-3 text-blue-600"></i>
                <?php echo $lang === 'fr' ? 'Tableau de bord' : 'Dashboard'; ?>
            </h1>
            <p class="text-gray-600 mt-2">
                <?php echo $lang === 'fr' ? 'Statistiques et analyses des toilettes publiques' : 'Statistics and analysis of public toilets'; ?>
            </p>
        </div>

        <!-- Stats Cards -->
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
            <div class="stat-card bg-white p-6 rounded-xl shadow-md">
                <div class="flex items-center justify-between mb-2">
                    <i data-feather="map-pin" class="w-8 h-8 text-blue-600"></i>
                </div>
                <div class="text-3xl font-bold text-gray-800"><?php echo number_format($total_toilettes); ?></div>
                <div class="text-sm text-gray-600"><?php echo $lang === 'fr' ? 'Total' : 'Total'; ?></div>
            </div>
            
            <div class="stat-card bg-white p-6 rounded-xl shadow-md">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-3xl">♿</span>
                </div>
                <div class="text-3xl font-bold text-green-600"><?php echo number_format($total_pmr); ?></div>
                <div class="text-sm text-gray-600">PMR</div>
            </div>
            
            <div class="stat-card bg-white p-6 rounded-xl shadow-md">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-3xl">💚</span>
                </div>
                <div class="text-3xl font-bold text-purple-600"><?php echo number_format($total_gratuit); ?></div>
                <div class="text-sm text-gray-600"><?php echo $lang === 'fr' ? 'Gratuit' : 'Free'; ?></div>
            </div>
            
            <div class="stat-card bg-white p-6 rounded-xl shadow-md">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-3xl">⏰</span>
                </div>
                <div class="text-3xl font-bold text-yellow-600"><?php echo number_format($total_24_7); ?></div>
                <div class="text-sm text-gray-600">24/7</div>
            </div>
            
            <div class="stat-card bg-white p-6 rounded-xl shadow-md">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-3xl">⭐</span>
                </div>
                <div class="text-3xl font-bold text-orange-600"><?php echo $note_globale; ?></div>
                <div class="text-sm text-gray-600"><?php echo $lang === 'fr' ? 'Note moy.' : 'Avg rating'; ?></div>
            </div>
            
            <div class="stat-card bg-white p-6 rounded-xl shadow-md">
                <div class="flex items-center justify-between mb-2">
                    <i data-feather="message-circle" class="w-8 h-8 text-pink-600"></i>
                </div>
                <div class="text-3xl font-bold text-pink-600"><?php echo number_format($total_avis); ?></div>
                <div class="text-sm text-gray-600"><?php echo $lang === 'fr' ? 'Avis' : 'Reviews'; ?></div>
            </div>
        </div>

        <!-- Charts Grid -->
        <div class="grid md:grid-cols-2 gap-6">
            <!-- Chart 1: Répartition par commune -->
            <div class="bg-white p-6 rounded-xl shadow-md">
                <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                    <i data-feather="map" class="w-5 h-5 mr-2 text-blue-600"></i>
                    <?php echo $lang === 'fr' ? 'Répartition par commune (Top 10)' : 'Distribution by city (Top 10)'; ?>
                </h3>
                <div class="chart-container">
                    <canvas id="chartCommune"></canvas>
                </div>
            </div>

            <!-- Chart 2: Accessibilité PMR -->
            <div class="bg-white p-6 rounded-xl shadow-md">
                <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                    <span class="text-xl mr-2">♿</span>
                    <?php echo $lang === 'fr' ? 'Accessibilité PMR' : 'PMR Accessibility'; ?>
                </h3>
                <div class="chart-container">
                    <div id="chartPMR" style="width:100%;height:300px;"></div>
                </div>
                <div id="legendPMR" class="custom-legend"></div>
            </div>

            <!-- Chart 3: Payant vs Gratuit -->
            <div class="bg-white p-6 rounded-xl shadow-md">
                <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                    <span class="text-xl mr-2">💰</span>
                    <?php echo $lang === 'fr' ? 'Payant vs Gratuit' : 'Paid vs Free'; ?>
                </h3>
                <div class="chart-container">
                    <div id="chartPayant" style="width:100%;height:300px;"></div>
                </div>
                <div id="legendPayant" class="custom-legend"></div>
            </div>

            <!-- Chart 4: Disponibilité 24/7 -->
            <div class="bg-white p-6 rounded-xl shadow-md">
                <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                    <span class="text-xl mr-2">⏰</span>
                    <?php echo $lang === 'fr' ? 'Disponibilité 24/7' : '24/7 Availability'; ?>
                </h3>
                <div class="chart-container">
                    <div id="chart247" style="width:100%;height:300px;"></div>
                </div>
                <div id="legend247" class="custom-legend"></div>
            </div>
        </div>

        <!-- TABLEAUX HTML AVEC DONNÉES SQL -->
        <div class="mt-12">
            <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <i data-feather="table" class="w-6 h-6 mr-3 text-blue-600"></i>
                <?php echo $lang === 'fr' ? 'Données détaillées' : 'Detailed Data'; ?>
            </h2>

            <div class="grid md:grid-cols-2 gap-6">
                <!-- Tableau 1: Derniers Avis -->
                <div class="bg-white p-6 rounded-xl shadow-md col-span-2 fade-in">
                    <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                        <i data-feather="message-square" class="w-5 h-5 mr-2 text-pink-600"></i>
                        <?php echo $lang === 'fr' ? 'Derniers avis' : 'Latest Reviews'; ?>
                    </h3>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th><?php echo $lang === 'fr' ? 'Utilisateur' : 'User'; ?></th>
                                    <th><?php echo $lang === 'fr' ? 'Toilette' : 'Toilet'; ?></th>
                                    <th><?php echo $lang === 'fr' ? 'Commune' : 'City'; ?></th>
                                    <th><?php echo $lang === 'fr' ? 'Note' : 'Rating'; ?></th>
                                    <th><?php echo $lang === 'fr' ? 'Propreté' : 'Cleanliness'; ?></th>
                                    <th><?php echo $lang === 'fr' ? 'Commentaire' : 'Comment'; ?></th>
                                    <th><?php echo $lang === 'fr' ? 'Date' : 'Date'; ?></th>
                                </tr>
                            </thead>
                            <tbody id="derniers-avis-tbody">
                                <?php foreach ($derniers_avis as $avis): ?>
                                <tr>
                                    <td class="font-medium"><?php echo htmlspecialchars($avis['username']); ?></td>
                                    <td><?php echo htmlspecialchars($avis['toilette_nom']); ?></td>
                                    <td><?php echo htmlspecialchars($avis['commune']); ?></td>
                                    <td><span class="badge badge-warning">⭐ <?php echo $avis['note']; ?>/5</span></td>
                                    <td><?php echo $avis['proprete'] ? '✨ ' . $avis['proprete'] . '/5' : '-'; ?></td>
                                    <td class="text-sm"><?php echo $avis['commentaire'] ? htmlspecialchars(substr($avis['commentaire'], 0, 50)) . '...' : '-'; ?></td>
                                    <td class="text-sm text-gray-600"><?php echo date('d/m/Y H:i', strtotime($avis['created_at'])); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Tableau 2: Toilettes Populaires -->
                <div class="bg-white p-6 rounded-xl shadow-md col-span-2 fade-in">
                    <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                        <i data-feather="trending-up" class="w-5 h-5 mr-2 text-blue-600"></i>
                        <?php echo $lang === 'fr' ? 'Toilettes les plus populaires' : 'Most Popular Toilets'; ?>
                    </h3>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th><?php echo $lang === 'fr' ? 'Nom' : 'Name'; ?></th>
                                    <th><?php echo $lang === 'fr' ? 'Commune' : 'City'; ?></th>
                                    <th><?php echo $lang === 'fr' ? 'Note' : 'Rating'; ?></th>
                                    <th><?php echo $lang === 'fr' ? 'Avis' : 'Reviews'; ?></th>
                                    <th>PMR</th>
                                    <th><?php echo $lang === 'fr' ? 'Tarif' : 'Price'; ?></th>
                                    <th>24/7</th>
                                </tr>
                            </thead>
                            <tbody id="toilettes-populaires-tbody">
                                <?php foreach ($toilettes_populaires as $toilette): ?>
                                <tr>
                                    <td class="font-medium"><?php echo htmlspecialchars($toilette['nom']); ?></td>
                                    <td><?php echo htmlspecialchars($toilette['commune']); ?></td>
                                    <td><span class="badge badge-warning">⭐ <?php echo round($toilette['note_moyenne'], 1); ?></span></td>
                                    <td><?php echo $toilette['nombre_avis']; ?> avis</td>
                                    <td><?php echo $toilette['acces_pmr'] ? '<span class="badge badge-success">Oui</span>' : '<span class="badge badge-secondary">Non</span>'; ?></td>
                                    <td><?php echo $toilette['payant'] ? '<span class="badge badge-danger">Payant</span>' : '<span class="badge badge-success">Gratuit</span>'; ?></td>
                                    <td><?php echo $toilette['ouvert_24_7'] ? '<span class="badge badge-warning">Oui</span>' : '<span class="badge badge-secondary">Non</span>'; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Tableau 3: Stats par Type -->
                <div class="bg-white p-6 rounded-xl shadow-md fade-in">
                    <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                        <i data-feather="layers" class="w-5 h-5 mr-2 text-purple-600"></i>
                        <?php echo $lang === 'fr' ? 'Statistiques par type' : 'Statistics by Type'; ?>
                    </h3>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th><?php echo $lang === 'fr' ? 'Type' : 'Type'; ?></th>
                                    <th><?php echo $lang === 'fr' ? 'Nombre' : 'Count'; ?></th>
                                    <th>PMR</th>
                                    <th><?php echo $lang === 'fr' ? 'Gratuit' : 'Free'; ?></th>
                                    <th>24/7</th>
                                    <th><?php echo $lang === 'fr' ? 'Note moy.' : 'Avg rating'; ?></th>
                                </tr>
                            </thead>
                            <tbody id="stats-type-tbody">
                                <?php foreach ($stats_par_type as $stat): ?>
                                <tr>
                                    <td class="font-medium"><?php echo htmlspecialchars($stat['type']); ?></td>
                                    <td><?php echo $stat['nombre']; ?></td>
                                    <td><?php echo $stat['pmr']; ?></td>
                                    <td><?php echo $stat['gratuit']; ?></td>
                                    <td><?php echo $stat['ouvert_24_7']; ?></td>
                                    <td><?php echo $stat['note_moyenne'] ? '<span class="badge badge-warning">⭐ ' . round($stat['note_moyenne'], 1) . '</span>' : '-'; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Tableau 4: Utilisateurs Actifs -->
                <div class="bg-white p-6 rounded-xl shadow-md fade-in">
                    <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                        <i data-feather="users" class="w-5 h-5 mr-2 text-green-600"></i>
                        <?php echo $lang === 'fr' ? 'Utilisateurs actifs' : 'Active Users'; ?>
                    </h3>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th><?php echo $lang === 'fr' ? 'Utilisateur' : 'User'; ?></th>
                                    <th><?php echo $lang === 'fr' ? 'Avis' : 'Reviews'; ?></th>
                                    <th><?php echo $lang === 'fr' ? 'Favoris' : 'Favorites'; ?></th>
                                    <th><?php echo $lang === 'fr' ? 'Membre depuis' : 'Member since'; ?></th>
                                </tr>
                            </thead>
                            <tbody id="utilisateurs-actifs-tbody">
                                <?php foreach ($utilisateurs_actifs as $user): ?>
                                <tr>
                                    <td class="font-medium"><?php echo htmlspecialchars($user['username']); ?></td>
                                    <td><span class="badge badge-success"><?php echo $user['nb_avis']; ?></span></td>
                                    <td><span class="badge badge-danger"><?php echo $user['nb_favoris']; ?></span></td>
                                    <td class="text-sm text-gray-600"><?php echo date('d/m/Y', strtotime($user['created_at'])); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Tableau 5: Répartition Géographique -->
                <div class="bg-white p-6 rounded-xl shadow-md col-span-2 fade-in">
                    <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                        <i data-feather="map-pin" class="w-5 h-5 mr-2 text-blue-600"></i>
                        <?php echo $lang === 'fr' ? 'Répartition géographique détaillée' : 'Detailed Geographic Distribution'; ?>
                    </h3>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th><?php echo $lang === 'fr' ? 'Commune' : 'City'; ?></th>
                                    <th><?php echo $lang === 'fr' ? 'Total' : 'Total'; ?></th>
                                    <th>PMR</th>
                                    <th><?php echo $lang === 'fr' ? 'Gratuit' : 'Free'; ?></th>
                                    <th>24/7</th>
                                    <th><?php echo $lang === 'fr' ? 'Note moy.' : 'Avg rating'; ?></th>
                                    <th><?php echo $lang === 'fr' ? 'Total avis' : 'Total reviews'; ?></th>
                                </tr>
                            </thead>
                            <tbody id="repartition-geo-tbody">
                                <?php foreach ($repartition_geo as $geo): ?>
                                <tr>
                                    <td class="font-medium"><?php echo htmlspecialchars($geo['commune']); ?></td>
                                    <td><span class="badge badge-success"><?php echo $geo['total']; ?></span></td>
                                    <td><?php echo $geo['pmr']; ?></td>
                                    <td><?php echo $geo['gratuit']; ?></td>
                                    <td><?php echo $geo['ouvert_24_7']; ?></td>
                                    <td><?php echo $geo['note_moyenne'] ? '<span class="badge badge-warning">⭐ ' . round($geo['note_moyenne'], 1) . '</span>' : '-'; ?></td>
                                    <td><?php echo $geo['total_avis']; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Refresh button -->
        <div class="mt-8 text-center">
            <button onclick="location.reload()" class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-200 flex items-center mx-auto">
                <i data-feather="refresh-cw" class="w-5 h-5 mr-2"></i>
                <?php echo $lang === 'fr' ? 'Actualiser les données' : 'Refresh data'; ?>
            </button>
        </div>
    </main>

    <script>
        // Initialize Feather Icons
        feather.replace();

        // Données PHP vers JavaScript
        var parCommune = <?php echo json_encode($par_commune); ?>;
        var parType = <?php echo json_encode($par_type); ?>;
        var evolution = <?php echo json_encode($evolution); ?>;
        var topNotes = <?php echo json_encode($top_notes); ?>;
        var totalToilettes = <?php echo $total_toilettes; ?>;
        var totalPMR = <?php echo $total_pmr; ?>;
        var totalGratuit = <?php echo $total_gratuit; ?>;
        var total247 = <?php echo $total_24_7; ?>;
        var lang = '<?php echo $lang; ?>';

        // ==============================================
        // GRAPHIQUES MIXTES: Chart.js + Flot jQuery
        // ==============================================

        // Chart 1: Répartition par commune (Chart.js - Barres)
        var ctxCommune = document.getElementById('chartCommune').getContext('2d');
        new Chart(ctxCommune, {
            type: 'bar',
            data: {
                labels: parCommune.map(function(item) { return item.commune; }),
                datasets: [{
                    label: lang === 'fr' ? 'Nombre de toilettes' : 'Number of toilets',
                    data: parCommune.map(function(item) { return item.total; }),
                    backgroundColor: '#3b82f6',
                    borderRadius: 5
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });

        // Chart 2: PMR (Flot Pie avec pourcentages)
        var pmrData = [
            { label: lang === 'fr' ? 'Accessible PMR' : 'PMR Accessible', data: totalPMR, color: '#10b981' },
            { label: lang === 'fr' ? 'Non accessible' : 'Not accessible', data: totalToilettes - totalPMR, color: '#d1d5db' }
        ];
        $.plot('#chartPMR', pmrData, {
            series: {
                pie: {
                    show: true,
                    radius: 1,
                    label: {
                        show: true,
                        radius: 0.75,
                        formatter: function(label, series) {
                            return '<div style="font-size:11px; text-align:center; padding:2px; color:white;">' +
                                   Math.round(series.percent) + '%</div>';
                        },
                        background: { opacity: 0.8 }
                    }
                }
            },
            legend: { show: false }
        });

        // Custom legend for PMR
        var legendPMR = '<div class="legend-item"><span class="legend-color" style="background: #10b981;"></span><span>' +
                        (lang === 'fr' ? 'Accessible PMR' : 'PMR Accessible') + '</span></div>';
        legendPMR += '<div class="legend-item"><span class="legend-color" style="background: #d1d5db;"></span><span>' +
                     (lang === 'fr' ? 'Non accessible' : 'Not accessible') + '</span></div>';
        $('#legendPMR').html(legendPMR);

        // Chart 3: Payant vs Gratuit (Flot Pie avec pourcentages)
        var payantData = [
            { label: lang === 'fr' ? 'Gratuit' : 'Free', data: totalGratuit, color: '#10b981' },
            { label: lang === 'fr' ? 'Payant' : 'Paid', data: totalToilettes - totalGratuit, color: '#ef4444' }
        ];
        $.plot('#chartPayant', payantData, {
            series: {
                pie: {
                    show: true,
                    radius: 1,
                    label: {
                        show: true,
                        radius: 0.75,
                        formatter: function(label, series) {
                            return '<div style="font-size:11px; text-align:center; padding:2px; color:white;">' +
                                   Math.round(series.percent) + '%</div>';
                        },
                        background: { opacity: 0.8 }
                    }
                }
            },
            legend: { show: false }
        });

        // Custom legend for Payant
        var legendPayant = '<div class="legend-item"><span class="legend-color" style="background: #10b981;"></span><span>' +
                           (lang === 'fr' ? 'Gratuit' : 'Free') + '</span></div>';
        legendPayant += '<div class="legend-item"><span class="legend-color" style="background: #ef4444;"></span><span>' +
                        (lang === 'fr' ? 'Payant' : 'Paid') + '</span></div>';
        $('#legendPayant').html(legendPayant);

        // Chart 4: 24/7 (Flot Pie avec pourcentages)
        var data247 = [
            { label: lang === 'fr' ? 'Ouvert 24/7' : 'Open 24/7', data: total247, color: '#f59e0b' },
            { label: lang === 'fr' ? 'Horaires limités' : 'Limited hours', data: totalToilettes - total247, color: '#6b7280' }
        ];
        $.plot('#chart247', data247, {
            series: {
                pie: {
                    show: true,
                    radius: 1,
                    label: {
                        show: true,
                        radius: 0.75,
                        formatter: function(label, series) {
                            return '<div style="font-size:11px; text-align:center; padding:2px; color:white;">' +
                                   Math.round(series.percent) + '%</div>';
                        },
                        background: { opacity: 0.8 }
                    }
                }
            },
            legend: { show: false }
        });

        // Custom legend for 24/7
        var legend247 = '<div class="legend-item"><span class="legend-color" style="background: #f59e0b;"></span><span>' +
                        (lang === 'fr' ? 'Ouvert 24/7' : 'Open 24/7') + '</span></div>';
        legend247 += '<div class="legend-item"><span class="legend-color" style="background: #6b7280;"></span><span>' +
                     (lang === 'fr' ? 'Horaires limités' : 'Limited hours') + '</span></div>';
        $('#legend247').html(legend247);

        // Dark mode toggle
        document.getElementById('darkModeToggle').addEventListener('click', function() {
            fetch('api/toggle_dark_mode.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(function(response) { return response.json(); })
            .then(function(data) {
                if (data.success) {
                    location.reload();
                }
            })
            .catch(function(error) {
                console.error('Error:', error);
            });
        });

        // ========================================
        // JQUERY INTERACTIONS
        // ========================================
        $(document).ready(function() {
            console.log('jQuery loaded successfully!');

            // 1. Animation au survol des lignes de tableau
            $('.data-table tbody tr').hover(
                function() {
                    $(this).css('background-color', 'rgba(59, 130, 246, 0.1)');
                },
                function() {
                    $(this).css('background-color', '');
                }
            );

            // 2. Filtrage des tableaux en temps réel
            $('<input type="text" class="w-full px-4 py-2 border rounded-lg mb-4" placeholder="' + (lang === 'fr' ? 'Rechercher...' : 'Search...') + '">').insertBefore('.data-table').on('keyup', function() {
                var searchTerm = $(this).val().toLowerCase();
                var table = $(this).next('.data-table');

                table.find('tbody tr').each(function() {
                    var rowText = $(this).text().toLowerCase();
                    $(this).toggle(rowText.indexOf(searchTerm) > -1);
                });
            });

            // 3. Tri des colonnes au clic sur les en-têtes
            $('.data-table th').css('cursor', 'pointer').on('click', function() {
                var table = $(this).parents('table').eq(0);
                var rows = table.find('tbody tr').toArray().sort(comparer($(this).index()));
                this.asc = !this.asc;
                if (!this.asc) { rows = rows.reverse(); }
                for (var i = 0; i < rows.length; i++) { table.find('tbody').append(rows[i]); }

                // Indicateur visuel de tri
                table.find('th').removeClass('sorted-asc sorted-desc');
                $(this).addClass(this.asc ? 'sorted-asc' : 'sorted-desc');
            });

            function comparer(index) {
                return function(a, b) {
                    var valA = getCellValue(a, index), valB = getCellValue(b, index);
                    return $.isNumeric(valA) && $.isNumeric(valB) ? valA - valB : valA.toString().localeCompare(valB);
                }
            }

            function getCellValue(row, index) {
                return $(row).children('td').eq(index).text();
            }

            // 4. Animation de compteur pour les stats cards
            $('.stat-card .text-3xl').each(function() {
                var $this = $(this);
                var originalText = $this.text();
                var hasSuffix = originalText.includes('/5');
                var countTo = originalText.replace(/[^0-9.]/g, '');

                if (countTo && !isNaN(countTo)) {
                    $({ countNum: 0 }).animate({
                        countNum: countTo
                    }, {
                        duration: 2000,
                        easing: 'swing',
                        step: function() {
                            var displayNum = Math.floor(this.countNum).toLocaleString();
                            $this.text(hasSuffix ? displayNum + '/5' : displayNum);
                        },
                        complete: function() {
                            var finalNum = countTo.indexOf('.') > -1 ? parseFloat(countTo).toFixed(2) : Math.floor(this.countNum).toLocaleString();
                            $this.text(hasSuffix ? finalNum + '/5' : finalNum);
                        }
                    });
                }
            });

            // 5. Tooltip sur les badges
            $('.badge').attr('title', function() {
                return $(this).text();
            }).css('cursor', 'help');

            // 6. Effet de highlight sur les nouvelles données
            $('.fade-in').each(function(index) {
                $(this).css('opacity', '0').delay(index * 100).animate({ opacity: 1 }, 500);
            });

            // 7. Export tableau en CSV avec jQuery
            $('.table-container').each(function() {
                var container = $(this);
                var table = container.find('.data-table');
                var exportBtn = $('<button class="export-csv-btn px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 mb-3">' + (lang === 'fr' ? '📥 Exporter CSV' : '📥 Export CSV') + '</button>');

                exportBtn.on('click', function() {
                    var csv = [];
                    var rows = table.find('tr');

                    rows.each(function() {
                        var row = [];
                        var cols = $(this).find('td, th');
                        cols.each(function() {
                            var text = $(this).text().trim();
                            row.push('"' + text.replace(/"/g, '""') + '"');
                        });
                        csv.push(row.join(','));
                    });

                    var csvString = csv.join('\n');
                    var blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
                    var link = document.createElement('a');
                    var url = URL.createObjectURL(blob);
                    link.setAttribute('href', url);
                    link.setAttribute('download', 'peepefinder_export_' + Date.now() + '.csv');
                    link.style.visibility = 'hidden';
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                });

                container.before(exportBtn);
            });

            // 8. Accordion pour masquer/afficher les tableaux
            $('.table-container').each(function() {
                var container = $(this);
                var title = container.prev('h3');

                if (title.length > 0 && !title.find('.toggle-icon').length) {
                    title.css('cursor', 'pointer').prepend('<span class="toggle-icon mr-2">▼</span>');

                    title.on('click', function() {
                        container.slideToggle(300);
                        $(this).find('.toggle-icon').text(container.is(':visible') ? '▼' : '▶');
                    });
                }
            });

            // 9. Ajout de styles pour le tri
            $('<style>.sorted-asc:after { content: " ▲"; } .sorted-desc:after { content: " ▼"; }</style>').appendTo('head');

            console.log('Toutes les interactions jQuery sont actives!');
        });
    </script>
<?php include 'partials/footer.php'; ?>
</body>
</html>
