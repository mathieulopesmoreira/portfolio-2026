<?php
/**
 * ========================================
 * PAGE D'IMPORT DE DONNÉES CSV (ADMIN)
 * ========================================
 *
 * Fichier: import.php
 * Description: Interface d'administration pour importer des données de toilettes depuis un fichier CSV
 *
 * **ACCÈS RÉSERVÉ AUX ADMINISTRATEURS**
 *
 * Fonctionnalités principales:
 * - Import de fichiers CSV avec données de toilettes publiques
 * - Support format CSV avec séparateur point-virgule (;)
 * - Parsing intelligent des coordonnées GPS (formats multiples)
 * - Normalisation automatique des types de toilettes
 * - Détection et traitement des doublons (adresse + code postal)
 * - Validation complète des données avant insertion
 * - Support encodage UTF-8 avec BOM
 * - Affichage des statistiques d'import (importées, mises à jour, échecs)
 * - Historique des imports dans la base de données
 * - Option de suppression massive de toutes les données
 * - Interface responsive avec feedback en temps réel
 *
 * Format CSV attendu:
 * - Séparateur: point-virgule (;)
 * - Encodage: UTF-8
 * - En-tête obligatoire avec noms de colonnes
 * - Taille maximale: 10 MB
 *
 * Colonnes CSV supportées:
 * - nom: Nom de la toilette
 * - adresse: Adresse complète
 * - commune: Nom de la commune
 * - code_postal: Code postal
 * - coord_geo: Coordonnées GPS (formats: "lat,lon" ou "lat lon" ou "lat")
 * - acces_pmr: Accessibilité PMR (Oui/Non/1/0)
 * - payant: Toilettes payantes (Oui/Non/1/0)
 * - ouvert_24_7: Ouvert 24/7 (Oui/Non/1/0)
 * - Type: Type de toilette (sera normalisé)
 * - horaires: Horaires d'ouverture
 * - Horaires d'ouverture: Horaires (alternative)
 * - description: Description
 * - Source: Source des données
 *
 * Normalisation des types:
 * - "TOILETTES PUBLIQUES" → "public"
 * - "SANISETTE" → "automatique"
 * - "TOILETTE AUTOMATIQUE" → "automatique"
 * - "WC PUBLICS" → "public"
 * - Autres → lowercase sans espaces
 *
 * Logique de doublon:
 * - Clé unique: adresse + code postal
 * - Si existe: mise à jour des données existantes
 * - Si nouveau: insertion d'un nouvel enregistrement
 *
 * Sécurité:
 * - Protection par requireAdmin() (seuls les admins peuvent importer)
 * - Validation de la taille du fichier (max 10 MB)
 * - Validation de l'extension (.csv, .txt)
 * - Échappement des données avant insertion
 * - Prepared statements PDO contre injections SQL
 * - Logging de toutes les opérations d'import
 *
 * Tables utilisées:
 * - toilettes: Insertion/mise à jour des données de toilettes
 * - imports_logs: Historique des imports (succès/échecs)
 *
 * Statistiques affichées:
 * - Nombre de toilettes total en base
 * - Nombre de toilettes PMR
 * - Nombre de toilettes gratuites
 * - Nombre de communes couvertes
 * - Derniers imports effectués (historique)
 *
 * Actions disponibles:
 * - Importer un fichier CSV
 * - Supprimer toutes les données (avec confirmation JavaScript)
 * - Voir les statistiques en temps réel
 * - Consulter l'historique des imports
 *
 * @author PeePeeFinder Team
 * @version 1.0
 */

// ========================================
// 1. INITIALISATION ET SÉCURITÉ
// ========================================
session_start();
require_once 'includes/db.php';
require_once 'includes/auth.php';

// ---- Protection : admin uniquement ----
// Redirige vers index.php si l'utilisateur n'est pas administrateur
requireAdmin();

// ========================================
// 2. CONFIGURATION ET VARIABLES
// ========================================

// ---- Gestion de la langue ----
$lang = isset($_SESSION['lang']) ? $_SESSION['lang'] : 'fr';

// ---- Informations utilisateur ----
$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$dark_mode = isset($_SESSION['dark_mode']) ? $_SESSION['dark_mode'] : false;

// ---- Variables de traitement ----
$errors = array();  // Tableau pour stocker les erreurs
$success = '';      // Message de succès
$stats = array('imported' => 0, 'updated' => 0, 'failed' => 0);  // Statistiques d'import

// Traitement suppression de toutes les données
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_all') {
    try {
        // On ne peut pas utiliser TRUNCATE directement à cause des clés étrangères.
        // On désactive les contraintes, on vide les tables, puis on les réactive.
        $pdo->exec("SET FOREIGN_KEY_CHECKS=0;");
        $pdo->exec("TRUNCATE TABLE toilettes;");
        $pdo->exec("TRUNCATE TABLE avis;");
        $pdo->exec("TRUNCATE TABLE favorites;");
        $pdo->exec("TRUNCATE TABLE reports;");
        $pdo->exec("SET FOREIGN_KEY_CHECKS=1;");

        $success = $lang === 'fr' ? 'Toutes les données des toilettes ont été supprimées avec succès.' : 'All toilet data has been successfully deleted.';

        // Log de l'action
        $stmt = $pdo->prepare("
            INSERT INTO imports_logs (user_id, filename, status, error_log, import_date)
            VALUES (?, 'DELETE_ALL', 'success', 'All toilets deleted by user', NOW())
        ");
        $stmt->execute(array($user_id));
    } catch (Exception $e) {
        error_log("Delete all toilets error: " . $e->getMessage());
        $errors[] = $lang === 'fr' ? 'Erreur lors de la suppression des données : ' . $e->getMessage() : 'Error deleting data: ' . $e->getMessage();
    }
}

// Traitement import CSV
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    $file = $_FILES['csv_file'];
    
    // Validation fichier
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors[] = $lang === 'fr' ? 'Erreur lors de l\'upload du fichier' : 'File upload error';
    } elseif ($file['size'] > 10 * 1024 * 1024) { // Max 10MB
        $errors[] = $lang === 'fr' ? 'Le fichier est trop volumineux (max 10MB)' : 'File is too large (max 10MB)';
    } else {
        // Vérifier l'extension du fichier (au lieu de finfo_open qui n'est pas activé)
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed_extensions = array('csv', 'txt');
        
        if (!in_array($extension, $allowed_extensions)) {
            $errors[] = $lang === 'fr' ? 'Format de fichier invalide. Utilisez un fichier CSV.' : 'Invalid file format. Use a CSV file.';
        }
    }
    
    if (empty($errors)) {
        $start_time = time();
        
        try {
            $handle = fopen($file['tmp_name'], 'r');
            if ($handle === false) {
                throw new Exception('Impossible d\'ouvrir le fichier');
            }
            
            // Lire l'en-tête avec point-virgule comme séparateur
            $header = fgetcsv($handle, 10000, ';');
            if ($header === false) {
                throw new Exception('Fichier CSV vide ou invalide');
            }
            
            // Nettoyer les en-têtes (supprimer espaces et BOM)
            $header = array_map(function($h) {
                return trim(str_replace("\xEF\xBB\xBF", '', $h));
            }, $header);
            
            // Traiter les lignes avec point-virgule comme séparateur
            $line_number = 1;
            while (($data = fgetcsv($handle, 10000, ';')) !== false) {
                $line_number++;
                
                // Créer un tableau associatif
                $row = array();
                foreach ($header as $i => $col) {
                    $row[$col] = isset($data[$i]) ? trim($data[$i]) : '';
                }
                
                // Extraction des coordonnées depuis coord_geo
                // Format possible: "49.0095751428167, 2.123456" ou "49.0095751428167 2.123456" ou juste "49.0095751428167"
                $latitude = null;
                $longitude = null;
                if (!empty($row['coord_geo'])) {
                    // Essayer avec virgule
                    if (strpos($row['coord_geo'], ',') !== false) {
                        $coords = explode(',', $row['coord_geo']);
                        if (count($coords) >= 2) {
                            $latitude = floatval(trim($coords[0]));
                            $longitude = floatval(trim($coords[1]));
                        }
                    } 
                    // Essayer avec espace
                    elseif (strpos($row['coord_geo'], ' ') !== false) {
                        $coords = explode(' ', trim($row['coord_geo']));
                        $coords = array_filter($coords); // Enlever les espaces vides
                        $coords = array_values($coords); // Réindexer
                        if (count($coords) >= 2) {
                            $latitude = floatval($coords[0]);
                            $longitude = floatval($coords[1]);
                        }
                    }
                    // Si seulement une coordonnée, ignorer
                    else {
                        $latitude = null;
                        $longitude = null;
                    }
                }
                
                // Validation : coordonnées obligatoires
                if (empty($latitude) || empty($longitude)) {
                    $stats['failed']++;
                    continue;
                }
                
                // Normaliser les booléens depuis les textes OpenData
                $accessible_public = isset($row['Accessible au public']) ? strtolower($row['Accessible au public']) : '';
                $payant = (isset($row['Tarif']) && (stripos($row['Tarif'], 'payant') !== false || stripos($row['Tarif'], 'gratuit') === false)) ? 1 : 0;
                $acces_pmr = (isset($row['Accessibilite PMR']) && (stripos($row['Accessibilite PMR'], 'oui') !== false || stripos($row['Accessibilite PMR'], 'accessible') !== false)) ? 1 : 0;
                
                // Détection 24/7 plus robuste
                $horaires_bruts = isset($row["Horaires d'ouverture"]) ? $row["Horaires d'ouverture"] : '';
                $ouvert_24_7 = (stripos($horaires_bruts, '24 h / 24') !== false || 
                                stripos($horaires_bruts, '24/24') !== false ||
                                trim($horaires_bruts) === '24h/24' ||
                                stripos($horaires_bruts, '24/7') !== false) ? 1 : 0;
                
                // Type normalisé
                $type_brut = isset($row['Type']) ? strtolower($row['Type']) : '';
                $type_normalise = 'autres';
                if (stripos($type_brut, 'sanisette') !== false) {
                    $type_normalise = 'sanisette';
                } elseif (stripos($type_brut, 'publique') !== false || stripos($type_brut, 'public') !== false) {
                    $type_normalise = 'toilettes_publiques';
                }
                
                // Nom (utiliser Source ou Type ou localisation)
                $nom = '';
                if (!empty($row['Source'])) {
                    $nom = $row['Source'];
                } elseif (!empty($row['Type'])) {
                    $nom = $row['Type'];
                } elseif (!empty($row['Indications de localisation'])) {
                    $nom = $row['Indications de localisation'];
                } else {
                    $nom = 'Toilettes publiques';
                }
                
                // Source ID unique (osm_id ou généré)
                if (!empty($row['osm_id'])) {
                    $source_id = 'OSM_' . $row['osm_id'];
                } else {
                    // Créer un hash stable basé sur les coordonnées et la commune pour les entrées sans osm_id
                    $unique_string = $latitude . $longitude . (isset($row['nom_de_la_commune']) ? $row['nom_de_la_commune'] : '');
                    $source_id = 'GEN_' . md5($unique_string);
                }
                
                // Commune
                $commune = !empty($row['nom_de_la_commune']) ? $row['nom_de_la_commune'] : '';
                
                // Code postal (extraire depuis code_geogrephique_commune ou code_geographique_departement)
                $code_postal = '';
                if (!empty($row['code_geogrephique_commune'])) {
                    $code_postal = substr($row['code_geogrephique_commune'], 0, 5);
                } elseif (!empty($row['code_geographique_departement'])) {
                    $code_postal = $row['code_geographique_departement'];
                }
                
                // Vérifier si existe déjà
                $stmt = $pdo->prepare("SELECT id FROM toilettes WHERE source_id = ?");
                $stmt->execute(array($source_id));
                $existing = $stmt->fetch();
                
                if ($existing) {
                    // UPDATE
                    $stmt = $pdo->prepare("
                        UPDATE toilettes SET
                            Source = ?,
                            `Accessible au public` = ?,
                            Tarif = ?,
                            `Accessibilite PMR` = ?,
                            `Indications de localisation` = ?,
                            Type = ?,
                            `Horaires d'ouverture` = ?,
                            `Relais bébé` = ?,
                            coord_geo = ?,
                            osm_id = ?,
                            nom_de_la_commune = ?,
                            code_geogrephique_commune = ?,
                            nom_departement = ?,
                            code_geographique_departement = ?,
                            nom = ?,
                            type_normalise = ?,
                            adresse = ?,
                            commune = ?,
                            code_postal = ?,
                            payant = ?,
                            acces_pmr = ?,
                            ouvert_24_7 = ?,
                            latitude = ?,
                            longitude = ?,
                            horaires = ?,
                            date_maj = CURDATE(),
                            updated_at = NOW()
                        WHERE source_id = ?
                    ");
                    $stmt->execute(array(
                        isset($row['Source']) ? $row['Source'] : '',
                        isset($row['Accessible au public']) ? $row['Accessible au public'] : '',
                        isset($row['Tarif']) ? $row['Tarif'] : '',
                        isset($row['Accessibilite PMR']) ? $row['Accessibilite PMR'] : '',
                        isset($row['Indications de localisation']) ? $row['Indications de localisation'] : '',
                        isset($row['Type']) ? $row['Type'] : '',
                        isset($row["Horaires d'ouverture"]) ? $row["Horaires d'ouverture"] : '',
                        isset($row['Relais bébé']) ? $row['Relais bébé'] : '',
                        isset($row['coord_geo']) ? $row['coord_geo'] : '',
                        isset($row['osm_id']) ? $row['osm_id'] : '',
                        isset($row['nom_de_la_commune']) ? $row['nom_de_la_commune'] : '',
                        isset($row['code_geogrephique_commune']) ? $row['code_geogrephique_commune'] : '',
                        isset($row['nom_departement']) ? $row['nom_departement'] : '',
                        isset($row['code_geographique_departement']) ? $row['code_geographique_departement'] : '',
                        $nom,
                        $type_normalise,
                        isset($row['Indications de localisation']) ? $row['Indications de localisation'] : '',
                        $commune,
                        $code_postal,
                        $payant,
                        $acces_pmr,
                        $ouvert_24_7,
                        $latitude,
                        $longitude,
                        isset($row["Horaires d'ouverture"]) ? $row["Horaires d'ouverture"] : '',
                        $source_id
                    ));
                    $stats['updated']++;
                } else {
                    // INSERT
                    $stmt = $pdo->prepare("
                        INSERT INTO toilettes (
                            Source, `Accessible au public`, Tarif, `Accessibilite PMR`,
                            `Indications de localisation`, Type, `Horaires d'ouverture`, `Relais bébé`,
                            coord_geo, osm_id, nom_de_la_commune, code_geogrephique_commune,
                            nom_departement, code_geographique_departement,
                            nom, type_normalise, adresse, commune, code_postal,
                            payant, acces_pmr, ouvert_24_7, latitude, longitude, horaires,
                            source_id, date_maj, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE(), NOW())
                    ");
                    $stmt->execute(array(
                        isset($row['Source']) ? $row['Source'] : '',
                        isset($row['Accessible au public']) ? $row['Accessible au public'] : '',
                        isset($row['Tarif']) ? $row['Tarif'] : '',
                        isset($row['Accessibilite PMR']) ? $row['Accessibilite PMR'] : '',
                        isset($row['Indications de localisation']) ? $row['Indications de localisation'] : '',
                        isset($row['Type']) ? $row['Type'] : '',
                        isset($row["Horaires d'ouverture"]) ? $row["Horaires d'ouverture"] : '',
                        isset($row['Relais bébé']) ? $row['Relais bébé'] : '',
                        isset($row['coord_geo']) ? $row['coord_geo'] : '',
                        isset($row['osm_id']) ? $row['osm_id'] : '',
                        isset($row['nom_de_la_commune']) ? $row['nom_de_la_commune'] : '',
                        isset($row['code_geogrephique_commune']) ? $row['code_geogrephique_commune'] : '',
                        isset($row['nom_departement']) ? $row['nom_departement'] : '',
                        isset($row['code_geographique_departement']) ? $row['code_geographique_departement'] : '',
                        $nom,
                        $type_normalise,
                        isset($row['Indications de localisation']) ? $row['Indications de localisation'] : '',
                        $commune,
                        $code_postal,
                        $payant,
                        $acces_pmr,
                        $ouvert_24_7,
                        $latitude,
                        $longitude,
                        isset($row["Horaires d'ouverture"]) ? $row["Horaires d'ouverture"] : '',
                        $source_id
                    ));
                    $stats['imported']++;
                }
            }
            
            fclose($handle);
            
            $duration = time() - $start_time;
            
            // Log import
            $stmt = $pdo->prepare("
                INSERT INTO imports_logs (user_id, filename, rows_imported, rows_updated, rows_failed, duration_seconds, import_date)
                VALUES (?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute(array(
                $user_id,
                $file['name'],
                $stats['imported'],
                $stats['updated'],
                $stats['failed'],
                $duration
            ));
            
            $total = $stats['imported'] + $stats['updated'];
            $success = ($lang === 'fr' ? 'Import réussi ! ' : 'Import successful! ') . 
                       $total . ($lang === 'fr' ? ' toilette(s) traitée(s) (' : ' toilet(s) processed (') .
                       $stats['imported'] . ($lang === 'fr' ? ' nouvelles, ' : ' new, ') .
                       $stats['updated'] . ($lang === 'fr' ? ' mises à jour, ' : ' updated, ') .
                       $stats['failed'] . ($lang === 'fr' ? ' échecs)' : ' failed)');
            
        } catch (Exception $e) {
            error_log("Import error: " . $e->getMessage());
            $errors[] = $lang === 'fr' ? 'Erreur lors de l\'import : ' . $e->getMessage() : 'Import error: ' . $e->getMessage();
        }
    }
}

// Récupérer l'historique des imports
try {
    $stmt = $pdo->prepare("
        SELECT il.*, u.username 
        FROM imports_logs il
        JOIN users u ON il.user_id = u.id
        ORDER BY il.import_date DESC
        LIMIT 10
    ");
    $stmt->execute();
    $imports_history = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $imports_history = array();
}
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" data-theme="<?php echo $dark_mode ? 'dark' : 'light'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $lang === 'fr' ? 'Import de données' : 'Data import'; ?> - PeePeeFinder</title>
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico">
    <link rel="stylesheet" href="assets/css/app.css">
    <script src="assets/js/app.js" defer></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/feather-icons"></script>
    <style>
        [data-theme="dark"] {
            background-color: #111827;
            color: #f9fafb;
        }
        [data-theme="dark"] .bg-white {
            background-color: #1f2937 !important;
        }
        [data-theme="dark"] .text-gray-800 {
            color: #f9fafb !important;
        }
        [data-theme="dark"] .text-gray-700 {
            color: #e5e7eb !important;
        }
        [data-theme="dark"] .text-gray-600 {
            color: #d1d5db !important;
        }
        [data-theme="dark"] .border-gray-300 {
            border-color: #4b5563 !important;
        }
        .upload-zone {
            border: 2px dashed #cbd5e0;
            transition: all 0.3s ease;
        }
        .upload-zone:hover {
            border-color: #3b82f6;
            background-color: #eff6ff;
        }
        .upload-zone.dragover {
            border-color: #3b82f6;
            background-color: #dbeafe;
        }
    </style>
</head>
<body class="font-sans antialiased bg-gray-50">
    <!-- Header -->
    <header class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div class="flex justify-between items-center nav-wrapper">
                    <a href="index.php" class="text-xl font-bold text-blue-600 flex items-center">
                        <span class="text-2xl mr-2">🚽</span>
                        PeePeeFinder
                    </a>

                
                <div class="flex items-center space-x-3 md:space-x-4">
                    <button
                        class="mobile-nav-toggle md:hidden"
                        type="button"
                        aria-controls="primary-navigation"
                        aria-expanded="false"
                        aria-label="<?php echo $lang === 'fr' ? 'Ouvrir le menu' : 'Open menu'; ?>"
                        data-open-label="<?php echo $lang === 'fr' ? 'Ouvrir le menu' : 'Open menu'; ?>"
                        data-close-label="<?php echo $lang === 'fr' ? 'Fermer le menu' : 'Close menu'; ?>"
                    >
                        <i data-feather="menu" class="icon-menu"></i>
                        <i data-feather="x" class="icon-close"></i>
                    </button>

                    <nav id="primary-navigation" class="hidden md:flex items-center space-x-4 mobile-nav">
                        <a href="map.php" class="text-gray-600 hover:text-blue-600 flex items-center">
                            <i data-feather="map" class="w-4 h-4 mr-1"></i>
                            <?php echo $lang === 'fr' ? 'Carte' : 'Map'; ?>
                        </a>
                        <a href="dashboard.php" class="text-gray-600 hover:text-blue-600 flex items-center">
                            <i data-feather="bar-chart-2" class="w-4 h-4 mr-1"></i>
                            Dashboard
                        </a>
                        <a href="import.php" class="text-blue-600 hover:text-blue-700 flex items-center font-medium">
                            <i data-feather="upload" class="w-4 h-4 mr-1"></i>
                            Import
                        </a>
                    </nav>
                    <button id="darkModeToggle" class="p-2 rounded-lg hover:bg-gray-100 transition duration-200">
                        <i data-feather="<?php echo $dark_mode ? 'sun' : 'moon'; ?>" class="w-5 h-5"></i>
                    </button>
                    
                    <div class="flex items-center space-x-2">
                        <a href="profil.php" class="text-gray-700 hover:text-blue-600 flex items-center">
                            <i data-feather="user" class="w-4 h-4 mr-1"></i>
                            <span class="hidden sm:inline"><?php echo htmlspecialchars($username); ?></span>
                        </a>
                        <a href="logout.php" class="px-3 py-1 bg-red-500 text-white rounded-lg hover:bg-red-600 transition duration-200 text-sm">
                            <?php echo $lang === 'fr' ? 'Déconnexion' : 'Logout'; ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 class="text-3xl font-bold text-gray-800 mb-8 flex items-center">
            <i data-feather="upload" class="w-8 h-8 mr-3 text-blue-600"></i>
            <?php echo $lang === 'fr' ? 'Import de données CSV' : 'CSV Data Import'; ?>
        </h1>

        <!-- Messages -->
        <?php if (!empty($errors)): ?>
            <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded">
                <div class="flex items-start">
                    <i data-feather="alert-circle" class="text-red-500 mr-2 flex-shrink-0" style="width: 20px; height: 20px;"></i>
                    <div class="flex-1">
                        <?php foreach ($errors as $error): ?>
                            <p class="text-red-700 text-sm"><?php echo htmlspecialchars($error); ?></p>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="bg-green-50 border-l-4 border-green-500 p-4 mb-6 rounded">
                <div class="flex items-start">
                    <i data-feather="check-circle" class="text-green-500 mr-2 flex-shrink-0" style="width: 20px; height: 20px;"></i>
                    <p class="text-green-700 text-sm"><?php echo htmlspecialchars($success); ?></p>
                </div>
            </div>
        <?php endif; ?>

        <!-- Upload Form -->
        <div class="bg-white p-6 rounded-xl shadow-md mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-4">
                <?php echo $lang === 'fr' ? 'Importer un fichier CSV' : 'Import CSV file'; ?>
            </h2>
            
            <form method="POST" enctype="multipart/form-data" id="uploadForm">
                <div class="upload-zone rounded-lg p-8 text-center mb-4" id="uploadZone">
                    <i data-feather="upload-cloud" class="w-16 h-16 text-gray-400 mx-auto mb-4"></i>
                    <p class="text-gray-600 mb-2">
                        <?php echo $lang === 'fr' ? 'Glissez-déposez votre fichier CSV ici' : 'Drag and drop your CSV file here'; ?>
                    </p>
                    <p class="text-gray-500 text-sm mb-4">
                        <?php echo $lang === 'fr' ? 'ou' : 'or'; ?>
                    </p>
                    <label class="inline-block px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 cursor-pointer transition duration-200">
                        <?php echo $lang === 'fr' ? 'Sélectionner un fichier' : 'Select a file'; ?>
                        <input type="file" name="csv_file" id="csvFile" accept=".csv" class="hidden" required>
                    </label>
                    <p class="text-gray-500 text-xs mt-4">
                        <?php echo $lang === 'fr' ? 'Taille maximum : 10 MB' : 'Maximum size: 10 MB'; ?>
                    </p>
                </div>

                <div id="fileInfo" class="hidden mb-4 p-4 bg-blue-50 rounded-lg">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <i data-feather="file-text" class="w-5 h-5 text-blue-600 mr-2"></i>
                            <span class="text-gray-800 font-medium" id="fileName"></span>
                            <span class="text-gray-600 text-sm ml-2" id="fileSize"></span>
                        </div>
                        <button type="button" onclick="clearFile()" class="text-red-600 hover:text-red-800">
                            <i data-feather="x" class="w-5 h-5"></i>
                        </button>
                    </div>
                </div>

                <button type="submit" class="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition duration-200 flex items-center justify-center font-medium">
                    <i data-feather="upload" class="w-5 h-5 mr-2"></i>
                    <?php echo $lang === 'fr' ? 'Importer les données' : 'Import data'; ?>
                </button>
            </form>
        </div>

        <!-- Format attendu -->
        <div class="bg-white p-6 rounded-xl shadow-md mb-8">
            <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                <i data-feather="info" class="w-5 h-5 mr-2 text-blue-600"></i>
                <?php echo $lang === 'fr' ? 'Format attendu (OpenData Île-de-France)' : 'Expected format (OpenData Île-de-France)'; ?>
            </h3>
            <div class="bg-gray-50 p-4 rounded-lg overflow-x-auto">
                <pre class="text-xs text-gray-700"><code>Source,Accessible au public,Tarif,Accessibilite PMR,Indications de localisation,Type,Horaires d'ouverture,Relais bébé,coord_geo,osm_id,nom_de_la_commune,code_geogrephique_commune,nom_departement,code_geographique_departement
"Mairie","Oui","Gratuit","Oui","12 Place de la Mairie","Toilettes publiques","8h-18h","Non","48.8566,2.3522","123456","Paris","75056","Paris","75"</code></pre>
            </div>
            <div class="mt-4 space-y-2 text-sm text-gray-600">
                <p><strong><?php echo $lang === 'fr' ? 'Colonnes obligatoires' : 'Required columns'; ?> :</strong> coord_geo (format: "latitude,longitude")</p>
                <p><strong><?php echo $lang === 'fr' ? 'Normalisation automatique' : 'Automatic normalization'; ?> :</strong></p>
                <ul class="list-disc list-inside ml-4 space-y-1">
                    <li>coord_geo → latitude / longitude</li>
                    <li>Accessibilite PMR → booléen acces_pmr</li>
                    <li>Tarif → booléen payant</li>
                    <li>Type → type_normalise (sanisette/toilettes_publiques/autres)</li>
                    <li>nom_de_la_commune → commune</li>
                </ul>
                <p class="mt-4"><strong><?php echo $lang === 'fr' ? 'Télécharger les données' : 'Download data'; ?> :</strong></p>
                <a href="https://www.data.gouv.fr/fr/datasets/toilettes-publiques-en-ile-de-france/" target="_blank" class="text-blue-600 hover:underline">
                    → data.gouv.fr/datasets/toilettes-publiques-en-ile-de-france
                </a>
            </div>
        </div>

        <!-- Zone de danger -->
        <div class="bg-red-50 border-l-4 border-red-500 p-6 rounded-xl shadow-md mb-8">
            <h3 class="text-lg font-bold text-red-800 mb-4 flex items-center">
                <i data-feather="alert-triangle" class="w-5 h-5 mr-2"></i>
                <?php echo $lang === 'fr' ? 'Zone de danger' : 'Danger Zone'; ?>
            </h3>
            <p class="text-red-700 mb-4 text-sm">
                <?php echo $lang === 'fr' ? 'L\'action ci-dessous est irréversible. Elle supprimera définitivement toutes les données de la table des toilettes.' : 'The action below is irreversible. It will permanently delete all data from the toilets table.'; ?>
            </p>
            <form method="POST" onsubmit="return confirm('<?php echo $lang === 'fr' ? 'Êtes-vous absolument certain de vouloir supprimer TOUTES les toilettes ? Cette action est irréversible.' : 'Are you absolutely sure you want to delete ALL toilets? This action is irreversible.'; ?>');">
                <input type="hidden" name="action" value="delete_all">
                <button type="submit" class="w-full bg-red-600 text-white py-3 rounded-lg hover:bg-red-700 transition duration-200 flex items-center justify-center font-medium">
                    <i data-feather="trash-2" class="w-5 h-5 mr-2"></i>
                    <?php echo $lang === 'fr' ? 'Supprimer toutes les toilettes' : 'Delete all toilets'; ?>
                </button>
            </form>
        </div>

        <!-- Historique des imports -->
        <?php if (!empty($imports_history)): ?>
        <div class="bg-white p-6 rounded-xl shadow-md">
            <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                <i data-feather="clock" class="w-5 h-5 mr-2 text-blue-600"></i>
                <?php echo $lang === 'fr' ? 'Historique des imports' : 'Import history'; ?>
            </h3>
            <div class="responsive-table overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-2 text-left text-sm font-medium text-gray-700"><?php echo $lang === 'fr' ? 'Date' : 'Date'; ?></th>
                            <th class="px-4 py-2 text-left text-sm font-medium text-gray-700"><?php echo $lang === 'fr' ? 'Fichier' : 'File'; ?></th>
                            <th class="px-4 py-2 text-left text-sm font-medium text-gray-700"><?php echo $lang === 'fr' ? 'Utilisateur' : 'User'; ?></th>
                            <th class="px-4 py-2 text-center text-sm font-medium text-gray-700"><?php echo $lang === 'fr' ? 'Nouvelles' : 'New'; ?></th>
                            <th class="px-4 py-2 text-center text-sm font-medium text-gray-700"><?php echo $lang === 'fr' ? 'Mises à jour' : 'Updated'; ?></th>
                            <th class="px-4 py-2 text-center text-sm font-medium text-gray-700"><?php echo $lang === 'fr' ? 'Échecs' : 'Failed'; ?></th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        <?php foreach ($imports_history as $import): ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-4 py-3 text-sm text-gray-600">
                                <?php echo date('d/m/Y H:i', strtotime($import['import_date'])); ?>
                            </td>
                            <td class="px-4 py-3 text-sm text-gray-800">
                                <?php echo htmlspecialchars($import['filename']); ?>
                            </td>
                            <td class="px-4 py-3 text-sm text-gray-600">
                                <?php echo htmlspecialchars($import['username']); ?>
                            </td>
                            <td class="px-4 py-3 text-sm text-center">
                                <span class="px-2 py-1 bg-green-100 text-green-800 rounded-full">
                                    <?php echo $import['rows_imported']; ?>
                                </span>
                            </td>
                            <td class="px-4 py-3 text-sm text-center">
                                <span class="px-2 py-1 bg-blue-100 text-blue-800 rounded-full">
                                    <?php echo $import['rows_updated']; ?>
                                </span>
                            </td>
                            <td class="px-4 py-3 text-sm text-center">
                                <span class="px-2 py-1 bg-red-100 text-red-800 rounded-full">
                                    <?php echo $import['rows_failed']; ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
    </main>

    <script>
        feather.replace();

        var uploadZone = document.getElementById('uploadZone');
        var fileInput = document.getElementById('csvFile');
        var fileInfo = document.getElementById('fileInfo');

        // Drag and drop
        uploadZone.addEventListener('dragover', function(e) {
            e.preventDefault();
            uploadZone.classList.add('dragover');
        });

        uploadZone.addEventListener('dragleave', function(e) {
            e.preventDefault();
            uploadZone.classList.remove('dragover');
        });

        uploadZone.addEventListener('drop', function(e) {
            e.preventDefault();
            uploadZone.classList.remove('dragover');
            
            if (e.dataTransfer.files.length) {
                fileInput.files = e.dataTransfer.files;
                showFileInfo(e.dataTransfer.files[0]);
            }
        });

        // File input change
        fileInput.addEventListener('change', function() {
            if (this.files.length) {
                showFileInfo(this.files[0]);
            }
        });

        function showFileInfo(file) {
            document.getElementById('fileName').textContent = file.name;
            document.getElementById('fileSize').textContent = '(' + (file.size / 1024).toFixed(2) + ' KB)';
            fileInfo.classList.remove('hidden');
            feather.replace();
        }

        function clearFile() {
            fileInput.value = '';
            fileInfo.classList.add('hidden');
        }

        // Dark mode toggle
        document.getElementById('darkModeToggle').addEventListener('click', function() {
            fetch('api/toggle_dark_mode.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(function(response) { return response.json(); })
            .then(function(data) {
                if (data.success) {
                    location.reload();
                }
            })
            .catch(function(error) { 
                console.error('Error:', error); 
            });
        });
    </script>
<?php include 'partials/footer.php'; ?>
</body>
</html>