<footer class="site-footer bg-slate-900 text-slate-100 py-8 mt-12">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-6">
            <div>
                <h3 class="text-lg font-semibold mb-3 flex items-center gap-2">
                    <span class="text-2xl" aria-hidden="true">&#128701;</span>
                    PeePeeFinder
                </h3>
                <p class="text-slate-300 text-sm leading-relaxed">
                    <?php echo $lang === 'fr'
                        ? 'Trouvez facilement des toilettes publiques en &Icirc;le-de-France.'
                        : 'Find public toilets easily in &Icirc;le-de-France.'; ?>
                </p>
            </div>
            <div>
                <h3 class="text-lg font-semibold mb-3">
                    <?php echo $lang === 'fr' ? 'Liens utiles' : 'Useful links'; ?>
                </h3>
                <ul class="space-y-2 text-sm">
                    <li>
                        <a href="map.php" class="text-slate-300 hover:text-white transition duration-200">
                            <?php echo $lang === 'fr' ? 'Carte' : 'Map'; ?>
                        </a>
                    </li>
                    <li>
                        <a href="dashboard.php" class="text-slate-300 hover:text-white transition duration-200">
                            Dashboard
                        </a>
                    </li>
                    <li>
                        <a href="https://www.data.gouv.fr/fr/datasets/toilettes-publiques-en-ile-de-france/" target="_blank" class="text-slate-300 hover:text-white transition duration-200">
                            <?php echo $lang === 'fr' ? 'Donn&eacute;es ouvertes' : 'Open data'; ?>
                        </a>
                    </li>
                    <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] === 'admin'): ?>
                        <li>
                            <a href="import.php" class="text-slate-300 hover:text-white transition duration-200">
                                <?php echo $lang === 'fr' ? 'Import donn&eacute;es' : 'Import data'; ?>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
            <div>
                <h3 class="text-lg font-semibold mb-3">
                    <?php echo $lang === 'fr' ? 'Contact' : 'Contact'; ?>
                </h3>
                <p class="text-slate-300 text-sm">contact@peepeefinder.fr</p>
                <div class="flex items-center gap-4 mt-4">
                    <a href="#" class="text-slate-400 hover:text-white transition duration-200" aria-label="Twitter">
                        <i data-feather="twitter"></i>
                    </a>
                    <a href="#" class="text-slate-400 hover:text-white transition duration-200" aria-label="Facebook">
                        <i data-feather="facebook"></i>
                    </a>
                    <a href="#" class="text-slate-400 hover:text-white transition duration-200" aria-label="GitHub">
                        <i data-feather="github"></i>
                    </a>
                </div>
            </div>
        </div>
        <div class="border-t border-slate-700 pt-6 text-center text-sm text-slate-400">
            <p>
                &copy; <?php echo date('Y'); ?> PeePeeFinder. <?php echo $lang === 'fr'
                    ? 'Tous droits r&eacute;serv&eacute;s.'
                    : 'All rights reserved.'; ?>
            </p>
        </div>
    </div>
</footer>
<script>
    if (window.feather && typeof window.feather.replace === 'function') {
        window.feather.replace();
    }
</script>
