document.addEventListener('DOMContentLoaded', () => {
    const breakpoint = window.matchMedia('(min-width: 768px)');
    const pairs = Array.from(document.querySelectorAll('.mobile-nav-toggle')).map((toggle) => {
        const navId = toggle.getAttribute('aria-controls');
        const nav = navId ? document.getElementById(navId) : null;

        if (!nav) {
            return null;
        }

        return { toggle, nav };
    }).filter(Boolean);

    if (!pairs.length) {
        return;
    }

    const updateBodyState = () => {
        const anyOpen = pairs.some(({ toggle }) => toggle.getAttribute('aria-expanded') === 'true');
        document.body.classList.toggle('mobile-nav-open', anyOpen);
    };

    const openNav = ({ toggle, nav }) => {
        toggle.setAttribute('aria-expanded', 'true');
        const closeLabel = toggle.dataset.closeLabel || 'Close menu';
        toggle.setAttribute('aria-label', closeLabel);
        toggle.classList.add('is-active');
        nav.classList.add('is-open');
        nav.classList.remove('hidden');
        nav.classList.add('flex');
        updateBodyState();
    };

    const closeNav = ({ toggle, nav }) => {
        toggle.setAttribute('aria-expanded', 'false');
        const openLabel = toggle.dataset.openLabel || 'Open menu';
        toggle.setAttribute('aria-label', openLabel);
        toggle.classList.remove('is-active');
        nav.classList.remove('is-open');
        nav.classList.remove('flex');
        if (!breakpoint.matches) {
            nav.classList.add('hidden');
        }
        updateBodyState();
    };

    const closeAll = () => pairs.forEach(closeNav);

    pairs.forEach((pair) => {
        const { toggle, nav } = pair;

        const openLabel = toggle.dataset.openLabel || toggle.getAttribute('aria-label') || 'Open menu';
        toggle.setAttribute('aria-label', openLabel);
        toggle.setAttribute('aria-expanded', 'false');
        toggle.classList.remove('is-active');

        toggle.addEventListener('click', (event) => {
            event.stopPropagation();
            const expanded = toggle.getAttribute('aria-expanded') === 'true';

            if (expanded) {
                closeNav(pair);
            } else {
                closeAll();
                openNav(pair);
            }
        });

        nav.querySelectorAll('a, button').forEach((item) => {
            item.addEventListener('click', () => closeNav(pair));
        });
    });

    document.addEventListener('click', (event) => {
        const clickedToggle = pairs.some(({ toggle }) => toggle.contains(event.target));
        const insideNav = pairs.some(({ nav }) => nav.contains(event.target));

        if (!clickedToggle && !insideNav) {
            closeAll();
        }
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            closeAll();
        }
    });

    const handleBreakpointChange = (event) => {
        if (event.matches) {
            closeAll();
            pairs.forEach(({ nav }) => nav.classList.remove('hidden'));
            updateBodyState();
        } else {
            pairs.forEach(({ nav }) => {
                if (!nav.classList.contains('is-open')) {
                    nav.classList.add('hidden');
                }
            });
            updateBodyState();
        }
    };

    if (typeof breakpoint.addEventListener === 'function') {
        breakpoint.addEventListener('change', handleBreakpointChange);
    } else if (typeof breakpoint.addListener === 'function') {
        breakpoint.addListener(handleBreakpointChange);
    }

    handleBreakpointChange(breakpoint);
});
