import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 1. Chargement des données
df_campagne = pd.read_csv('base_campagne.csv')
df_finance = pd.read_csv('base_finance.csv')

# 2. Préparation des données
# Conversion de la durée d'appel en numérique (cas de valeurs mal formatées)
df_campagne['duree_appel'] = pd.to_numeric(df_campagne['duree_appel'], errors='coerce')

# Fusion des données de campagne avec les indicateurs financiers sur le mois et l'année
df_merged = pd.merge(
    df_campagne, 
    df_finance, 
    left_on=['mois_contact', 'annee_contact'], 
    right_on=['mois', 'annee'], 
    how='left'
)

# 3. Création des graphiques bivariés

# A. Âge vs Souscription (Boxplot)
plt.figure(figsize=(10, 6))
sns.boxplot(x='souscription', y='age', data=df_campagne, palette='Set2')
plt.title('Distribution de l\'Âge par Souscription')
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.show()

# B. Durée d'appel vs Souscription (Boxplot)
plt.figure(figsize=(10, 6))
sns.boxplot(x='souscription', y='duree_appel', data=df_campagne, palette='Set1')
plt.title('Influence de la Durée d\'Appel sur la Souscription')
plt.ylabel('Durée (min)')
plt.show()

# C. Taux de souscription par Emploi (Barres empilées normalisées)
emploi_sub = pd.crosstab(df_campagne['emploi'], df_campagne['souscription'], normalize='index')
emploi_sub.plot(kind='bar', stacked=True, figsize=(12, 6), color=['#ff9999','#66b3ff'])
plt.title('Taux de Souscription par Type d\'Emploi')
plt.ylabel('Proportion')
plt.xticks(rotation=45)
plt.legend(title='Souscription')
plt.show()

# D. Impact de l'Indice de Confiance Économique (Boxplot)
plt.figure(figsize=(10, 6))
sns.boxplot(x='souscription', y='indic_confiance', data=df_merged, palette='Pastel1')
plt.title('Souscription en fonction de l\'Indice de Confiance Économique')
plt.show()

# E. Prêt Immobilier vs Souscription
immo_sub = pd.crosstab(df_campagne['pret_immo'], df_campagne['souscription'], normalize='index')
immo_sub.plot(kind='bar', stacked=True, figsize=(8, 6), color=['#ff9999','#66b3ff'])
plt.title('Impact du Prêt Immobilier sur la Souscription')
plt.show()