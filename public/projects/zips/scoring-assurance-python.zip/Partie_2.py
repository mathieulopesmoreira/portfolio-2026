import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn import metrics

# 1. Chargement des données
df_camp = pd.read_csv("base_campagne.csv", sep=',', header=0)
df_finance = pd.read_csv("base_finance.csv", sep=',', header=0)

# Jointure
df = df_camp.merge(
    df_finance,
    how='left',
    left_on=['annee_contact', 'mois_contact'],
    right_on=['annee', 'mois']
)

# 2. Nettoyage sécurisé
df["genre_naissance"] = df["genre_naissance"].replace("M", "H")
df.replace(["unknown", "inconnu"], np.nan, inplace=True)
df.drop_duplicates(subset="ID", inplace=True)
df = df[df["age"] >= 18].copy()

# Création des tranches
df["classe_age"] = pd.cut(df["age"], bins=[18, 25, 40, 60, 120], labels=["18-25", "25-40", "40-60", "60+"])
df["classe_enfant"] = pd.cut(df["enfant"], bins=[-1, 0, 3, 5, 100], labels=["0", "1-3", "4-5", "5+"])

# Encodage de la cible
df["souscription"] = df["souscription"].map({"non": 0, "oui": 1})

# Suppression des colonnes inutiles par NOM (plus robuste que les index)
colonnes_a_virer = ['ID', 'annee', 'mois', 'annee_contact', 'mois_contact', 'age', 'enfant','IPC','croissance_emploi','contact_mois_suiv','duree_appel','jour_contact','contacts_camp_prec','nb_contact','indic_confiance']
df_clean = df.drop(columns=[c for c in colonnes_a_virer if c in df.columns])

# 3. Préparation pour le modèle
# Remplissage simple des vides (au cas où)
df_clean = df_clean.fillna(method='ffill') 

# Création des variables dummies
df_dummies = pd.get_dummies(df_clean, drop_first=True, dtype=int)

# 4. Modélisation
if 'souscription' in df_dummies.columns:
    X = df_dummies.drop('souscription', axis=1)
    y = df_dummies['souscription']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=16)

    logreg = LogisticRegression(max_iter=1000)
    logreg.fit(X_train, y_train)
    y_pred = logreg.predict(X_test)

    # 5. MATRICE DE CONFUSION (Version Matplotlib sans Seaborn)
    cnf_matrix = metrics.confusion_matrix(y_test, y_pred)
    
    fig, ax = plt.subplots(figsize=(6, 5))
    disp = ax.imshow(cnf_matrix, cmap='Blues')
    plt.colorbar(disp)
    
    # Ajout des étiquettes
    ax.set_xticks([0, 1])
    ax.set_yticks([0, 1])
    ax.set_xticklabels(['Non', 'Oui'])
    ax.set_yticklabels(['Non', 'Oui'])
    ax.set_title('Matrice de Confusion')
    ax.set_xlabel('Prédictions')
    ax.set_ylabel('Réel')

    # Affichage des chiffres dans les cases
    for i in range(2):
        for j in range(2):
            ax.text(j, i, cnf_matrix[i, j], ha='center', va='center', 
                    color='white' if cnf_matrix[i, j] > cnf_matrix.max()/2 else 'black')

    plt.show()
    print("\nScore de performance :\n", metrics.classification_report(y_test, y_pred))

# 6. ODDS & ODDS RATIOS
coefficients = logreg.coef_[0]
variables = X.columns

df_odds = pd.DataFrame({
    "variable": variables,
    "coef_logit": coefficients,
    "odds_ratio": np.exp(coefficients)
}).sort_values(by="odds_ratio", ascending=False)

print("\nODDS RATIOS :\n")
print(df_odds)