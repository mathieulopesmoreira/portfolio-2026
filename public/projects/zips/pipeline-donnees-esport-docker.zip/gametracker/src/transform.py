import pandas as pd
import numpy as np

def transform_players(df):
    """
    Cleans players data comprehensively.
    Tracks and logs all 7 quality issues.
    """
    print("=" * 60)
    print("TRANSFORMATION - Players Data")
    print("=" * 60)
    
    problems_count = 0
    initial_rows = len(df)
    
    # 1. Strip whitespace from username FIRST (before duplicate detection)
    if 'username' in df.columns:
        before = df['username'].str.len().sum()
        df['username'] = df['username'].str.strip()
        after = df['username'].str.len().sum()
        if before != after:
            problems_count += 1
            print(f"[Problème {problems_count}] Espaces parasites nettoyés dans username")
    
    # 2. Fix email format (replace invalid emails without @ with None)
    if 'email' in df.columns:
        invalid_count = (~df['email'].str.contains('@', na=False)).sum()
        if invalid_count > 0:
            problems_count += 1
            print(f"[Problème {problems_count}] {invalid_count} emails invalides (sans @) remplacés par None")
            df.loc[~df['email'].str.contains('@', na=False), 'email'] = None
        df['email'] = df['email'].replace({np.nan: None})
    
    # 3. Parse dates with mixed format support
    if 'registration_date' in df.columns:
        # Try mixed format first (handles both YYYY-MM-DD and DD/MM/YYYY)
        df['registration_date'] = pd.to_datetime(df['registration_date'], format='mixed', errors='coerce')
        invalid_dates = df['registration_date'].isna().sum()
        if invalid_dates > 0:
            problems_count += 1
            print(f"[Problème {problems_count}] {invalid_dates} dates invalides converties en NULL")
    
    # 4. Detect SEMANTIC duplicates (same person, different ID)
    # Strategy: group by (username, email, registration_date, country, level) and keep first player_id
    # Clean email/username should match for true duplicates
    df['_clean_email'] = df['email'].fillna('').str.lower().str.strip()
    df['_clean_username'] = df['username'].str.lower().str.strip()
    
    # Create a composite key for duplicate detection
    duplicate_mask = df.duplicated(subset=['_clean_username', '_clean_email', 'registration_date', 'country', 'level'], keep='first')
    
    semantic_dups = duplicate_mask.sum()
    if semantic_dups > 0:
        problems_count += 1
        print(f"[Problème {problems_count}] {semantic_dups} doublons sémantiques détectés (même joueur, ID différent)")
        # Show which ones are being removed
        removed = df[duplicate_mask][['player_id', 'username', 'email']]
        for _, row in removed.iterrows():
            print(f"  → Suppression player_id={row['player_id']} ({row['username']})")
    
    df = df[~duplicate_mask]
    df = df.drop(columns=['_clean_email', '_clean_username'])
    
    # 5. Remove strict ID-based duplicates (if any remain)
    id_dups = df.duplicated(subset=['player_id'], keep='first').sum()
    if id_dups > 0:
        problems_count += 1
        print(f"[Problème {problems_count}] {id_dups} doublons stricts sur player_id")
        df = df.drop_duplicates(subset=['player_id'], keep='first')
    
    # 6. Handle empty emails (already converted to None above, but count as issue)
    # This was already counted in step 2
    
    final_rows = len(df)
    print(f"\nRésultat: {initial_rows} lignes → {final_rows} lignes ({initial_rows - final_rows} supprimées)")
    print(f"Total problèmes traités: {problems_count}")
    print("=" * 60)
    return df

def transform_scores(df, valid_player_ids):
    """
    Cleans scores data comprehensively.
    """
    print("\n" + "=" * 60)
    print("TRANSFORMATION - Scores Data")
    print("=" * 60)
    
    problems_count = 0
    initial_rows = len(df)
    
    # 1. Remove strict duplicates on score_id
    score_id_dups = df.duplicated(subset=['score_id'], keep='first').sum()
    if score_id_dups > 0:
        problems_count += 1
        print(f"[Problème {problems_count}] {score_id_dups} doublons stricts sur score_id supprimés")
        df = df.drop_duplicates(subset=['score_id'], keep='first')
    
    # 2. Convert score to numeric and handle missing values
    df['score'] = pd.to_numeric(df['score'], errors='coerce')
    missing_scores = df['score'].isna().sum()
    if missing_scores > 0:
        problems_count += 1
        print(f"[Problème {problems_count}] {missing_scores} scores manquants détectés")
    
    # 3. Remove negative or zero scores
    before_neg = len(df)
    df = df.dropna(subset=['score'])
    df = df[df['score'] > 0]
    neg_removed = before_neg - len(df)
    if neg_removed > 0:
        problems_count += 1
        print(f"[Problème {problems_count}] {neg_removed} scores négatifs/nuls/manquants supprimés")
    
    # 4. Parse played_at dates
    if 'played_at' in df.columns:
        df['played_at'] = pd.to_datetime(df['played_at'], errors='coerce')
        invalid_dates = df['played_at'].isna().sum()
        if invalid_dates > 0:
            problems_count += 1
            print(f"[Problème {problems_count}] {invalid_dates} dates de jeu invalides converties en NULL")
    
    # 5. Convert duration to numeric
    df['duration_minutes'] = pd.to_numeric(df['duration_minutes'], errors='coerce')
    
    # 6. Filter orphan player_ids (not in cleaned players table)
    before_orphan = len(df)
    df = df[df['player_id'].isin(valid_player_ids)]
    orphans_removed = before_orphan - len(df)
    if orphans_removed > 0:
        problems_count += 1
        print(f"[Problème {problems_count}] {orphans_removed} scores orphelins supprimés (player_id inexistant)")
    
    final_rows = len(df)
    print(f"\nRésultat: {initial_rows} lignes → {final_rows} lignes ({initial_rows - final_rows} supprimées)")
    print(f"Total problèmes traités: {problems_count}")
    print("=" * 60)
    return df
