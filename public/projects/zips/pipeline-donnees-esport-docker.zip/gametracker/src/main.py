from database import database_connection
from extract import extract
from transform import transform_players, transform_scores
from load import load_players, load_scores
from report import generate_report
import os

def main():
    print("Starting GameTracker Pipeline...")
    
    # Paths
    players_csv = os.path.join('data', 'raw', 'Players.csv')
    scores_csv = os.path.join('data', 'raw', 'Scores.csv')
    
    try:
        with database_connection() as conn:
            # 1. Process Players
            print("\n--- Processing Players ---")
            df_players = extract(players_csv)
            df_players_clean = transform_players(df_players)
            load_players(df_players_clean, conn)
            
            # Get valid player IDs for score filtering
            valid_player_ids = df_players_clean['player_id'].unique().tolist()
            
            # 2. Process Scores
            print("\n--- Processing Scores ---")
            df_scores = extract(scores_csv)
            df_scores_clean = transform_scores(df_scores, valid_player_ids)
            load_scores(df_scores_clean, conn)
            
        print("\nPipeline execution completed successfully.")
        
        # 3. Generate Report
        print("\n--- Generating Report ---")
        generate_report()
            
    except Exception as e:
        print(f"\nPipeline failed: {e}")
        exit(1)

if __name__ == "__main__":
    main()
