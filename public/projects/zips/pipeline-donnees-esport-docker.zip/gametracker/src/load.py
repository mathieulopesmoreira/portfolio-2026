import mysql.connector

def load_players(df, conn):
    """
    Loads players data into MySQL using ON DUPLICATE KEY UPDATE.
    """
    print("Loading players into database...")
    cursor = conn.cursor()
    
    # Prepare query
    query = """
    INSERT INTO players (player_id, username, email, registration_date, country, level)
    VALUES (%s, %s, %s, %s, %s, %s)
    ON DUPLICATE KEY UPDATE
        username = VALUES(username),
        email = VALUES(email),
        registration_date = VALUES(registration_date),
        country = VALUES(country),
        level = VALUES(level)
    """
    
    # Prepare data tuples
    data = []
    for _, row in df.iterrows():
        # Handle None/NaN for dates which might need to be None for MySQL
        reg_date = row['registration_date']
        if pd.isna(reg_date):
            reg_date = None
        else:
            reg_date = reg_date.date() # Convert timestamp to date object

        email = row['email']
        if pd.isna(email):
            email = None
            
        data.append((
            row['player_id'],
            row['username'],
            email,
            reg_date,
            row['country'],
            row['level']
        ))
        
    try:
        cursor.executemany(query, data)
        conn.commit()
        print(f"Loaded {cursor.rowcount} records into players table.")
    except mysql.connector.Error as e:
        print(f"Error loading players: {e}")
        conn.rollback()
    finally:
        cursor.close()

import pandas as pd # Import pandas for checking isna

def load_scores(df, conn):
    """
    Loads scores data into MySQL using ON DUPLICATE KEY UPDATE.
    """
    print("Loading scores into database...")
    cursor = conn.cursor()
    
    query = """
    INSERT INTO scores (score_id, player_id, game, score, duration_minutes, played_at, platform)
    VALUES (%s, %s, %s, %s, %s, %s, %s)
    ON DUPLICATE KEY UPDATE
        player_id = VALUES(player_id),
        game = VALUES(game),
        score = VALUES(score),
        duration_minutes = VALUES(duration_minutes),
        played_at = VALUES(played_at),
        platform = VALUES(platform)
    """
    
    data = []
    for _, row in df.iterrows():
        played_at = row['played_at']
        if pd.isna(played_at):
            played_at = None
        else:
             played_at = played_at.to_pydatetime() # Ensure datetime format

        data.append((
            row['score_id'],
            row['player_id'],
            row['game'],
            row['score'],
            row['duration_minutes'],
            played_at,
            row['platform']
        ))
        
    try:
        cursor.executemany(query, data)
        conn.commit()
        print(f"Loaded {cursor.rowcount} records into scores table.")
    except mysql.connector.Error as e:
        print(f"Error loading scores: {e}")
        conn.rollback()
    finally:
        cursor.close()
