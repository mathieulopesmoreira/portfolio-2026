import mysql.connector
from mysql.connector import Error
import time
from contextlib import contextmanager
from config import Config

def get_connection():
    """Returns a MySQL connection."""
    return mysql.connector.connect(
        host=Config.DB_HOST,
        user=Config.DB_USER,
        password=Config.DB_PASSWORD,
        database=Config.DB_NAME,
        ssl_disabled=True
    )

def get_connection_with_retry(max_retries=5, delay=2):
    """Returns a MySQL connection with retry logic."""
    for i in range(max_retries):
        try:
            conn = get_connection()
            if conn.is_connected():
                return conn
        except Error as e:
            print(f"Connection failed (attempt {i+1}/{max_retries}): {e}")
            time.sleep(delay)
    raise Exception("Could not connect to the database after retries.")

@contextmanager
def database_connection():
    """Context manager for database connection handling commit/rollback."""
    conn = get_connection_with_retry()
    try:
        yield conn
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        if conn.is_connected():
            conn.close()
