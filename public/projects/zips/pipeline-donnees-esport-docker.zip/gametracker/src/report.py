from datetime import datetime
from database import get_connection

def generate_report():
    print("Generating report...")
    output_path = 'output/rapport.txt'
    
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        # 1. General Stats
        cursor.execute("SELECT COUNT(*) FROM players")
        nb_joueurs = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM scores")
        nb_scores = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(DISTINCT game) FROM scores")
        nb_jeux = cursor.fetchone()[0]
        
        # 2. Top 5 Scores
        cursor.execute("""
            SELECT p.username, s.game, s.score 
            FROM scores s 
            JOIN players p ON s.player_id = p.player_id 
            ORDER BY s.score DESC 
            LIMIT 5
        """)
        top_scores = cursor.fetchall()
        
        # 3. Average Score per Game
        cursor.execute("SELECT game, AVG(score) FROM scores GROUP BY game")
        avg_scores = cursor.fetchall()
        
        # 4. Players per Country
        cursor.execute("SELECT country, COUNT(*) FROM players GROUP BY country")
        players_country = cursor.fetchall()
        
        # 5. Sessions per Platform
        cursor.execute("SELECT platform, COUNT(*) FROM scores GROUP BY platform")
        sessions_platform = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        with open(output_path, 'w') as f:
            f.write("====================================================\n")
            f.write("GAMETRACKER - Rapport de synthese\n")
            f.write(f"Genere le : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("====================================================\n\n")
            
            f.write("--- Statistiques generales ---\n")
            f.write(f"Nombre de joueurs : {nb_joueurs}\n")
            f.write(f"Nombre de scores : {nb_scores}\n")
            f.write(f"Nombre de jeux : {nb_jeux}\n\n")
            
            f.write("--- Top 5 des meilleurs scores ---\n")
            for i, (user, game, score) in enumerate(top_scores, 1):
                f.write(f"{i}. {user} | {game} | {score}\n")
            f.write("\n")
            
            f.write("--- Score moyen par jeu ---\n")
            for game, avg in avg_scores:
                f.write(f"{game} : {avg:.1f}\n")
            f.write("\n")
            
            f.write("--- Joueurs par pays ---\n")
            for country, count in players_country:
                f.write(f"{country} : {count}\n")
            f.write("\n")
            
            f.write("--- Sessions par plateforme ---\n")
            for platform, count in sessions_platform:
                f.write(f"{platform} : {count}\n")
                
        print(f"Report generated at {output_path}")
        
    except Exception as e:
        print(f"Error generating report: {e}")
