<div align="center">

# GameTracker ETL Pipeline

### Pipeline de donnees automatise pour l'analyse des performances de joueurs de jeux video

[![Docker](https://img.shields.io/badge/Docker-2496ED?style=for-the-badge&logo=docker&logoColor=white)](https://www.docker.com/)
[![Python](https://img.shields.io/badge/Python-3.11-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://www.python.org/)
[![MySQL](https://img.shields.io/badge/MySQL-8.0-4479A1?style=for-the-badge&logo=mysql&logoColor=white)](https://www.mysql.com/)
[![License](https://img.shields.io/badge/License-MIT-green.svg?style=for-the-badge)](LICENSE)
[![GitHub](https://img.shields.io/badge/GitHub-Repository-181717?style=for-the-badge&logo=github)](https://github.com/mathieulopesmoreira/gametracker)

---

**Pipeline ETL complet** | **Conteneurisation Docker** | **Automatisation Bash** | **Base MySQL** | **11+ Problemes de qualite traites**

</div>

---

## Table des matieres
- [Description](#description)
- [Fonctionnalites](#fonctionnalites)
- [Technologies utilisees](#technologies-utilisees)
- [Prerequis](#prerequis)
- [Installation et demarrage](#installation-et-demarrage)
- [Structure du projet](#structure-du-projet)
- [Pipeline de traitement](#pipeline-de-traitement)
- [Problemes de qualite traites](#problemes-de-qualite-traites)
- [Architecture](#architecture)
- [Commandes](#commandes)
- [Resultats](#resultats)
- [Auteur](#auteur)

---

## Description

**GameTracker** est un pipeline ETL (Extract, Transform, Load) complet developpe pour une startup d'analyse de performances de joueurs de jeux video. Ce projet demontre la maitrise des technologies de conteneurisation, d'automatisation et de traitement de donnees.

### Contexte academique
Projet individuel realise dans le cadre du **BUT Science des Donnees 2025-2026** pour le cours *Automatisation et Tests en Programmation*.

### Objectifs
- Nettoyer des donnees CSV sales (doublons, formats incoherents, valeurs manquantes)
- Charger les donnees dans une base MySQL
- Generer un rapport statistique automatise
- Conteneuriser le tout avec Docker
- Automatiser l'execution via scripts Bash

---

## Fonctionnalites

| Fonctionnalite | Description |
|----------------|-------------|
| **Extraction intelligente** | Lecture et validation de fichiers CSV avec gestion d'erreurs |
| **Nettoyage avance** | Detection de 11+ problemes de qualite (doublons semantiques, dates mixtes, emails invalides) |
| **Analyse statistique** | Top scores, moyennes par jeu, repartition geographique |
| **Conteneurisation** | Environnement isole et reproductible avec Docker Compose |
| **Automatisation** | Execution one-click avec orchestration Bash |
| **Logging detaille** | Tracabilite complete de chaque operation de nettoyage |

---

## Technologies utilisees

<div align="center">

| Technologie | Version | Role |
|:---:|:---:|:---|
| <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/docker/docker-original.svg" width="40"/> | Latest | Conteneurisation multi-services |
| <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" width="40"/> | 3.11 | Logique ETL et transformation |
| <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg" width="40"/> | 8.0 | Stockage relationnel |
| <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/pandas/pandas-original.svg" width="40"/> | Latest | Manipulation de donnees |
| <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/bash/bash-original.svg" width="40"/> | - | Scripts d'automatisation |

</div>

---

## Prerequis

```bash
# Verifier Docker
docker --version
# Docker version 20.10+

# Verifier Docker Compose
docker compose version
# Docker Compose version v2.0+
```

**Ressources systeme minimales :**
- CPU : 2 cores
- RAM : 2 GB
- Disque : 500 MB

---

## Installation et demarrage

### Demarrage rapide
```bash
# Lancer l'environnement et executer le pipeline
docker compose up --build -d

# Consulter le rapport genere
cat output/rapport.txt
```

### Installation complete
```bash
# Cloner le depot
git clone https://github.com/mathieulopesmoreira/gametracker.git
cd gametracker

# Lancer l'environnement et executer le pipeline
docker compose up --build -d

# Consulter le rapport genere
cat output/rapport.txt
```

### Arret et nettoyage
```bash
# Arreter les conteneurs
docker compose down

# Supprimer les volumes (reinitialisation complete)
docker compose down -v
```

---

## Structure du projet

```
gametracker/
├── docker-compose.yml      # Orchestration MySQL + App
├── Dockerfile              # Image Python personnalisee
├── requirements.txt        # Dependances Python
├── .gitignore              # Exclusions Git
├── README.md               # Documentation
├── data/
│   └── raw/                # CSV bruts (Players.csv, Scores.csv)
├── scripts/
│   ├── init-db.sql         # Schema MySQL avec TRUNCATE
│   ├── wait-for-db.sh      # Attente DB avec retry
│   └── run_pipeline.sh     # Orchestrateur principal (4 etapes)
├── src/
│   ├── __init__.py         # Module Python
│   ├── config.py           # Variables d'environnement
│   ├── database.py         # Context manager MySQL
│   ├── extract.py          # Lecture CSV
│   ├── transform.py        # Nettoyage (11+ problemes)
│   ├── load.py             # Insertion MySQL
│   ├── report.py           # Generation statistiques
│   └── main.py             # Point d'entree ETL
└── output/
    └── rapport.txt         # Rapport auto-genere
```

---

## Pipeline de traitement

```mermaid
graph LR
    A[CSV Files] -->|Extract| B[Python ETL]
    B -->|Transform| C[Clean Data]
    C -->|Load| D[MySQL]
    D -->|Query| E[Report Gen]
    E -->|Write| F[rapport.txt]
    
    style A fill:#e1f5ff
    style C fill:#c8e6c9
    style D fill:#fff9c4
    style F fill:#f8bbd0
```

### 1. Extract
- Lecture CSV avec **pandas**
- Validation d'existence
- Logging du nombre de lignes

### 2. Transform
- **11+ problemes de qualite** detectes et corriges
- Doublons semantiques (meme personne, IDs differents)
- Formats de dates mixtes (YYYY-MM-DD, DD/MM/YYYY)
- Emails invalides, valeurs manquantes, scores negatifs

### 3. Load
- Insertion MySQL avec **idempotence** (`ON DUPLICATE KEY UPDATE`)
- TRUNCATE automatique pour garantir des donnees propres
- Gestion correcte des NaN/None

### 4. Report
- Statistiques generales (joueurs, scores, jeux)
- Top 5 meilleurs scores
- Moyennes par jeu
- Repartitions geographiques et par plateforme

---

## Problemes de qualite traites

<div align="center">

### 11 problemes detectes et corriges

</div>

#### Donnees Joueurs (`Players.csv`)

| # | Probleme | Solution | Exemple |
|:-:|----------|----------|---------|
| 1 | **Doublons semantiques** | Detection par `(username, email, date, pays, niveau)` | `ShadowBlade` avec `player_id=1` et `10` |
| 2 | **Espaces parasites** | `str.strip()` automatique | `"  StarGazer  "` → `"StarGazer"` |
| 3 | **Emails invalides** | Verification `@` present | `"nightwolf"` → `NULL` |
| 4 | **Emails manquants** | Conversion en `NULL` | `""` → `NULL` |
| 5 | **Dates mixtes** | Parsing `format='mixed'` | `"15/03/2023"` et `"2023-06-15"` |
| 6 | **Dates invalides** | Detection impossibilite | `"30-02-2024"`, `"date_inconnue"` → `NULL` |

#### Donnees Scores (`Scores.csv`)

| # | Probleme | Solution | Exemple |
|:-:|----------|----------|---------|
| 7 | **Scores negatifs/nuls** | Suppression `score <= 0` | `-500` |
| 8 | **Scores manquants** | Suppression lignes vides | Score vide |
| 9 | **Dates invalides** | Conversion `errors='coerce'` | `"date_invalide"` → `NULL` |
| 10 | **Doublons stricts** | Suppression sur `score_id` | `SCR024` = doublon de `SCR001` |
| 11 | **Orphelins** | Filtrage par `valid_player_ids` | `player_id=99` n'existe pas |

---

## Architecture

### Services Docker

```yaml
┌─────────────────────────────────────┐
│         Docker Compose              │
├─────────────────┬───────────────────┤
│   MySQL 8.0     │   Python 3.11     │
│   Port: 3306    │   Scripts ETL     │
│   Healthcheck   │   Volume mounts   │
└─────────────────┴───────────────────┘
```

### Flux d'automatisation

La commande `docker compose up --build -d` orchestre automatiquement :

1. **Demarrage MySQL** : Creation des tables via `init-db.sql`
2. **Attente DB** : `wait-for-db.sh` verifie la disponibilite (30 tentatives, 60s max)
3. **ETL** : `main.py` execute Extract, Transform, Load
4. **Report** : Generation du fichier `output/rapport.txt`

---

## Commandes

### Commandes principales

```bash
# Demarrer le projet et executer le pipeline
docker compose up --build -d

# Voir les logs en temps reel
docker compose logs -f app

# Arreter les services
docker compose down
```

### Commandes de developpement

```bash
# Shell interactif dans le conteneur
docker compose exec app bash

# Console Python
docker compose exec app python

# Acces MySQL direct
docker compose exec db mysql -u user -ppassword gametracker

# Reinitialiser la base
docker compose exec db mysql -u user -ppassword gametracker < scripts/init-db.sql
```

---

## Resultats

### Avant/Apres nettoyage

| Metrique | Brut | Nettoye | Changement |
|----------|:----:|:-------:|:----------:|
| **Joueurs** | 25 | 23 | -2 (doublons semantiques) |
| **Scores** | 40 | 34 | -6 (invalides) |
| **Qualite** | Sale | Propre | +11 regles |

### Exemple de rapport genere

```
====================================================
GAMETRACKER - Rapport de synthese
====================================================

--- Statistiques generales ---
Nombre de joueurs : 23
Nombre de scores  : 34
Nombre de jeux    : 3

--- Top 5 des meilleurs scores ---
1. DarkPhoenix     | SpaceInvaders | 22500
2. DragonSlayer99  | SpaceInvaders | 21000
3. QuantumLeap     | SpaceInvaders | 20200
4. FrostBite       | SpaceInvaders | 19400
5. CyberNinja      | SpaceInvaders | 18500

--- Sessions par plateforme ---
PC       : 19
Console  : 10
Mobile   : 5
====================================================
```

---

## Auteur

<div align="center">

### **Mathieu Lopes Moreira**

**BUT Science des Donnees** - 2025-2026  
Mini-Projet Individuel : GameTracker  
Automatisation et Tests en Programmation

[![GitHub](https://img.shields.io/badge/GitHub-mathieulopesmoreira-181717?style=flat-square&logo=github)](https://github.com/mathieulopesmoreira)

</div>

---

<div align="center">

© 2026 Mathieu Lopes Moreira

</div>
