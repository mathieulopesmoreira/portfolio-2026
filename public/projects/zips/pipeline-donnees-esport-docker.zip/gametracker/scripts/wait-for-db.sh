#!/bin/bash

# Wait for MySQL to be ready
echo "Waiting for MySQL..."
for i in {1..30}; do
    if mysqladmin ping -h"$DB_HOST" -u"$DB_USER" -p"$DB_PASSWORD" --skip-ssl --silent; then
        echo "MySQL is up and running!"
        exit 0
    fi
    echo "Waiting for MySQL... ($i/30)"
    sleep 2
done

echo "MySQL did not come up in time."
exit 1
