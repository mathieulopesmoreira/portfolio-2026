#!/bin/bash

# Configuration
DB_HOST=${DB_HOST:-localhost}
DB_USER=${DB_USER:-user}
DB_PASSWORD=${DB_PASSWORD:-password}
DB_NAME=${DB_NAME:-gametracker}

echo "===================================================="
echo "         GAMETRACKER PIPELINE AUTOMATION            "
echo "===================================================="

# 1. Wait for Database
echo "[Step 1/4] Waiting for database..."
./scripts/wait-for-db.sh
if [ $? -ne 0 ]; then
    echo "Error: Database is not available."
    exit 1
fi

# 2. Initialize Database
echo "[Step 2/4] Initializing database..."
mysql -h"$DB_HOST" -u"$DB_USER" -p"$DB_PASSWORD" --skip-ssl "$DB_NAME" < scripts/init-db.sql
if [ $? -ne 0 ]; then
    echo "Error: Failed to initialize database."
    exit 1
fi

# 3. Run ETL Pipeline
echo "[Step 3/4] Running ETL Pipeline..."
python src/main.py
if [ $? -ne 0 ]; then
    echo "Error: ETL Pipeline failed."
    exit 1
fi

# 4. End
echo "===================================================="
echo "         PIPELINE COMPLETED SUCCESSFULLY            "
echo "===================================================="
